﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BasikBatel : MonoBehaviour
{
    public GameObject Gen;
    public GameObject GG;
    public GameObject GP;
    //анимирует ближний бой
    // Start is called before the first frame update
    void Start()
    {
        Gen = GameObject.Find("Canvas");
    }
    public void hod()
    {
        //переносим цель в канвас
        GG.transform.SetParent(Gen.transform);
    }
    // Update is called once per frame
    void Update()
    {
        
    }
}
