﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ListAnimator : MonoBehaviour
{//проигрыватель
    public bool stop = true;
    public float stor;//счетчик
    public int taim;
    private int list;//количество
    private int plist;//количество

    //генератор анимаций
    //public string tayp;
    public string tayp;



    public int coz;//данные 1
    public GameObject GG;//с кем работаем
    public GameObject GG0;
    public GameObject GG1;
    // Start is called before the first frame update
    //собирает очередь анимациий и воиспроизводит их
    void Start()
    {

    }

    //void support()
    //{ 
    //    stor += (1 * Time.deltaTime);
    //    if ((int)stor >= taim)
    //    {
    //        Debug.Log(stor);
    //        stor = 0;
    //        taim = 0;
    //    } 
    //    else
    //    {
    //        support();
    //    }
    //}
    public void invoid(GameObject GGt, int vol)
    {
        list += vol;
        var ta = Instantiate(GG0, new Vector3(gameObject.transform.position.x, gameObject.transform.position.y, 0), Quaternion.identity);//вызываемый обект
        ta.transform.SetParent(gameObject.transform);
        //ta.transform.position = new Vector3(0, 0, 0);
        ta.GetComponent<magic>().coz = coz;
        ta.GetComponent<magic>().tayp = tayp;
        ta.GetComponent<magic>().GG1 = GGt;
        ta.name = "ani" + list;
    }

    public void anList(string taypz)
    {
        //католог анимаций
       /*
        отправлем запрос на вызов анимации, система генерит анимацию
        у анимации есть задержка, которая по идее должна предотвращать многопоточность
         
         
         */
        switch (taypz)
        {
            case ("Dam")://ближний бой
                //мечь на карту
                break;
            case ("DDam")://дальний бой
                break;
            case ("Death1")://анимация смерти 1
                break;
            case ("Hp")://обработчик хп
                //разработать кориктеровки для лица
                var ta = Instantiate(GG1, new Vector3(GG.GetComponent<magic>().GG1.transform.position.x, GG.GetComponent<magic>().GG1.transform.position.y, 0), Quaternion.identity);//вызываемый обект
                ta.transform.SetParent(GG.GetComponent<magic>().GG1.transform);
                ta.GetComponent<Text>().text = "" + GG.GetComponent<magic>().coz;
                ta.name = "anim"+ stor;
                break;

        }



    }
    public void player(string taypz, GameObject GGt, int coss)
    {
        switch (taypz)
        {
            case ("Dam")://ближний бой
                //мечь на карту
                //
                break;
            case ("DDam")://дальний бой
                break;
            case ("Death1")://анимация смерти 1
                break;
            case ("Hp")://обработчик хп
                var ta = Instantiate(GG1, new Vector3(GGt.GetComponent<card>().HPBuf.transform.position.x, GGt.GetComponent<card>().HPBuf.transform.position.y, 0), Quaternion.identity);//вызываемый обект
                ta.transform.SetParent(GGt.GetComponent<card>().HPBuf.transform);
                ta.GetComponent<Text>().text = "" + coss;
                break;

        }
    }
    // Update is called once per frame
    void FixedUpdate()
    {//их проигрывание
        if (stop == false)
        {

            stor += (1 * Time.deltaTime);
            if ((int)stor >= taim)
            {
                taim = (int)stor;
                GG = GameObject.Find("ani"+ taim);
                if (GG != null)
                {
                    GG.GetComponent<magic>().play(); 
                }
                plist++;
                if(plist >= list)
                {
                    list = 0;
                    stor = 0;
                    taim = 0;
                    plist = 0;
                    stop = true;
                }
            }
        }
    }
}
