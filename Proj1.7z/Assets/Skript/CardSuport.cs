﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class CardSuport : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    public string name;
    public string clas = "skill";
    public GameObject mel;
    public GameObject canvas;
    // Start is called before the first frame update
    void Start()
    {
        canvas = GameObject.Find("Canvas");
        switch (name)
        {
            case ("Dam"):
                if(mel.GetComponent<card>().dam <= 0)
                {   gameObject.active = false;  }
                break;
            case ("DDam"):
                if (mel.GetComponent<card>().ddam <= 0)
                {  gameObject.active = false; }
                break;
            default:
                gameObject.active = false;
                break;
        }
    }
    



    public void OnPointerEnter(PointerEventData eventData)
    {
        canvas.GetComponent<stol>().mood = name;
        canvas.GetComponent<stol>().selector = mel;
        canvas.GetComponent<stol>().clas = "Сreator";



    }
    public void OnPointerExit(PointerEventData eventData)
    {
        if (canvas.GetComponent<stol>().sel == null)
        {
            canvas.GetComponent<stol>().clas = null;
        }


        //canvas.GetComponent<stol>().selector = null;
    }
    // Update is called once per frame
    void Update()
    {
        
    }
}
