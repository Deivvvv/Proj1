﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class SuportMenu : MonoBehaviour
{
    //подгружаем текст
    public int lang;
    public GameObject obj;
    public GameObject general;

    public string titelrus;
    public string titeleng;
    // Start is called before the first frame update
    void Start()
    {
        general = GameObject.Find("Canvas");
        lang = general.GetComponent<GeneralSetting>().Language;
        switch (lang)
        {
            case (0):
                //руский
                if(obj != null)
                {
                    obj.GetComponent<Text>().text = titelrus;
                }
                else
                {
                    gameObject.GetComponent<Text>().text = titelrus;
                }
                break;
            case (1):
                //английский
                if (obj != null)
                {
                    obj.GetComponent<Text>().text = titeleng;
                }
                else
                {
                    gameObject.GetComponent<Text>().text = titeleng;
                }
                break;
            default:
                //отсутсвует локализация
                break;
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
