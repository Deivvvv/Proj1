﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AddAvatar : MonoBehaviour
{
    public GameObject General;

    public string name;
    // Start is called before the first frame update


        public void butt()
    {
        General.GetComponent<basicgenrator>().avatar = name;
        General.GetComponent<basicgenrator>().stat();
    }
    void Start()
    {
       // General = GameObject.Find("Canvas");
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
