﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class activ : MonoBehaviour
{
    public GameObject GG;
    public bool ev;

    public void active()
    {
        if (GG.active == false) { GG.active = true; } else { GG.active = false; }

    }
    public void alt()
    {
        if (ev == false) { if (GG.active == false) { GG.active = true; } else { GG.active = false; } }

    }
    public void fall()
    {
        GG.active = false;
    }
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
