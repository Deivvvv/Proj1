﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class creares : MonoBehaviour
{
    public GameObject hpcos;
    public GameObject damcos;
    public GameObject mene;//name

    //public int def;
    public int hp;
    public int dam;

    public int team = 0;//команада можно буль если их 2
    public string clas = "creator";
    // Start is called before the first frame update
    void Start()
    {
        hpcos.GetComponent<Text>().text = "" +hp;
        damcos.GetComponent<Text>().text = "" + dam;

    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
