﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class magic : MonoBehaviour
{
    //компоненты анимаций
    public string tayp;
    public int coz;
    public GameObject GG1;

    public void play()
    {
        GameObject GG;
        Debug.Log(gameObject);
        GG = GameObject.Find("Canvas");
        GG.GetComponent<ListAnimator>().GG = gameObject;
        GG.GetComponent<ListAnimator>().anList(tayp);
    }
}
