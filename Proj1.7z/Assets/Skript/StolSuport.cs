﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StolSuport : MonoBehaviour
{
    public string Sek;//код запроса
    public GameObject GG;
    public int lok;//указатель

    public bool res;//результат

    private bool blok;//блокировка, на время выполнения процедуры
    public int ret;
    public int reg;
    public int lez;
    public int boof1;//эффекты стола команды 1
    public int boof2;//эффекты стола команды 2
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void bsek()
    {//шит для процедуры
        if(blok != true)
        {
            blok = true;
            sekr();
        }
    }
    //поиск по эффектам
    private void sekr()
    {
        
        res = false;
        ret++;
        GG = GameObject.Find("boof" + lok + ":" + ret);
        if(GG != null)
        {
            reg++;
            if (Sek == GG.GetComponent<Arow>().tayp)
            {
                res = true;
            }
        }
        else
        {
            lez++;
        }
        if (res == true)
        {//доп деиствия для расширенного запроса

            blok = false;
            //cброс
            //ret = 0;
        }
        else if (lok == 0)
        {
            if (reg >= boof1) 
            {
                blok = false;
                ret = 0;
                reg = 0;
                if(lez >= boof1)
                {
                    boof1 = 0;
                }
            }
            else{ sekr(); }
        }
        else
        {
            if (reg >= boof2)
            {
                blok = false;
                ret = 0;
                reg = 0;
                if (lez >= boof2)
                {
                    boof2 = 0;
                }
            }
            else { sekr(); }
        }
        lez = 0;
    }
}
