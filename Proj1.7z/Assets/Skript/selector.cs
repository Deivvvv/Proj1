﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class selector : MonoBehaviour
{
    //stol 1
    //stol 2
    //селектор нужен для реализации карт на стол, реализации перетаскивания карт, создает ссылку на преобразование каты в существо или заклятие
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
