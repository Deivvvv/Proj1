﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class colodss : MonoBehaviour
{
    //правила управления колодой

    public GameObject selector;//пространство хранения вызываемой карты
    public GameObject select;//выбрананя карта
    public GameObject sel;
    private GameObject GG;


    private string clas;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        //левая кнопка  взятие
        if (Input.GetKeyDown(KeyCode.Mouse0))
        {

            if (sel == null)
            {
                sel = selector;

                if (sel != null)
                {

                    clas = sel.GetComponent<card>().clas;
                }
            }
        }


        //реализация
        if (Input.GetKeyUp(KeyCode.Mouse0))
        {
            if ((sel != null) & (select == null))
            {
                select = selector;
            }
            if ((select != null) & (sel != null))
            {

                //ДЛя инициализациия карт
                if ((select.GetComponent<card>().clas == "card") &(clas == "card"))//если это пользовательские карты
                {
                    select.GetComponent<card>().id = sel.GetComponent<card>().id;
                }
                else { Debug.Log("это не карта"); }
                if ((select.GetComponent<card>().clas == "pcard") & (clas == "pcard"))//если это наши карты Pcard
                {
                    select.GetComponent<card>().id = sel.GetComponent<card>().id;
                }
                else { Debug.Log("это не карта"); }
                if ((select.GetComponent<card>().clas == "pcard") & (clas == "PProf"))//если это наши карты
                {
                    select.GetComponent<card>().id = sel.GetComponent<card>().id;
                }
                else { Debug.Log("это не карта"); }
                if ((select.GetComponent<card>().clas == "card") & (clas == "Prof"))//если это пользовательские карты
                {
                    select.GetComponent<card>().id = sel.GetComponent<card>().id;
                }
                GG = GameObject.Find("Canvas");
                GG.GetComponent<BibLoad>().UpColod();

                select = null;
                sel = null;

            }
            else
            {
                //sel.transform.SetParent(stol1.transform);//перемещение обекта внутрь иерархи
                sel = null;
            }
        }









        if (Input.GetKeyDown(KeyCode.Mouse1))
        {
            sel = selector;
            if (sel.GetComponent<card>().clas == "card")
            {
                sel.GetComponent<card>().id = 0;

            }
            if (sel.GetComponent<card>().clas == "Pcard")
            {
                sel.GetComponent<card>().id = 0;

            }

            GG = GameObject.Find("Canvas");
            GG.GetComponent<BibLoad>().UpColod();
            sel = null;
        }
    }
}
