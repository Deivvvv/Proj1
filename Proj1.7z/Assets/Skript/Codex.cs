﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Codex : MonoBehaviour
{
    // Start is called before the first frame update
    public string clas;
    public string selClas;
    public string mood;
    public int ret;
    public int reg;

    public GameObject select;
    public GameObject sel;
    public GameObject GG;
    void Start()
    {
        
    }
    void HP()
    {
        if(sel.GetComponent<card>().team == 1)
        { 
            gameObject.GetComponent<ListAnimator>().coz = ret;
            gameObject.GetComponent<ListAnimator>().tayp = "Hp";
            gameObject.GetComponent<ListAnimator>().invoid(gameObject, 4);
        }
        else
        {
            gameObject.GetComponent<ListAnimator>().player("HP", select, ret);
        }
    }
    void BlokCom()
    {
        //сюда входят обязательные проверки
        gameObject.GetComponent<StolSuport>().Sek = "Taynt";
        gameObject.GetComponent<StolSuport>().lok = select.GetComponent<card>().team;
        gameObject.GetComponent<StolSuport>().bsek();
        if (gameObject.GetComponent<StolSuport>().res != true)
        {
            gameObject.GetComponent<StolSuport>().Sek = "Mask";
            gameObject.GetComponent<StolSuport>().lok = select.GetComponent<card>().team;
            gameObject.GetComponent<StolSuport>().bsek();
        }
        if ((sel.GetComponent<card>().team == 1) & ((gameObject.GetComponent<StolSuport>().res == true) & (select.GetComponent<card>().Protect.active != true)))//невозможная ситуация, обработчик, усовершенствовать его
        {//персмотреть
            Debug.Log(sel);
            gameObject.GetComponent<StolSuport>().ret = 0;
            gameObject.GetComponent<StolSuport>().reg = 0;
            gameObject.GetComponent<AIBasik>().reg--;
            gameObject.GetComponent<AIBasik>().skan();
            gameObject.GetComponent<StolSuport>().ret = 0;
            gameObject.GetComponent<StolSuport>().reg = 0;
        }
        // else
    }

    public void codex()
    {
        if ((clas == "Сreator") & (selClas == "Сreator"))
        {
            if ((gameObject.GetComponent<StolSuport>().boof1 > 0)||(gameObject.GetComponent<StolSuport>().boof2 > 0))//тут должна быть проветка на эффекты стола, не знаю название переменной пула
            { BlokCom(); }
            if (select != null)
            {


                if ((gameObject.GetComponent<StolSuport>().res != true) || ((gameObject.GetComponent<StolSuport>().res == true) & (select.GetComponent<card>().Protect.active == true)))
                {

                    //canvas.GetComponent<StolSuport>().ret = 0;
                    //Debug.Log(mood);
                    switch (mood)
                    {
                        case ("Dam"):
                            if (sel.GetComponent<card>().team != select.GetComponent<card>().team)
                            {
                                if ((sel.GetComponent<card>().power == true) & (select.GetComponent<card>().avo == false) & (sel.GetComponent<card>().avo == false))
                                {
                                    ret = 35;
                                    if (((sel.GetComponent<card>().sp1 == ret) || (sel.GetComponent<card>().sp2 == ret) || (sel.GetComponent<card>().sp3 == ret) || (sel.GetComponent<card>().sp4 == ret) || (sel.GetComponent<card>().sp5 == ret)) & ((select.GetComponent<card>().sp1 == ret) || (select.GetComponent<card>().sp2 == ret) || (select.GetComponent<card>().sp3 == ret) || (select.GetComponent<card>().sp4 == ret) || (select.GetComponent<card>().sp5 == ret)))
                                    {//взаимная атака
                                        ret = 0;
                                        ret = select.GetComponent<card>().def + select.GetComponent<card>().shild - sel.GetComponent<card>().dam;
                                        if (ret < 0)
                                        {
                                            reg = select.GetComponent<card>().hp + ret;
                                            select.GetComponent<card>().hp += ret;
                                            //HP
                                            gameObject.GetComponent<ListAnimator>().GG = select.GetComponent<card>().HPBuf;
                                            HP();

                                        }
                                        ret = 0;

                                        if (reg < 0)
                                        {
                                            GG = select.GetComponent<card>().Stol;
                                        }
                                            Debug.Log(select);
                                            ret = sel.GetComponent<card>().def + sel.GetComponent<card>().shild - select.GetComponent<card>().dam;
                                            if (ret < 0)
                                            {
                                                sel.GetComponent<card>().hp += ret;
                                                //HP
                                                gameObject.GetComponent<ListAnimator>().GG = sel.GetComponent<card>().HPBuf;
                                                HP();
                                            }
                                            ret = 0;
                                        sel.GetComponent<card>().power = false;
                                        select.GetComponent<card>().statys();
                                        sel.GetComponent<card>().statys();

                                    }
                                    else if (((sel.GetComponent<card>().sp1 == ret) || (sel.GetComponent<card>().sp2 == ret) || (sel.GetComponent<card>().sp3 == ret) || (sel.GetComponent<card>().sp4 == ret) || (sel.GetComponent<card>().sp5 == ret)))
                                    {
                                        ret = 0;
                                        ret = select.GetComponent<card>().def + select.GetComponent<card>().shild - sel.GetComponent<card>().dam;
                                        if (ret < 0)
                                        {
                                            reg = select.GetComponent<card>().hp + ret;
                                            select.GetComponent<card>().hp += ret;
                                            //HP
                                            gameObject.GetComponent<ListAnimator>().GG = select.GetComponent<card>().HPBuf;
                                            HP();
                                            
                                        }
                                        ret = 0;
                                        Debug.Log(select);

                                        if (reg < 0)
                                        {
                                            GG = select.GetComponent<card>().Stol;
                                        }
                                        select.GetComponent<card>().statys();
                                        if (select.GetComponent<card>().hp > 0)
                                        {
                                            Debug.Log(select);
                                            ret = sel.GetComponent<card>().def + sel.GetComponent<card>().shild - select.GetComponent<card>().dam;
                                            if (ret < 0)
                                            {
                                                sel.GetComponent<card>().hp += ret;
                                                //HP
                                                gameObject.GetComponent<ListAnimator>().GG = sel.GetComponent<card>().HPBuf;
                                                HP();
                                            }
                                            ret = 0;
                                        }
                                        sel.GetComponent<card>().power = false;
                                        sel.GetComponent<card>().statys();
                                    }
                                    else if (((select.GetComponent<card>().sp1 == ret) || (select.GetComponent<card>().sp2 == ret) || (select.GetComponent<card>().sp3 == ret) || (select.GetComponent<card>().sp4 == ret) || (select.GetComponent<card>().sp5 == ret)))
                                    {
                                        ret = 0;

                                        ret = sel.GetComponent<card>().def + sel.GetComponent<card>().shild - select.GetComponent<card>().dam;
                                        if (ret < 0)
                                        {
                                            sel.GetComponent<card>().hp += ret;
                                            //HP
                                            gameObject.GetComponent<ListAnimator>().GG = sel.GetComponent<card>().HPBuf;
                                            HP();
                                        }
                                        ret = 0;
                                        sel.GetComponent<card>().statys();
                                        if (sel.GetComponent<card>().hp > 0)
                                        {
                                            sel.GetComponent<card>().power = false;
                                            ret = select.GetComponent<card>().def + select.GetComponent<card>().shild - sel.GetComponent<card>().dam;
                                            if (ret < 0)
                                            {
                                                reg = select.GetComponent<card>().hp + ret;
                                                select.GetComponent<card>().hp += ret;
                                                //HP
                                                gameObject.GetComponent<ListAnimator>().GG = select.GetComponent<card>().HPBuf;
                                                HP();
                                            }
                                            ret = 0;
                                        }

                                        if (reg < 0)
                                        {
                                            GG = select.GetComponent<card>().Stol;
                                        }
                                        select.GetComponent<card>().statys();

                                    }
                                    else
                                    {
                                        ret = 0;
                                        ret = select.GetComponent<card>().def + select.GetComponent<card>().shild - sel.GetComponent<card>().dam;
                                        if (ret < 0)
                                        {
                                            reg = select.GetComponent<card>().hp + ret;
                                            select.GetComponent<card>().hp += ret;
                                            //HP
                                            gameObject.GetComponent<ListAnimator>().GG = select.GetComponent<card>().HPBuf;
                                            HP();
                                        }
                                        ret = sel.GetComponent<card>().def + sel.GetComponent<card>().shild - select.GetComponent<card>().dam;
                                        if (ret < 0)
                                        {
                                            sel.GetComponent<card>().hp += ret;
                                            //HP
                                            gameObject.GetComponent<ListAnimator>().GG = sel.GetComponent<card>().HPBuf;
                                            HP();
                                        }
                                        ret = 0;
                                        if (reg < 0)
                                        {
                                            GG = select.GetComponent<card>().Stol;
                                        }

                                        //select.GetComponent<card>().hp -= sel.GetComponent<card>().dam;
                                        sel.GetComponent<card>().power = false;
                                        //sel.GetComponent<card>().hp -= select.GetComponent<card>().dam;
                                        sel.GetComponent<card>().statys();
                                        //sel.GetComponent<card>().mel.GetComponent<Image>().color = new Vector4(39 / 255.0f, 39 / 255.0f, 39 / 255.0f, 1);
                                        select.GetComponent<card>().statys();
                                    }





                                    if ((reg < 0) & (sel.GetComponent<card>().hp > 0))
                                    {
                                        ret = 27;//натиск//64 топот как аналог, зашит жестко
                                        if (((sel.GetComponent<card>().sp1 == ret) || (sel.GetComponent<card>().sp2 == ret) || (sel.GetComponent<card>().sp3 == ret) || (sel.GetComponent<card>().sp4 == ret) || (sel.GetComponent<card>().sp5 == ret)) || ((sel.GetComponent<card>().sp1 == 64) || (sel.GetComponent<card>().sp2 == 64) || (sel.GetComponent<card>().sp3 == 64) || (sel.GetComponent<card>().sp4 == 64) || (sel.GetComponent<card>().sp5 == 64)))
                                        {
                                            if (GG.GetComponent<StolSlot>().BObj != null)
                                            {
                                                select = GG.GetComponent<StolSlot>().BObj;




                                                ret = 35;
                                                if (((sel.GetComponent<card>().sp1 == ret) || (sel.GetComponent<card>().sp2 == ret) || (sel.GetComponent<card>().sp3 == ret) || (sel.GetComponent<card>().sp4 == ret) || (sel.GetComponent<card>().sp5 == ret)) & ((select.GetComponent<card>().sp1 == ret) || (select.GetComponent<card>().sp2 == ret) || (select.GetComponent<card>().sp3 == ret) || (select.GetComponent<card>().sp4 == ret) || (select.GetComponent<card>().sp5 == ret)))
                                                {//взаимная атака
                                                    ret = 0;
                                                    ret = select.GetComponent<card>().def + select.GetComponent<card>().shild - sel.GetComponent<card>().dam;
                                                    if (ret < 0)
                                                    {
                                                        reg = select.GetComponent<card>().hp + ret;
                                                        select.GetComponent<card>().hp += ret;
                                                        //HP
                                                        gameObject.GetComponent<ListAnimator>().GG = select.GetComponent<card>().HPBuf;
                                                        HP();

                                                    }
                                                    ret = 0;

                                                    if (reg < 0)
                                                    {
                                                        GG = select.GetComponent<card>().Stol;
                                                    }
                                                    Debug.Log(select);
                                                    ret = sel.GetComponent<card>().def + sel.GetComponent<card>().shild - select.GetComponent<card>().dam;
                                                    if (ret < 0)
                                                    {
                                                        sel.GetComponent<card>().hp += ret;
                                                        //HP
                                                        gameObject.GetComponent<ListAnimator>().GG = sel.GetComponent<card>().HPBuf;
                                                        HP();
                                                    }
                                                    ret = 0;
                                                    sel.GetComponent<card>().power = false;
                                                    select.GetComponent<card>().statys();
                                                    sel.GetComponent<card>().statys();

                                                }
                                                else
                                                if (((sel.GetComponent<card>().sp1 == ret) || (sel.GetComponent<card>().sp2 == ret) || (sel.GetComponent<card>().sp3 == ret) || (sel.GetComponent<card>().sp4 == ret) || (sel.GetComponent<card>().sp5 == ret)))
                                                {
                                                    Debug.Log(ret);
                                                    ret = 0;
                                                    ret = select.GetComponent<card>().def + select.GetComponent<card>().shild - reg;
                                                    if (ret < 0)
                                                    {
                                                        reg = select.GetComponent<card>().hp + ret;
                                                        select.GetComponent<card>().hp += ret;
                                                        //HP
                                                        gameObject.GetComponent<ListAnimator>().GG = select.GetComponent<card>().HPBuf;
                                                        HP();
                                                    }
                                                    ret = 0;
                                                    Debug.Log(select);

                                                    select.GetComponent<card>().statys();
                                                    if (select.GetComponent<card>().hp > 0)
                                                    {
                                                        Debug.Log(select);
                                                        ret = sel.GetComponent<card>().def + sel.GetComponent<card>().shild - select.GetComponent<card>().dam;
                                                        if (ret < 0)
                                                        {
                                                            sel.GetComponent<card>().hp += ret;
                                                            //HP
                                                            gameObject.GetComponent<ListAnimator>().GG = sel.GetComponent<card>().HPBuf;
                                                            HP();
                                                        }
                                                        ret = 0;
                                                    }
                                                    sel.GetComponent<card>().power = false;
                                                    sel.GetComponent<card>().statys();
                                                }
                                                else if (((select.GetComponent<card>().sp1 == ret) || (select.GetComponent<card>().sp2 == ret) || (select.GetComponent<card>().sp3 == ret) || (select.GetComponent<card>().sp4 == ret) || (select.GetComponent<card>().sp5 == ret)))
                                                {
                                                    ret = 0;

                                                    ret = sel.GetComponent<card>().def + sel.GetComponent<card>().shild - select.GetComponent<card>().dam;
                                                    if (ret < 0)
                                                    {
                                                        sel.GetComponent<card>().hp += ret;
                                                        //HP
                                                        gameObject.GetComponent<ListAnimator>().GG = sel.GetComponent<card>().HPBuf;
                                                        HP();
                                                    }
                                                    ret = 0;
                                                    sel.GetComponent<card>().statys();
                                                    if (sel.GetComponent<card>().hp > 0)
                                                    {
                                                        sel.GetComponent<card>().power = false;
                                                        ret = select.GetComponent<card>().def + select.GetComponent<card>().shild - reg;
                                                        if (ret < 0)
                                                        {
                                                            reg = select.GetComponent<card>().hp + ret;
                                                            select.GetComponent<card>().hp += ret;
                                                            //HP
                                                            gameObject.GetComponent<ListAnimator>().GG = select.GetComponent<card>().HPBuf;
                                                            HP();
                                                        }
                                                        ret = 0;
                                                    }
                                                    select.GetComponent<card>().statys();

                                                }
                                                else
                                                {
                                                    ret = 0;
                                                    //Debug.Log(mood);
                                                    ret = select.GetComponent<card>().def + select.GetComponent<card>().shild - reg;
                                                    if (ret < 0)
                                                    {
                                                        reg = select.GetComponent<card>().hp + ret;
                                                        select.GetComponent<card>().hp += ret;
                                                        //HP
                                                        gameObject.GetComponent<ListAnimator>().GG = select.GetComponent<card>().HPBuf;
                                                        HP();
                                                    }
                                                    ret = sel.GetComponent<card>().def + sel.GetComponent<card>().shild - select.GetComponent<card>().dam;
                                                    if (ret < 0)
                                                    {
                                                        sel.GetComponent<card>().hp += ret;
                                                        //HP
                                                        gameObject.GetComponent<ListAnimator>().GG = sel.GetComponent<card>().HPBuf;
                                                        HP();
                                                    }
                                                    ret = 0;

                                                    //select.GetComponent<card>().hp -= sel.GetComponent<card>().dam;
                                                    sel.GetComponent<card>().power = false;
                                                    //sel.GetComponent<card>().hp -= select.GetComponent<card>().dam;
                                                    sel.GetComponent<card>().statys();
                                                    //sel.GetComponent<card>().mel.GetComponent<Image>().color = new Vector4(39 / 255.0f, 39 / 255.0f, 39 / 255.0f, 1);
                                                    select.GetComponent<card>().statys();
                                                }

                                            }

                                        }

                                    }
                                    ret = 64;
                                    if ((reg < 0) & ((sel.GetComponent<card>().sp1 == ret) || (sel.GetComponent<card>().sp2 == ret) || (sel.GetComponent<card>().sp3 == ret) || (sel.GetComponent<card>().sp4 == ret) || (sel.GetComponent<card>().sp5 == ret)))
                                    {
                                       //проверить чей лагерь
                                        if (sel.GetComponent<card>().team == 0)
                                        {
                                            gameObject.GetComponent<stol>().Ehp += reg;//был -, + из-за инверсии
                                        }
                                        else
                                        {
                                            gameObject.GetComponent<stol>().hp += reg;
                                        }
                                        sel.GetComponent<card>().statys();
                                    }
                                }
                                //sel = null;
                            }


                            break;
                        case ("DDam"):

                            if (sel.GetComponent<card>().team != select.GetComponent<card>().team)
                            {
                                if (sel.GetComponent<card>().power == true)
                                {
                                    //Debug.Log(mood);
                                    //кастуем спел стрела
                                    var ta = Instantiate(gameObject.GetComponent<stol>().Spell, new Vector3(0, 0, 0), Quaternion.identity);//вызываемый обект
                                    ta.transform.SetParent(sel.transform);

                                    sel.GetComponent<card>().buffcost++;
                                    ta.name = "Buf" + sel.GetComponent<card>().buffcost;
                                    ta.GetComponent<Arow>().mel = select;
                                    ta.GetComponent<Arow>().host = sel;
                                    ta.GetComponent<Arow>().taym = 1;
                                    ta.GetComponent<Arow>().strong = sel.GetComponent<card>().ddam;
                                    ta.GetComponent<Arow>().tayp = "Aroww";
                                    ta.GetComponent<Arow>().mell = ta;
                                    ta.GetComponent<Arow>().clas = selClas;
                                    ta.GetComponent<Arow>().host = sel.GetComponent<card>().mel;
                                    /*
                                     * mel;//тело(цель)
                                        taym;//время каста
                                        pstrong;//сила
                                        tayp;
                                     */


                                    sel.GetComponent<card>().power = false;
                                    sel.GetComponent<card>().Cast = true;
                                    sel.GetComponent<card>().statys();

                                    select.GetComponent<card>().statys();
                                }
                                //sel = null;
                            }

                            break;
                    }

                }
            }
        }
        else if ((clas == "Сreator") & (selClas == "Head"))
        {

            gameObject.GetComponent<StolSuport>().Sek = "Taynt";
            //if(sel)
            gameObject.GetComponent<StolSuport>().lok = select.GetComponent<StolSlot>().team;
            gameObject.GetComponent<StolSuport>().bsek();
            if (gameObject.GetComponent<StolSuport>().res != true)
            {
                switch (mood)
                {
                    case ("Dam"):
                        if (sel.GetComponent<card>().team != select.GetComponent<StolSlot>().team)
                        {
                            if (sel.GetComponent<card>().power == true)
                            {
                                Debug.Log(gameObject.GetComponent<StolSuport>().res);
                                sel.GetComponent<card>().power = false;
                                if (sel.GetComponent<card>().team == 0)
                                {
                                    gameObject.GetComponent<stol>().Ehp -= sel.GetComponent<card>().dam;
                                }
                                else
                                {
                                    gameObject.GetComponent<stol>().hp -= sel.GetComponent<card>().dam;
                                }
                                sel.GetComponent<card>().statys();

                            }
                        }
                        break;
                    case ("DDam"):

                        if (sel.GetComponent<card>().team != select.GetComponent<StolSlot>().team)
                        {
                            if (sel.GetComponent<card>().power == true)
                            {
                                //Debug.Log(mood);
                                //кастуем спел стрела
                                var ta = Instantiate(gameObject.GetComponent<stol>().Spell, new Vector3(0, 0, 0), Quaternion.identity);//вызываемый обект
                                ta.transform.SetParent(sel.transform);

                                sel.GetComponent<card>().buffcost++;
                                ta.name = "Buf" + sel.GetComponent<card>().buffcost;
                                ta.GetComponent<Arow>().mel = select;
                                ta.GetComponent<Arow>().host = sel;
                                ta.GetComponent<Arow>().taym = 1;
                                ta.GetComponent<Arow>().strong = sel.GetComponent<card>().ddam;
                                ta.GetComponent<Arow>().tayp = "Aroww";
                                ta.GetComponent<Arow>().mell = ta;
                                ta.GetComponent<Arow>().clas = "Head";
                                ta.GetComponent<Arow>().host = sel.GetComponent<card>().mel;
                                /*
                                 * mel;//тело(цель)
                                    taym;//время каста
                                    pstrong;//сила
                                    tayp;
                                 */


                                sel.GetComponent<card>().power = false;
                                sel.GetComponent<card>().Cast = true;
                                sel.GetComponent<card>().statys();

                            }
                            //sel = null;
                        }

                        break;
                }
            }


            gameObject.GetComponent<stol>().hpbar.GetComponent<Text>().text = "" + gameObject.GetComponent<stol>().hp;
            gameObject.GetComponent<stol>().ehpbar.GetComponent<Text>().text = "" + gameObject.GetComponent<stol>().Ehp;
        }

        //sel = null;




        //sel = null;
        //select = null;


        gameObject.GetComponent<StolSuport>().ret = 0;
        gameObject.GetComponent<StolSuport>().reg = 0;


        ret = 0;
        reg = 0;



    }
// Update is called once per frame
void Update()
    {
        
    }
}
