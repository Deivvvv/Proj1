﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using UnityEngine.UI;
using UnityEngine.EventSystems;

public class StolSlot : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    public GameObject AObj;
    public GameObject BObj;

    public string clas = "Slot";

    public int team;
    public GameObject canvas;
    public GameObject Gen;
    public GameObject SuportSlot;
    //private

    //выполняет роль слотов стола
    // Start is called before the first frame update
    void Start()
    {
        canvas = GameObject.Find("Canvas");
        if (Gen != null) { Gen.active = false; }
        
    }
    public void Restruct()
    {
        if ((AObj == null)&(BObj != null))
        {

            BObj.GetComponent<card>().avo = false;
            BObj.GetComponent<card>().instal();
            AObj = BObj;
            BObj = null;
        }
        
    }
    // Update is called once per frame
    void Update()
    {
        
    }
    public void OnPointerEnter(PointerEventData eventData)
    {
        if((AObj != null)&(canvas.GetComponent<stol>().sel != null)&(BObj == null)&(canvas.GetComponent<stol>().clas == "card"))
        {
            Gen.active = true;

            AObj.transform.SetParent(SuportSlot.transform);

        }
        else
        {
            if(clas == "Head")
            {
                canvas.GetComponent<stol>().selector = gameObject;
                canvas.GetComponent<stol>().selClas = clas;



            }
            else
            if((canvas.GetComponent<stol>().sel != null) & (canvas.GetComponent<stol>().clas == "card"))
            {
                canvas.GetComponent<stol>().selector = gameObject;
                canvas.GetComponent<stol>().selClas = clas;
            }
            
        }
        
        if (Gen != null)
        {
           // if (turn == true)
            //{
                //AObj.transform.SetParent(SuportSlot.transform);
           // }
        }
        //Debug.Log("Selest   " + gameObject.name);

        //if (canvas.GetComponent<GeneralSetting>().Mod == "Colod") {
        //    canvas.GetComponent<stol>().selector = gameObject;
        //}


    }
    public void OnPointerExit(PointerEventData eventData)
    {if (clas != "Head")
        {
            if (Gen.active == true)
            {
                AObj.transform.SetParent(gameObject.transform);
                Gen.active = false;
            }

            canvas.GetComponent<stol>().selector = null;
            canvas.GetComponent<stol>().selClas = null;
        }
        else
        {
            canvas.GetComponent<stol>().selector = null;
            canvas.GetComponent<stol>().selClas = null;
        }
       
    }



}
