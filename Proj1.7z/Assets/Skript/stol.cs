﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

using System.IO;

public class stol : MonoBehaviour
{
    public bool AIMod;
    public bool MPMod;

    private float vstat;

    private bool Rhod;//свич хода

    public bool rest;//команад сброса 
    public bool createee;//команад сброса 


    public string boof;//буфер
    public string boog;//буфер
    private string cod;//буфер
    private string path;//буфер
    private int ret;//счетчик

    private int reg;//счетчик

    public GameObject GG;//курсор
    public GameObject GP;//курсор
    public GameObject Spell;//спел(buf)

    private string str1;
    private string str2;
    private string str3;
    private int str4;
    public int str5;


    public string mood;//мод
    public string clas;
    public string selClas;

    public int coun;//количество карт
    public int conStol;//количество карт
    public int EconStol;//количество карт
    public GameObject counReg;//количество карт
    public GameObject EcounReg;//количество карт

    public Camera _camera;
    public GameObject key;//курсор
    public GameObject go;//вызываем карту
    public GameObject stol1;//стол 1
    public GameObject stol2;//стол 2
    public GameObject stol3;//стол 3
    public GameObject stol4;//стол 4
    public GameObject hott;//индикатор маны
    public GameObject Ehott;//индикатор маны
    //public GameObject hotta;//индикатор маны текущей
    public GameObject hpbar;//индикатор hp текущей
    public GameObject ehpbar;//индикатор ehp текущей
    public bool goop;//ждем составления колоды

    public GameObject creares;//существо

    

    public Image mbar1;

    public GameObject Head1;
    public GameObject Head2;
    

    public GameObject selector;//пространство хранения вызываемой карты
    public GameObject select;
    public GameObject sel;
    public GameObject selFik;//фиксация оригинала


    public int sizehand = 3;//колода в руке start
    public int handdask = 7;//колода в руке start


    public int Emanebatel;//боевая мана 2 игрока
    public int Ehp = 30;//вражеское здоровье
    public int Emane;//маны за ход
    public int Ecard;//в колоде
    public int Ehand;//карты в руке


    public int mane;//маны за ход
    public int manegame = 10;//макс маны 10
    public int manebatel;//боевая мана

    public int hp = 30;//здоровье
    private int hod = 1;//текущий ход
    
    public int ID = 0;//номер карты
    public int IDE = 0;//буфер
    public int IDP = 0;//буфер

    private war sde = new war();
    private cardwar sg = new cardwar();

    //мы претягиваем карты удержание клавиши мышы

    void Start ()
    {
        path = Path.Combine(Application.dataPath);
        cod = path + "/colods/general.json"; 
        sde = JsonUtility.FromJson<war>(File.ReadAllText(cod));

        Rhod = false;
        str1 = sde.tayp;
        str2 = sde.cold;
        Debug.Log(sde.tayp);
        Debug.Log(sde.cold);


        cod = path + "/colods/"+sde.tayp +"/"+ sde.cold +".json"; 
        sde = JsonUtility.FromJson<war>(File.ReadAllText(cod));
        

        Debug.Log(sde.tag);
        str3 = sde.tag;
        Debug.Log(sde.pcard);
        str4 = sde.pcard;
        Debug.Log(sde.ccard);
        str5 = sde.ccard;
        stage1();

        maness();
        hott.GetComponent<Text>().text = "" + manebatel + " / " + mane;//активная мана
        hpbar.GetComponent<Text>().text = "" +hp;
        ehpbar.GetComponent<Text>().text = "" + Ehp;
        /* var ta = Instantiate(creares, new Vector3(0, 0, 0), Quaternion.identity);//вызываемый обект
        ta.transform.SetParent(stol2.transform);
        ta.GetComponent<card>().neme = "Манекен голем";
        ta.GetComponent<card>().dam = 1;
        ta.GetComponent<card>().hp = 12;
        ta.GetComponent<card>().clas = "Creator";
        ta.GetComponent<card>().team = 1;*/

        //ta.GetComponent<card>().start();


        hhod();
        goop = true;//временная команда
    }
    private void stage2()
    {
        //if(ID ==0) { ID = 1; }
        //перемешивание
       // Debug.Log(str5);
        IDE = Random.Range(1, (str5 +1));
       // Debug.Log(IDE);
        GP = GameObject.Find("" + IDE + "card");
        if(GP != null)
        {
            ID++;
            GP.name = "card"+ID;
            GG = GameObject.Find("Buffer2");
            GP.transform.SetParent(GG.transform);//перемещение обекта внутрь иерархи
            GG = GameObject.Find("Buffer1");
            GP.transform.SetParent(GG.transform);//перемещение обекта внутрь иерархи
        }
        //if( ID >= str5)
        //{
        //    ID = 100;
        //}
        if (ID >= str5)
        {
            //Debug.Log(ID);
            //Debug.Log(str5);
            //stage2();
            ID = 0;
            IDE = 0;
            //GG = GameObject.Find("Buffer1");
            Altstage2();
            //stage3();
        }
        else
        {
            stage2();
        }
    }
    private void Altstage2()
    {
        //if(ID ==0) { ID = 1; }
        //перемешивание
     //   Debug.Log(str5);
        IDP = Random.Range(1, (str5 + 1));
// Debug.Log(IDP);
        GP = GameObject.Find("" + IDP + "Acard");
        if (GP != null)
        {
            ID++;
            GP.name = "Acard" + IDP;
            GG = GameObject.Find("Buffer2");
            GP.transform.SetParent(GG.transform);//перемещение обекта внутрь иерархи
        }
        //if( ID >= str5)
        //{
        //    ID = 100;
        //}
        if (ID >= str5)
        {
            //Debug.Log(ID);
            //Debug.Log(str5);
            //stage2();
            ID = 0;
            IDP = 0;
            //GG = GameObject.Find("Buffer1");
            stage3();
        }
        else
        {
            Altstage2();
        }
    }


    private void stage3()
    {
        //создаем копию команды для бота используя rhod
       
        if (Rhod == false)
        {
            IDE++;
            GP = GameObject.Find("card" + IDE);
            coun--;
            conStol++;
            counReg.GetComponent<Text>().text = "" + coun;
            if (conStol > handdask)
            {
                Destroy(GP);
                conStol--;
            }
            else
            {
                if(coun >= 0)
                {
                    // GP = GameObject.Find("card" + IDE);
                    GP.transform.SetParent(stol1.transform);
                    GP.transform.localScale = new Vector3(0.6f, 0.6f, 0.6f);//0.7 norm
                }
               
            }
            if (IDE < sizehand )//пересчитать
            {

                Rhod = true; stage3();
            }
        }
        else
        {
            IDP++;
            GP = GameObject.Find("Acard" + IDP);
            Ecard--;
            Ehand++;
            EcounReg.GetComponent<Text>().text = "" + (Ecard + str5);
            if (Ehand > handdask)
            {
                Destroy(GP);
                Ehand--;
            }
            else
            {
                if (coun >= 0)
                {
                    // GP = GameObject.Find("card" + IDE);
                    GP.transform.SetParent(stol2.transform);
                    GP.transform.localScale = new Vector3(0.6f, 0.6f, 0.6f);//0.7 norm
                }

            }
            if (IDP < sizehand)
            {
                Rhod = false;
                stage3();
            }
        }

    }

    private void Altstage1()
    {
        //Debug.Log(str1);//tayp
        // Debug.Log(str2);//cold

        // Debug.Log(str3);//tag
        // Debug.Log(str4);//pcard
        // Debug.Log(str5);//ccard


        //ret++;

        //coun++;

        cod = path + "/colods/" + str1 + "/" + str2 + "/" + ret + ".json";
        sde = JsonUtility.FromJson<war>(File.ReadAllText(cod));

        if (sde.cardes == 0) { cod = path + "/colods/ErorrColod/rest/0.json"; }
        else
        {
            if (ret <= str4)
            {
                cod = path + "/cold/" + str3 + "/" + sde.cardes + ".json";
            }
            else
            {
                cod = path + "/cold/" + str1 + "/" + sde.cardes + ".json";

            }
        }



        sg = JsonUtility.FromJson<cardwar>(File.ReadAllText(cod));




        GG = GameObject.Find("Buffer1");

        var ta = Instantiate(creares, new Vector3(0, 0, 0), Quaternion.identity);//вызываемый обект
        ta.transform.SetParent(GG.transform);//перемещение обекта внутрь иерархи
        ta.name = "" + ret + "Acard";


        if (ret <= str4)
        {
            ta.GetComponent<Image>().color = new Color(255 / 255.0f, 211 / 255.0f, 61 / 255.0f);//золотой
        }
        else
        {
            ta.GetComponent<Image>().color = new Color(205 / 255.0f, 205 / 255.0f, 205 / 255.0f);//серебренный

        }


        ta.GetComponent<card>().id = sg.num;
        ta.GetComponent<card>().neme = sg.names;
        ta.GetComponent<card>().dam = sg.dam;
        ta.GetComponent<card>().ddam = sg.ddam;
        ta.GetComponent<card>().hp = sg.hp;
        ta.GetComponent<card>().clas = "Card";

        ta.GetComponent<card>().avatar = sg.Imagesss;

        ta.GetComponent<card>().slotName.GetComponent<Text>().text = sg.names;//переправить
        ta.GetComponent<card>().broe = sg.broe;
        ta.GetComponent<card>().crush = sg.crush;
        ta.GetComponent<card>().shilds = sg.shilds;
        ta.GetComponent<card>().shild = sg.shild;
        ta.GetComponent<card>().ship = sg.ship;
        ta.GetComponent<card>().def = sg.def;
        ta.GetComponent<card>().spas = sg.spas;
        ta.GetComponent<card>().sal = sg.sal;
        ta.GetComponent<card>().toh = sg.toh;
        ta.GetComponent<card>().zap = sg.zap;
        ta.GetComponent<card>().mobi = sg.mobi;
        ta.GetComponent<card>().izv = sg.izv;
        ta.GetComponent<card>().ura = sg.ura;
        ta.GetComponent<card>().mane = sg.mana;
        //sg.sizes = sizes;
        ta.GetComponent<card>().sp1 = sg.sp1;
        ta.GetComponent<card>().sp2 = sg.sp2;
        ta.GetComponent<card>().sp3 = sg.sp3;
        ta.GetComponent<card>().sp4 = sg.sp4;
        ta.GetComponent<card>().sp5 = sg.sp5;
        ta.GetComponent<card>().team = 1;//команда


        if (ret >= str5)
        {
            ret = 0;
            stage2();
        }
        else
        {
            stage1();
        }
    }


    private void stage1()
    {
        //Debug.Log(str1);//tayp
       // Debug.Log(str2);//cold

       // Debug.Log(str3);//tag
       // Debug.Log(str4);//pcard
       // Debug.Log(str5);//ccard


        ret++;

        coun++;

        cod = path + "/colods/" + str1 + "/" + str2 + "/" + ret + ".json";
        sde = JsonUtility.FromJson<war>(File.ReadAllText(cod));

        if(sde.cardes == 0) { cod = path + "/colods/ErorrColod/rest/0.json"; }
        else
        {
            if (ret <= str4)
            {
                cod = path + "/cold/" + str3 + "/" + sde.cardes + ".json";
            }
            else
            {
                cod = path + "/cold/" + str1 + "/" + sde.cardes + ".json";

            }
        }
        


       sg = JsonUtility.FromJson<cardwar>(File.ReadAllText(cod));




        GG = GameObject.Find("Buffer1");

        var ta = Instantiate(creares, new Vector3(0, 0, 0), Quaternion.identity);//вызываемый обект
        ta.transform.SetParent(GG.transform);//перемещение обекта внутрь иерархи
        ta.name = "" + ret + "card";
       

        if (ret <= str4)
        {
            ta.GetComponent<Image>().color = new Color(255 / 255.0f, 211 / 255.0f, 61 / 255.0f);//золотой
        }
        else
        {
            ta.GetComponent<Image>().color = new Color(205 / 255.0f, 205 / 255.0f, 205 / 255.0f);//серебренный

        }


        ta.GetComponent<card>().id = sg.num;
        ta.GetComponent<card>().neme = sg.names;
        ta.GetComponent<card>().dam = sg.dam;
        ta.GetComponent<card>().ddam = sg.ddam;
        ta.GetComponent<card>().hp = sg.hp;
        ta.GetComponent<card>().clas = "Card";

        ta.GetComponent<card>().avatar = sg.Imagesss;

        ta.GetComponent<card>().slotName.GetComponent<Text>().text = sg.names;//переправить
        ta.GetComponent<card>().broe = sg.broe;
        ta.GetComponent<card>().crush = sg.crush;
        ta.GetComponent<card>().shilds = sg.shilds;
        ta.GetComponent<card>().shild = sg.shild;
        ta.GetComponent<card>().ship = sg.ship;
        ta.GetComponent<card>().def = sg.def;
        ta.GetComponent<card>().spas = sg.spas;
        ta.GetComponent<card>().sal = sg.sal;
        ta.GetComponent<card>().toh = sg.toh;
        ta.GetComponent<card>().zap = sg.zap;
        ta.GetComponent<card>().mobi = sg.mobi;
        ta.GetComponent<card>().izv = sg.izv;
        ta.GetComponent<card>().ura = sg.ura;
        ta.GetComponent<card>().mane = sg.mana;
        //sg.sizes = sizes;
        ta.GetComponent<card>().sp1 = sg.sp1;
        ta.GetComponent<card>().sp2 = sg.sp2;
        ta.GetComponent<card>().sp3 = sg.sp3;
        ta.GetComponent<card>().sp4 = sg.sp4;
        ta.GetComponent<card>().sp5 = sg.sp5;
        ta.GetComponent<card>().team = 0;//команда

        /*
         if (ret >= str5)
        {
            ret = 0;
            stage2();
        }
        else
        {
            stage1();
        }
         */
        Altstage1();

    }
    public void astage4()
    {
        ret++;
        if (Rhod == true)
        {
            GG = GameObject.Find("Slot" + ret);
        }
        else
        {
            GG = GameObject.Find("SlotA" + ret);
        }
        if (GG.GetComponent<StolSlot>().AObj != null)
        {
            GG.GetComponent<StolSlot>().AObj.GetComponent<card>().Hod();
        }
        if (GG.GetComponent<StolSlot>().BObj != null)
        {
            GG.GetComponent<StolSlot>().BObj.GetComponent<card>().Hod();
        }
    }

        private void stage4()
    {
        ret++;
        if (Rhod == false)
        {
            GG = GameObject.Find("Slot" + ret);
        }
        else
        {
            GG = GameObject.Find("SlotA" + ret);
        }


        //GG.GetComponent<StolSlot>().Restruct();
        if (GG.GetComponent<StolSlot>().AObj != null)
        {
            GG.GetComponent<StolSlot>().AObj.GetComponent<card>().Hod();
            //GG.GetComponent<StolSlot>().AObj.GetComponent<card>().id++;
        }
        if (GG.GetComponent<StolSlot>().BObj != null)
        {
            GG.GetComponent<StolSlot>().BObj.GetComponent<card>().Hod();
        }

        // Debug.Log(ret);
        if (ret >= 7) { ret = 0; stage5(); } else { stage4(); }
    }
    public void stage5()
    {
        
            ret++;
        if (Rhod == true)
        {
            GG = GameObject.Find("Slot" + ret);
        }
        else
        {
            GG = GameObject.Find("SlotA" + ret);
        }
        GG.GetComponent<StolSlot>().Restruct();
        if (GG.GetComponent<StolSlot>().AObj != null)
        {
            GG.GetComponent<StolSlot>().AObj.GetComponent<card>().SReader();
        }
        if (GG.GetComponent<StolSlot>().BObj != null)
        {
            GG.GetComponent<StolSlot>().BObj.GetComponent<card>().SReader();
        }

        //Debug.Log(ret);
        if (ret >= 7) { ret = 0; } else { stage5(); }
         

    }
    /*void FixedUpdate()
    {
            x = (Input.mousePosition.x);
            y = (Input.mousePosition.y);
            key.transform.position = new Vector3(x,y, 0f);
    }*/


    public void stage6()
    {

        ret++;
            GG = GameObject.Find("Slot" + ret);
        
        if (GG.GetComponent<StolSlot>().AObj != null)
        {
            GG.GetComponent<StolSlot>().AObj.GetComponent<card>().SReader12();
        }
        if (GG.GetComponent<StolSlot>().BObj != null)
        {
            GG.GetComponent<StolSlot>().BObj.GetComponent<card>().SReader12();
        }

        GG = GameObject.Find("SlotA" + ret);
        if (GG.GetComponent<StolSlot>().AObj != null)
        {
            GG.GetComponent<StolSlot>().AObj.GetComponent<card>().SReader12();
        }
        if (GG.GetComponent<StolSlot>().BObj != null)
        {
            GG.GetComponent<StolSlot>().BObj.GetComponent<card>().SReader12();
        }
        //Debug.Log(ret);
        if (ret >= 7) { ret = 0; Debug.Log("sistam skan"); } else { stage6(); }


    }
    // Update is called once per frame
    void Update()
    {






        if (Input.GetKeyDown(KeyCode.Mouse0))
        {
            if (sel == null)
            {
                sel = selector;

            }
            if (sel != null)
            {
                if (clas != "Сreator")
                {
                    if (sel.GetComponent<card>().clas == "Card")
                    {
                        if (sel.GetComponent<card>().team != 0)
                        {
                            sel = null;
                        }
                        else
                        {
                            clas = "card";
                            sel.GetComponent<Image>().color = new Vector4(51 / 255.0f, 255 / 255.0f, 0 / 255.0f, 1);//gren
                        }

                    }
                    else if (sel.GetComponent<card>().clas == "Creator")
                    {
                        clas = "Сreator";
                        sel.GetComponent<Image>().color = new Vector4(51 / 255.0f, 255 / 255.0f, 0 / 255.0f, 1);//gren
                                                                                                                //цветовая индикация
                                                                                                                //sel.GetComponent<Image>().color = new Vector4(39 / 255.0f, 39 / 255.0f, 39 / 255.0f, 1);
                    }
                }


            }
            //if (clas == "Сreator")
            // {

            //sel.transform.localScale = new Vector3(0.8f, 0.8f, 1f);
            // }
            //ret = 0;
            //stage5();//обработчик состаяний

            stage6();
        }


        if (Input.GetKeyUp(KeyCode.Mouse0))
        {
            if ((sel != null) & (select == null))
            {
                select = selector;
            }



            if ((select != null) & (sel != null))
            {
                //ДЛя инициализациия карт
                if (clas == "card")
                {
                    if (selClas == "Slot")
                    {
                        if (select.GetComponent<StolSlot>().team != 0)
                        {
                            sel.GetComponent<card>().mane = 0;
                            sel.GetComponent<card>().team = 1;
                            //sel.transform.rotation = Quaternion.Euler(0, 0, 180);
                        }
                    }
                    else if (selClas == "SlotSuport")
                    {
                        if (select.GetComponent<StolSlotSuport>().team != 0)
                        {
                            sel.GetComponent<card>().mane = 0;
                            sel.GetComponent<card>().team = 1;
                        }
                    }

                    if (manebatel >= sel.GetComponent<card>().mane)
                    {
                         
                        if (selClas == "Slot")
                        {
                            sel.GetComponent<card>().Stol = select;
                            sel.GetComponent<card>().clas = "Сreator"; 
                            sel.transform.SetParent(select.transform);
                            select.GetComponent<StolSlot>().AObj = sel;

                            sel.GetComponent<card>().instal();
                            conStol--;

                            sel.GetComponent<Image>().color = new Vector4(39 / 255.0f, 39 / 255.0f, 39 / 255.0f, 1);//blak
                            clas = null; 
                        }
                        else if (selClas == "SlotSuport")
                        {
                            sel.GetComponent<card>().Stol = select.GetComponent<StolSlotSuport>().Gen;
                            sel.GetComponent<card>().clas = "Сreator";

                            sel.GetComponent<Image>().color = new Vector4(39 / 255.0f, 39 / 255.0f, 39 / 255.0f, 1); 
                            if (select.GetComponent<StolSlotSuport>().turn == true)
                            {
                                select.GetComponent<StolSlotSuport>().Gen.GetComponent<StolSlot>().AObj.GetComponent<card>().avo = true;



                                select.GetComponent<StolSlotSuport>().Gen.GetComponent<StolSlot>().BObj = select.GetComponent<StolSlotSuport>().Gen.GetComponent<StolSlot>().AObj;

                                select.GetComponent<StolSlotSuport>().Gen.GetComponent<StolSlot>().AObj = sel;
                                sel.transform.SetParent(select.GetComponent<StolSlotSuport>().Gen.transform);
                                select.GetComponent<StolSlotSuport>().Gen.GetComponent<StolSlot>().BObj.transform.SetParent(select.GetComponent<StolSlotSuport>().Gen.transform);
                                select.GetComponent<StolSlotSuport>().Gen.GetComponent<StolSlot>().BObj.GetComponent<card>().instal();
                                select.GetComponent<StolSlotSuport>().Gen.GetComponent<StolSlot>().AObj.GetComponent<card>().instal();
                                conStol--;

                                clas = null; 
                            }
                            else
                            {
                                conStol--;
                                select.GetComponent<StolSlotSuport>().Gen.GetComponent<StolSlot>().AObj.transform.SetParent(select.GetComponent<StolSlotSuport>().Gen.transform);

                                select.GetComponent<StolSlotSuport>().Gen.GetComponent<StolSlot>().BObj = sel;
                                sel.transform.SetParent(select.GetComponent<StolSlotSuport>().Gen.transform);
                                select.GetComponent<StolSlotSuport>().Gen.GetComponent<StolSlot>().BObj.GetComponent<card>().avo = true;
                                select.GetComponent<StolSlotSuport>().Gen.GetComponent<StolSlot>().BObj.GetComponent<card>().instal();
                                select.GetComponent<StolSlotSuport>().Gen.GetComponent<StolSlot>().AObj.GetComponent<card>().instal();
                                clas = null;
                            }
                        } 
                        if (null != selClas)
                        {
                            manebatel -= sel.GetComponent<card>().mane;
                            maness();
                        } 
                    } 

                    if (clas == "card")
                    {

                        sel.GetComponent<Image>().color = new Vector4(255 / 255.0f, 255 / 255.0f, 255 / 255.0f, 1);
                    } 

                    clas = null;
                    sel = null;
                    select = null; 
                }


                else if (clas == "Сreator")
                {
                        //select.transform.localScale = new Vector3(0.8f, 0.8f, 1f);
                    gameObject.GetComponent<Codex>().clas = clas;
                    gameObject.GetComponent<Codex>().selClas = selClas;
                    gameObject.GetComponent<Codex>().mood = mood;
                    // ret;
                    //  reg;

                    gameObject.GetComponent<Codex>().select = select;
                    gameObject.GetComponent<Codex>().sel = sel;

                    gameObject.GetComponent<Codex>().codex();

                }
                 

                    ret = 0;
                reg = 0;

                //двустороний обработчик
                if (Rhod == true)
                {
                    Rhod = false;
                    stage5();
                }
                else
                {
                    Rhod = true;
                    stage5();
                }
                if (Rhod == true)
                {
                    Rhod = false;
                    stage5();
                }
                else
                {
                    Rhod = true;
                    stage5();
                }



                //stage5();
                //stage5();//обработчик состаяний


                clas = null;
                selClas = null;
                //sel.transform.SetParent(stol1.transform);//перемещение обекта внутрь иерархи
                //if(sel != null)
                //{
                //  sel.transform.localScale = new Vector3(0.6f, 0.6f, 1f);
                // }
                //if (select != null)
                //{
                //  select.transform.localScale = new Vector3(0.6f, 0.6f, 1f);
                // }
                select = null;
                sel = null;
                mood = null;
                //select = null;
                //stage6();
            }
            else
            {
                sel = null;
            }
            stage6();
        }





    }

    //перемешиваем карты в начале игры



        public void HpHead()
    {

        hpbar.GetComponent<Text>().text = "" + hp;
        ehpbar.GetComponent<Text>().text = "" + Ehp;
    }



    public void Newhod()
    {
        Rhod = false; //suphhod();
        stage3();
        if (mane < manegame) { mane++; }
        manebatel = mane;
        stage4();
        maness();
    }
        public void hhod()
    {
       //suphhod();
      //  if (Rhod == false)
      //  {
            Rhod = true;
            stage3();
            hod++;
            if (Emane < manegame) { Emane++; }
            Emanebatel = Emane;
            stage4();
            maness();
            gameObject.GetComponent<AIBasik>().Sinx();
            gameObject.GetComponent<AIBasik>().skan();
            // suphhod();
       // }
       // else {
        //    Rhod = false; //suphhod();
        //    stage3();
        //    if (mane < manegame) { mane++; }
        //    manebatel = mane;
        //    stage4();
        //    maness();
       // }

        //suphhod();
        //if (Rhod == false)
        //     {
        //        Rhod = true;
        //     }
        //    else { Rhod = false; }



        //if (Rhod == true) { hhod(); } //else { Rhod = true; hhod(); }


    }

    public void maness()
        
    {
        //vstat = (1f *manebatel) / mane; //деактивированно
       // mbar1.fillAmount = vstat ;
        hott.GetComponent<Text>().text = "" + manebatel + " / " + mane;//активная мана
        Ehott.GetComponent<Text>().text = "" + Emanebatel + " / " + Emane;//активная мана
    }
    
}
public class war
{

    public string tayp;
    public string cold;
    public string tag;
    public int ccard;
    public int pcard;
    public int cardes;



}

public class cardwar
{
    public string Imagesss;

    public string names;

    public int num;//номер объекта

    public int dam;//Ближний бой
    public int ddam;//Дальний бой
    public int broe;//Бронебойность
    public int crush;//Бронелом

    public int shilds;//размер щиты
    public int shild;//щиты
    public int ship;//шипы
    public int def;//броня


    public int spas;//спасение
    public int sal;//салто
    public int toh;//точность
    public int zap;//запугивание


    public int mobi;//перемещение
    public int izv;//изворотливость
    public int ura;//куворок

    public int hp;//жизнь
    public int mana;

    //public int sizes;//количество спосбностей

    public int sp1;
    public int sp2;
    public int sp3;
    public int sp4;
    public int sp5;
}