﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

using System.IO;

public class BibLoad : MonoBehaviour
{
    private int Lang;//язык
    //этот скрипт служит для загрузки библотеки
    public GameObject av;//шаблон а
    public GameObject bv;//шаблон б
    public GameObject doll;//место колоды
    public GameObject doll1;//место колоды
    public GameObject doll3;//место колоды
    public GameObject doll4;//место колоды

    private bool control = false;

    public GameObject GenColod;//шаблон ссылок колоды
    public GameObject doll2;//место колоды

    private cardessss sg = new cardessss();

    private GameObject GG;
    public string boof;//буфер
    private string cod;//буфер
    private string path;//буфер
    public int frak;
    public string frakname;
    private int ret;
    private int reg;
    private int regg;
    private int reff;
    private colodes sde = new colodes();
    private colod sd = new colod();
    private genco gp = new genco();


    /*
     * Используя даные из general производим выгрузку активной колоды по библиотеке
     * 
     * Для колод используется генерируемый colod_general отвечающий за библиотеку определенного типа
     *
     *тех данные:

    выбраный тип, выбранная колода





     */
    // Start is called before the first frame update
    void Start()
    {
        GG = GameObject.Find("Canvas");
        Lang = GG.GetComponent<GeneralSetting>().Language;

        


        path = Path.Combine(Application.dataPath);
        cod = path + "/cold/generalst.json";
        if (!File.Exists(cod)) { print("warning 1 отсутвуют библотеки или управлющие фаилы" + cod); }//warning 1 отсутвуют библотеки или управлющие фаилы
        else
        {
            sde = JsonUtility.FromJson<colodes>(File.ReadAllText(cod));
            ret = sde.size;
            boof = sde.names;

            cod = path + "/cold/"+ boof +".json";
            sde = JsonUtility.FromJson<colodes>(File.ReadAllText(cod));
            reg = sde.size;

            boof = "cold1";

            cod = path + "/colods/general.json";

            if (!File.Exists(cod)) { sde.names = "cold1"; sde.bibsize = 100; File.WriteAllText(cod, JsonUtility.ToJson(sde)); }// вызов аварийной колоды проработать
            //sde.size = gp.size;
            sde = JsonUtility.FromJson<colodes>(File.ReadAllText(cod));



            sde.names = boof;
            sde.cold = "colod1";
            sde.tayp = boof;
            sde.frak = "noname";
            sde.size = ret;
            ret = 0;

            //sde.cold = "colod";
            sde.bibsize = reg;
            reg = 0;
            gp.pcard = 10;
            gp.ccard = 25;



            //sde = JsonUtility.FromJson<colodes>(File.ReadAllText(cod));
            File.WriteAllText(cod, JsonUtility.ToJson(sde));

            cod = path + "/colods/" + sde.tayp + "/";//шаблон записывается по номеру
            if (!Directory.Exists(cod)) { Debug.Log(cod); Directory.CreateDirectory(cod); }


            cod = path + "/colods/" + sde.tayp + "/gen_colod.json";
            if (!File.Exists(cod)) {
                sd.cardes = 0;
                File.WriteAllText(cod, JsonUtility.ToJson(sd));

            }
            
            sd = JsonUtility.FromJson<colod>(File.ReadAllText(cod));

            cod = path + "/colods/" + sde.tayp + "/" + sde.cold + ".json";
            print(cod);
            if (!File.Exists(cod)) { Debug.Log(cod); ErorrColod(); }//ErorrColod(); }
            frakname = sde.frak;
            ret = 0;

            switch (sde.frak)
            {
                case ("noname"):
                    frak = 0; //гильдия
                    break;
                case ("Hunter"):
                    frak = 1; //охотники
                    break;
                case ("Thief"):
                    frak = 2;//Воры
                    break;
                case ("Knight"):
                    frak = 3;//Войны
                    break;
                case ("Civilian"):
                    frak = 4;//Ополченцы
                    break;
                case ("Slave"):
                    frak = 5;//Работорговцы
                    break;
                case ("Wild"):
                    frak = 6;//Дикари
                    break;
                case ("Traider"):
                    frak = 7;//Торговая гильдия
                    break;
                case ("Engine"):
                    frak = 8;//Инжинеры
                    break;
                case ("Gull"):
                    frak = 9;//Падальщики
                    break;
                case ("HeadHunter"):
                    frak = 10;//Наемники
                    break;
                case ("Cash"):
                    frak = 11;//Роставщики
                    break;
            }
            suportfraktion();

            ReBib();
            LoadGenColod();


            control = false;

            print("ok");



            LoadColod();
            LoadCard();
            PLoadCard();
            frakSuport();

            ret = 0;
            reg = 0;
        }
    }


    public void bone()
    {

        cod = path + "/colods/general.json";
        sde = JsonUtility.FromJson<colodes>(File.ReadAllText(cod));

        sde.cold = boof;

        File.WriteAllText(cod, JsonUtility.ToJson(sde));

        cod = path + "/colods/" + sde.tayp + "/boof.json";

        if (File.Exists(cod))
        {
            gp = JsonUtility.FromJson<genco>(File.ReadAllText(cod));
        }
    }

    private void LoadGenColod()
    {
        ret++;
        cod = path + "/colods/" + sde.tayp + "/colod" + ret + ".json";
        //cod = path + "/colods/noname/colod" + ret + ".json";

        Debug.Log(sd.cardes);
        if (File.Exists(cod))
        {
            gp = JsonUtility.FromJson<genco>(File.ReadAllText(cod));
            //загрузка сcылок на колоды
            var ta = Instantiate(GenColod, new Vector3(0, 0, 0), Quaternion.identity);//вызываемый обект
            ta.transform.SetParent(doll2.transform);
            ta.name = "cod" + reg;

            ta.GetComponent<ColodSelekt>().name = gp.names;
            Debug.Log(gp.names);
            ta.GetComponent<ColodSelekt>().gname.GetComponent<Text>().text = gp.names;
            ta.GetComponent<ColodSelekt>().gfrak.GetComponent<Text>().text = gp.tag;


            ta.GetComponent<ColodSelekt>().id = ret;



            switch (gp.tag)
            {
                default:
                    Debug.Log(gp.tag);
                    Debug.Log(Lang);
                    break;

                case ("noname"):
                    ta.GetComponent<ColodSelekt>().frak = 0; //гильдия
                    Debug.Log(Lang);
                    switch (Lang)
                    {
                        case (0): ta.GetComponent<ColodSelekt>().gfrak.GetComponent<Text>().text = "Неитралы"; break;
                        case (1): ta.GetComponent<ColodSelekt>().gfrak.GetComponent<Text>().text = "noname"; break;
                    }
                    /*
                     * Debug.Log(Lang);
                     switch (Lang)
                    {
                        case (0): ta.GetComponent<ColodSelekt>().gfrak.GetComponent<Text>().text = "Неитралы"; break;
                        case (1): ta.GetComponent<ColodSelekt>().gfrak.GetComponent<Text>().text = "noname"; break;
                    }
                     
                     */
                    break;
                case ("Hunter"):
                    ta.GetComponent<ColodSelekt>().frak = 1; //охотники
                    break;
                case ("Thief"):
                    ta.GetComponent<ColodSelekt>().frak = 2;//Воры
                    break;
                case ("Knight"):
                    ta.GetComponent<ColodSelekt>().frak = 3;//Войны
                    break;
                case ("Civilian"):
                    ta.GetComponent<ColodSelekt>().frak = 4;//Ополченцы
                    break;
                case ("Slave"):
                    ta.GetComponent<ColodSelekt>().frak = 5;//Работорговцы
                    break;
                case ("Wild"):
                    ta.GetComponent<ColodSelekt>().frak = 6;//Дикари
                    break;
                case ("Traider"):
                    ta.GetComponent<ColodSelekt>().frak = 7;//Торговая гильдия
                    break;
                case ("Engine"):
                    ta.GetComponent<ColodSelekt>().frak = 8;//Инжинеры
                    break;
                case ("Gull"):
                    ta.GetComponent<ColodSelekt>().frak = 9;//Падальщики
                    break;
                case ("HeadHunter"):
                    ta.GetComponent<ColodSelekt>().frak = 10;//Наемники
                    break;
                case ("Cash"):
                    ta.GetComponent<ColodSelekt>().frak = 11;//Роставщики
                    break;
            }
        }






        if (ret >= sd.cardes)
        {
            ret = 0; reg = 0;
            cod = path + "/colods/" + sde.tayp + "/" + sde.cold + ".json";

            gp = JsonUtility.FromJson<genco>(File.ReadAllText(cod));
        }
        //if (reg == sd.cardes) { ret = 0; reg = 0; }
        else { LoadGenColod(); }



    }


    public void SavColod()//сохранение колоды
    {
         
         if (ret == 0)
        {
            reg++;





            gp.names = "colod" + reg;
            cod = path + "/colods/" + sde.tayp + "/" + gp.names + ".json";

            if (File.Exists(cod)) { SavColod(); }

            sde.cold = gp.names;

            gp.names = "Изгои" + reg;//имя
            gp.tag = "noname";//фракция
            File.WriteAllText(cod, JsonUtility.ToJson(gp));

            cod = path + "/colods/" + sde.tayp + "/" + sde.cold + "/";//reg +
            if (!Directory.Exists(cod)) { Debug.Log(cod); Directory.CreateDirectory(cod); }

            


            cod = path + "/colods/" + sde.tayp + "/gen_colod.json";
            sd.cardes++;
            //sd.cardes = sd.cardes + 1;
            File.WriteAllText(cod, JsonUtility.ToJson(sd));
            reg = 0;
        }
        ret++;


        cod = path + "/colods/" + sde.tayp + "/" + sde.cold + "/" + ret + ".json";

        //GG = GameObject.Find("colod"+ ret);
        sd.cardes = 0;//GG.GetComponent<card>().id;
        File.WriteAllText(cod, JsonUtility.ToJson(sd));


        if (ret < gp.ccard) { SavColod(); }
        else
        {
            cod = path + "/colods/" + sde.tayp + "/gen_colod.json";
            sd = JsonUtility.FromJson<colod>(File.ReadAllText(cod));
            ret = 0;

        }
         
         
         
         


    }
    public void SavUPColod()//сохранение колоды
    {
        if(reg == 0)
        {
            cod = cod = path + "/colods/general.json";

            sde = JsonUtility.FromJson<colodes>(File.ReadAllText(cod));

            Debug.Log(sde.cold);
            cod = path + "/colods/" + sde.tayp + "/"+ sde.cold +".json";

            gp = JsonUtility.FromJson<genco>(File.ReadAllText(cod));
            sde.frak = frakname;//это фиксация новой библиотеки
        }

        reg++;

            GG = GameObject.Find("colod" + reg);

        sd.cardes = GG.GetComponent<card>().id;

        Debug.Log(sd.cardes);


        cod = path + "/colods/" + sde.tayp + "/" + sde.cold + "/" + reg + ".json";
        Debug.Log(cod);

        //GG = GameObject.Find("colod"+ ret);
        //sd.cardes = 0;//GG.GetComponent<card>().id;
        File.WriteAllText(cod, JsonUtility.ToJson(sd));
        


        if(reg < gp.ccard) { SavUPColod();  }
        else { reg = 0;
            cod = path + "/colods/" + sde.tayp + "/" + sde.cold + ".json"; ;
            gp.tag = frakname;

            File.WriteAllText(cod, JsonUtility.ToJson(gp));
        }


    }
    private void frakSuport()
    {
        GG = GameObject.Find("Titel1");
        switch (frak - 1)
        {
            case (0):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text = "Неитралы"; break;
                    case (1): GG.GetComponent<Text>().text = "noname"; break;
                }
                break;
            case (1):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text = "Охотники"; break;
                    case (1): GG.GetComponent<Text>().text = "Hunter"; break;
                }
                break;
            case (2):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text = "Воры"; break;
                    case (1): GG.GetComponent<Text>().text = "Thief"; break;
                }
                break;
            case (3):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text = "Войны"; break;
                    case (1): GG.GetComponent<Text>().text = "Warior"; break;
                }
                break;
            case (4):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text = "Ополченцы"; break;
                    case (1): GG.GetComponent<Text>().text = "Civilian"; break;
                }
                break;
            case (5):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text = "Работорговцы"; break;
                    case (1): GG.GetComponent<Text>().text = "Slave"; break;
                }
                break;
            case (6):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text = "Дикари"; break;
                    case (1): GG.GetComponent<Text>().text = "Wild"; break;
                }
                break;
            case (7):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text = "Торговая гильдия"; break;
                    case (1): GG.GetComponent<Text>().text = "Traider"; break;
                }
                break;
            case (8):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text = "Инжинеры"; break;
                    case (1): GG.GetComponent<Text>().text = "Engine"; break;
                }
                break;
            case (9):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text = "Падальщики"; break;
                    case (1): GG.GetComponent<Text>().text = "Gull"; break;
                }
                break;
            case (10):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text = "Наемники"; break;
                    case (1): GG.GetComponent<Text>().text = "HeadHunter"; break;
                }
                break;
            case (-1):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text = "Роставщики"; break;
                    case (1): GG.GetComponent<Text>().text = "Cash"; break;
                }
                break;
        }

        GG = GameObject.Find("Titel2");

        switch (frak)
        {
            case (0):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text = "Неитралы"; break;
                    case (1): GG.GetComponent<Text>().text = "noname"; break;
                }
                break;
            case (1):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text = "Охотники"; break;
                    case (1): GG.GetComponent<Text>().text = "Hunter"; break;
                }
                break;
            case (2):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text = "Воры"; break;
                    case (1): GG.GetComponent<Text>().text = "Thief"; break;
                }
                break;
            case (3):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text = "Войны"; break;
                    case (1): GG.GetComponent<Text>().text = "Warior"; break;
                }
                break;
            case (4):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text = "Ополченцы"; break;
                    case (1): GG.GetComponent<Text>().text = "Civilian"; break;
                }
                break;
            case (5):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text = "Работорговцы"; break;
                    case (1): GG.GetComponent<Text>().text = "Slave"; break;
                }
                break;
            case (6):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text = "Дикари"; break;
                    case (1): GG.GetComponent<Text>().text = "Wild"; break;
                }
                break;
            case (7):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text = "Торговая гильдия"; break;
                    case (1): GG.GetComponent<Text>().text = "Traider"; break;
                }
                break;
            case (8):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text = "Инжинеры"; break;
                    case (1): GG.GetComponent<Text>().text = "Engine"; break;
                }
                break;
            case (9):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text = "Падальщики"; break;
                    case (1): GG.GetComponent<Text>().text = "Gull"; break;
                }
                break;
            case (10):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text = "Наемники"; break;
                    case (1): GG.GetComponent<Text>().text = "HeadHunter"; break;
                }
                break;
            case (11):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text = "Роставщики"; break;
                    case (1): GG.GetComponent<Text>().text = "Cash"; break;
                }
                break;
        }
        GG = GameObject.Find("Titel3");
        switch (frak +1)
        {
            case (12):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text = "Неитралы"; break;
                    case (1): GG.GetComponent<Text>().text = "noname"; break;
                }
                break;
            case (1):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text = "Охотники"; break;
                    case (1): GG.GetComponent<Text>().text = "Hunter"; break;
                }
                break;
            case (2):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text = "Воры"; break;
                    case (1): GG.GetComponent<Text>().text = "Thief"; break;
                }
                break;
            case (3):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text = "Войны"; break;
                    case (1): GG.GetComponent<Text>().text = "Warior"; break;
                }
                break;
            case (4):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text = "Ополченцы"; break;
                    case (1): GG.GetComponent<Text>().text = "Civilian"; break;
                }
                break;
            case (5):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text = "Работорговцы"; break;
                    case (1): GG.GetComponent<Text>().text = "Slave"; break;
                }
                break;
            case (6):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text = "Дикари"; break;
                    case (1): GG.GetComponent<Text>().text = "Wild"; break;
                }
                break;
            case (7):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text = "Торговая гильдия"; break;
                    case (1): GG.GetComponent<Text>().text = "Traider"; break;
                }
                break;
            case (8):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text = "Инжинеры"; break;
                    case (1): GG.GetComponent<Text>().text = "Engine"; break;
                }
                break;
            case (9):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text = "Падальщики"; break;
                    case (1): GG.GetComponent<Text>().text = "Gull"; break;
                }
                break;
            case (10):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text = "Наемники"; break;
                    case (1): GG.GetComponent<Text>().text = "HeadHunter"; break;
                }
                break;
            case (11):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text = "Роставщики"; break;
                    case (1): GG.GetComponent<Text>().text = "Cash"; break;
                }
                break;
        }
        

    }

    private void suportfraktion()
    {
        GG = GameObject.Find("StColod");
        GG.GetComponent<Text>().text = "Колода: " + sde.cold;
        GG = GameObject.Find("StFrak");
        switch (Lang)
        {
            case (0): GG.GetComponent<Text>().text = "Гильдия: "; break;
            case (1): GG.GetComponent<Text>().text = "Guild: "; break;
        }
        switch (frak)
        {
            case (0):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text += "Неитралы"; break;
                    case (1): GG.GetComponent<Text>().text += "noname"; break;
                }
                break;
            case (1):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text += "Охотники"; break;
                    case (1): GG.GetComponent<Text>().text += "Hunter"; break;
                }
                break;
            case (2):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text += "Воры"; break;
                    case (1): GG.GetComponent<Text>().text += "Thief"; break;
                }
                break;
            case (3):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text += "Войны"; break;
                    case (1): GG.GetComponent<Text>().text += "Warior"; break;
                }
                break;
            case (4):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text += "Ополченцы"; break;
                    case (1): GG.GetComponent<Text>().text += "Civilian"; break;
                }
                break;
            case (5):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text += "Работорговцы"; break;
                    case (1): GG.GetComponent<Text>().text += "Slave"; break;
                }
                break;
            case (6):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text += "Дикари"; break;
                    case (1): GG.GetComponent<Text>().text += "Wild"; break;
                }
                break;
            case (7):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text += "Торговая гильдия"; break;
                    case (1): GG.GetComponent<Text>().text += "Traider"; break;
                }
                break;
            case (8):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text += "Инжинеры"; break;
                    case (1): GG.GetComponent<Text>().text += "Engine"; break;
                }
                break;
            case (9):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text += "Падальщики"; break;
                    case (1): GG.GetComponent<Text>().text += "Gull"; break;
                }
                break;
            case (10):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text += "Наемники"; break;
                    case (1): GG.GetComponent<Text>().text += "HeadHunter"; break;
                }
                break;
            case (11):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text += "Роставщики"; break;
                    case (1): GG.GetComponent<Text>().text += "Cash"; break;
                }
                break;
        }
    }



    public void FrakP()
    {
        frak++;
        if(frak > 11)
        {
            frak = 0;
        }
        frakSuport();
        
    }
    public void FrakM()
    {
        frak--;
        if (frak < 0)
        {
            frak = 11;
        }
        frakSuport();
    }

    public void SwithFrak()
    {
        
        download();
        /*
          switch (frak)
        {
            case (0):
                sde.frak = "noname";//гильдия
                break;
            case (1):
                sde.frak = "Hunter";//охотники
                break;
            case (2):
                sde.frak = "Thief";//Воры
                break;
            case (3):
                sde.frak = "Knight";//Войны
                break;
            case (4):
                sde.frak = "Civilian";//Ополченцы
                break;
            case (5):
                sde.frak = "Slave";//Работорговцы
                break;
            case (6):
                sde.frak = "Wild";//Дикари
                break;
            case (7):
                sde.frak = "Traider";//Торговая гильдия
                break;
            case (8):
                sde.frak = "Engine";//Инжинеры
                break;
            case (9):
                sde.frak = "Gull";//Падальщики
                break;
            case (10):
                sde.frak = "HeadHunter";//Наемники
                break;
            case (11):
                sde.frak = "Cash";//Роставщики
                break;
        }
         */
        switch (frak)
        {
            case (0):
                frakname = "noname";//гильдия
                break;
            case (1):
                frakname = "Hunter";//охотники
                break;
            case (2):
                frakname = "Thief";//Воры
                break;
            case (3):
                frakname = "Knight";//Войны
                break;
            case (4):
                frakname = "Civilian";//Ополченцы
                break;
            case (5):
                frakname = "Slave";//Работорговцы
                break;
            case (6):
                frakname = "Wild";//Дикари
                break;
            case (7):
                frakname = "Traider";//Торговая гильдия
                break;
            case (8):
                frakname = "Engine";//Инжинеры
                break;
            case (9):
                frakname = "Gull";//Падальщики
                break;
            case (10):
                frakname = "HeadHunter";//Наемники
                break;
            case (11):
                frakname = "Cash";//Роставщики
                break;
        }

        LoadCard();
        PLoadCard();
        LoadColod();

        suportfraktion();
    }



   
    private void LoadCard()//загрузка карт
    {

        if (ret == 0)
        {
            cod = path + "/cold/" + sde.names + ".json";
            sde = JsonUtility.FromJson<colodes>(File.ReadAllText(cod));
            reff = sde.size;

            cod = path + "/colods/general.json";
            sde = JsonUtility.FromJson<colodes>(File.ReadAllText(cod));
        }
        if (sde.bibsize != 0)
        {
            ret++;
            cod = path + "/cold/" + sde.names + "/" + ret + ".json";//шаблон записывается по номеру
            if(File.Exists(cod))
            {
                sg = JsonUtility.FromJson<cardessss>(File.ReadAllText(cod));

                var ta = Instantiate(bv, new Vector3(0, 0, 0), Quaternion.identity);//вызываемый обект
                ta.transform.SetParent(doll1.transform);
                ta.name = "card" + ret;
                ta.GetComponent<card>().id = sg.num;
                ta.GetComponent<card>().neme = sg.names;
                ta.GetComponent<card>().dam = sg.dam;
                ta.GetComponent<card>().ddam = sg.ddam;
                ta.GetComponent<card>().hp = sg.hp;
                ta.GetComponent<card>().clas = "Prof";


                ta.GetComponent<card>().avatar = sg.Imagesss;

                ta.GetComponent<card>().slotName.GetComponent<Text>().text = sg.names;//переправить
                ta.GetComponent<card>().broe = sg.broe;
                ta.GetComponent<card>().crush = sg.crush;
                ta.GetComponent<card>().shilds = sg.shilds;
                ta.GetComponent<card>().shild = sg.shild;
                ta.GetComponent<card>().ship = sg.ship;
                ta.GetComponent<card>().def = sg.def;
                ta.GetComponent<card>().spas = sg.spas;
                ta.GetComponent<card>().sal = sg.sal;
                ta.GetComponent<card>().toh = sg.toh;
                ta.GetComponent<card>().zap = sg.zap;
                ta.GetComponent<card>().mobi = sg.mobi;
                ta.GetComponent<card>().izv = sg.izv;
                ta.GetComponent<card>().ura = sg.ura;
                ta.GetComponent<card>().mane = sg.mana;
                //sg.sizes = sizes;
                ta.GetComponent<card>().sp1 = sg.sp1;
                ta.GetComponent<card>().sp2 = sg.sp2;
                ta.GetComponent<card>().sp3 = sg.sp3;
                ta.GetComponent<card>().sp4 = sg.sp4;
                ta.GetComponent<card>().sp5 = sg.sp5;
                if (ta.GetComponent<card>().sp1 != 0) { reg++; }
                if (ta.GetComponent<card>().sp2 != 0) { reg++; }
                if (ta.GetComponent<card>().sp3 != 0) { reg++; }
                if (ta.GetComponent<card>().sp4 != 0) { reg++; }
                if (ta.GetComponent<card>().sp5 != 0) { reg++; }

                GG = GameObject.Find("costSpell");
                GG.name = "costSpell" + ret;
                GG.GetComponent<Text>().text = "" + reg;

                GG = GameObject.Find("NomName");
                GG.name = "NomName" + ret;
                GG.GetComponent<Text>().text = "№  " + ret;

                reg = 0;
               
            }
            if (reff <= ret)
            {
                reff = 0;
                ret = 0;
                GG = null;
            }
            else { LoadCard(); }
        }
        
    }

    private void PLoadCard()//загрузка карт
    {
        //получение размера библиотеки


        if(ret == 0)
        {
            Debug.Log(sde.frak);
            Debug.Log(frakname);
            if(sde.frak != frakname)
            {

                cod = path + "/cold/" + frakname + ".json";
            }
            else
            {

                cod = path + "/cold/" + sde.frak + ".json";
            }
            sde = JsonUtility.FromJson<colodes>(File.ReadAllText(cod));
            reff = sde.size;

            cod = path + "/colods/general.json";
            sde = JsonUtility.FromJson<colodes>(File.ReadAllText(cod));
        }

        ret++;
        //cod = path + "/cold/" + sde.names + "/" + ret + ".json";//шаблон записывается по номеру
        
        if (sde.frak != frakname)
        {

            cod = path + "/cold/" + frakname + "/" + ret + ".json";
        }
        else
        {

            cod = path + "/cold/" + sde.frak + "/" + ret + ".json";//шаблон записывается по номеру
        }
        if (File.Exists(cod))
        {

            sg = JsonUtility.FromJson<cardessss>(File.ReadAllText(cod));

            var ta = Instantiate(bv, new Vector3(0, 0, 0), Quaternion.identity);//вызываемый обект
            ta.transform.SetParent(doll3.transform);
            ta.name = "pcard" + ret;
            ta.GetComponent<Image>().color = new Color(255 / 255.0f, 211 / 255.0f, 61 / 255.0f);//золотой
            ta.GetComponent<card>().id = sg.num;
            ta.GetComponent<card>().neme = sg.names;
            ta.GetComponent<card>().dam = sg.dam;
            ta.GetComponent<card>().ddam = sg.ddam;
            ta.GetComponent<card>().hp = sg.hp;
            ta.GetComponent<card>().clas = "PProf";


            ta.GetComponent<card>().avatar = sg.Imagesss;

            ta.GetComponent<card>().slotName.GetComponent<Text>().text = sg.names;//переправить
            ta.GetComponent<card>().broe = sg.broe;
            ta.GetComponent<card>().crush = sg.crush;
            ta.GetComponent<card>().shilds = sg.shilds;
            ta.GetComponent<card>().shild = sg.shild;
            ta.GetComponent<card>().ship = sg.ship;
            ta.GetComponent<card>().def = sg.def;
            ta.GetComponent<card>().spas = sg.spas;
            ta.GetComponent<card>().sal = sg.sal;
            ta.GetComponent<card>().toh = sg.toh;
            ta.GetComponent<card>().zap = sg.zap;
            ta.GetComponent<card>().mobi = sg.mobi;
            ta.GetComponent<card>().izv = sg.izv;
            ta.GetComponent<card>().ura = sg.ura;
            ta.GetComponent<card>().mane = sg.mana;
            //sg.sizes = sizes;
            ta.GetComponent<card>().sp1 = sg.sp1;
            ta.GetComponent<card>().sp2 = sg.sp2;
            ta.GetComponent<card>().sp3 = sg.sp3;
            ta.GetComponent<card>().sp4 = sg.sp4;
            ta.GetComponent<card>().sp5 = sg.sp5;
            if (ta.GetComponent<card>().sp1 != 0) { reg++; }
            if (ta.GetComponent<card>().sp2 != 0) { reg++; }
            if (ta.GetComponent<card>().sp3 != 0) { reg++; }
            if (ta.GetComponent<card>().sp4 != 0) { reg++; }
            if (ta.GetComponent<card>().sp5 != 0) { reg++; }

            GG = GameObject.Find("costSpell");
            GG.name = "costSpell" + ret;
            GG.GetComponent<Text>().text = "" + reg;

            GG = GameObject.Find("NomName");
            GG.name = "NomName" + ret;
            GG.GetComponent<Text>().text = "№  " + ret;

            reg = 0;
        }
        if (reff <= ret)
        {
            ret = 0;
            GG = null;


           
        }
        else { PLoadCard(); }
    }




    private void LoadColod()//загрузка колоды
    {
        reg++;

        cod = path + "/colods/" + sde.tayp + "/" + sde.cold + "/" + reg + ".json";//шаблон записывается по номеру
        if (!File.Exists(cod)) { sd.cardes = 0; }//это времнно?
        else
        {
            sd = JsonUtility.FromJson<colod>(File.ReadAllText(cod));
        }
        

        if (gp.pcard >= reg)
        {
            //происходи выбор режима игры (потом переписать) //сделать портацию колод  
            

            if (sd.cardes == 0) { cod = path + "/colods/ErorrColod/rest/0.json"; }
            else
            {
                if (sde.frak != frakname)
                {

                    cod = path + "/cold/" + frakname + "/" + sd.cardes + ".json";
                }
                else
                {

                    cod = path + "/cold/" + sde.frak + "/" + sd.cardes + ".json";//шаблон записывается по номеру
                }
            }


            //Debug.Log(cod);
            sg = JsonUtility.FromJson<cardessss>(File.ReadAllText(cod));

            if(sg.names ==  null)
            {
                sg.names = "Раб";
            }
            //Debug.Log(sg.names);
            //Debug.Log(sg.hp);

            var ta = Instantiate(av, new Vector3(0, 0, 0), Quaternion.identity);//вызываемый обект
            ta.transform.SetParent(doll.transform);
            ta.name = "colod" + reg;
            ta.GetComponent<Image>().color = new Color(255 / 255.0f, 211 / 255.0f, 61 / 255.0f);//золотой

            ta.GetComponent<card>().id = sg.num;
            ta.GetComponent<card>().neme = sg.names;
            ta.GetComponent<card>().dam = sg.dam;
            ta.GetComponent<card>().ddam = sg.ddam;
            ta.GetComponent<card>().hp = sg.hp;
            ta.GetComponent<card>().clas = "pcard";

            ta.GetComponent<card>().avatar = sg.Imagesss;

            ta.GetComponent<card>().slotName.GetComponent<Text>().text = sg.names;//переправить
            ta.GetComponent<card>().broe = sg.broe;
            ta.GetComponent<card>().crush = sg.crush;
            ta.GetComponent<card>().shilds = sg.shilds;
            ta.GetComponent<card>().shild = sg.shild;
            ta.GetComponent<card>().ship = sg.ship;
            ta.GetComponent<card>().def = sg.def;
            ta.GetComponent<card>().spas = sg.spas;
            ta.GetComponent<card>().sal = sg.sal;
            ta.GetComponent<card>().toh = sg.toh;
            ta.GetComponent<card>().zap = sg.zap;
            ta.GetComponent<card>().mobi = sg.mobi;
            ta.GetComponent<card>().izv = sg.izv;
            ta.GetComponent<card>().ura = sg.ura;
            ta.GetComponent<card>().mane = sg.mana;
            //sg.sizes = sizes;
            ta.GetComponent<card>().sp1 = sg.sp1;
            ta.GetComponent<card>().sp2 = sg.sp2;
            ta.GetComponent<card>().sp3 = sg.sp3;
            ta.GetComponent<card>().sp4 = sg.sp4;
            ta.GetComponent<card>().sp5 = sg.sp5;

            //Debug.Log(sg.names);



        }
        else if (gp.ccard >= reg)
        {
            
            
            cod = path + "/cold/" + sde.names + "/" + sd.cardes + ".json";//шаблон записывается по номеру
            if (!File.Exists(cod))
            {

                cod = path + "/colods/ErorrColod/rest/0.json";
               
            }
            sg = JsonUtility.FromJson<cardessss>(File.ReadAllText(cod));

            cod = path + "/colods/" + sde.tayp + "/" + sde.cold + "/" + ret + ".json";//шаблон записывается по номеру

                var ta = Instantiate(av, new Vector3(0, 0, 0), Quaternion.identity);//вызываемый обект
                ta.transform.SetParent(doll.transform);
                ta.name = "colod" + reg;

                ta.GetComponent<Image>().color = new Color(205 / 255.0f, 205 / 255.0f, 205 / 255.0f);//серебренный

                ta.GetComponent<card>().id = sg.num;
                ta.GetComponent<card>().neme = sg.names;
                ta.GetComponent<card>().dam = sg.dam;
                ta.GetComponent<card>().ddam = sg.ddam;
                ta.GetComponent<card>().hp = sg.hp;
            ta.GetComponent<card>().clas = "card";



            ta.GetComponent<card>().avatar = sg.Imagesss;


                ta.GetComponent<card>().slotName.GetComponent<Text>().text = sg.names;//переправить
                ta.GetComponent<card>().broe = sg.broe;
                ta.GetComponent<card>().crush = sg.crush;
                ta.GetComponent<card>().shilds = sg.shilds;
                ta.GetComponent<card>().shild = sg.shild;
                ta.GetComponent<card>().ship = sg.ship;
                ta.GetComponent<card>().def = sg.def;
                ta.GetComponent<card>().spas = sg.spas;
                ta.GetComponent<card>().sal = sg.sal;
                ta.GetComponent<card>().toh = sg.toh;
                ta.GetComponent<card>().zap = sg.zap;
                ta.GetComponent<card>().mobi = sg.mobi;
                ta.GetComponent<card>().izv = sg.izv;
                ta.GetComponent<card>().ura = sg.ura;
                ta.GetComponent<card>().mane = sg.mana;
                //sg.sizes = sizes;
                ta.GetComponent<card>().sp1 = sg.sp1;
                ta.GetComponent<card>().sp2 = sg.sp2;
                ta.GetComponent<card>().sp3 = sg.sp3;
                ta.GetComponent<card>().sp4 = sg.sp4;
                ta.GetComponent<card>().sp5 = sg.sp5;
           



            //ta.GetComponent<Image>().color = new Color(79 / 255.0f, 165 / 255.0f, 63 / 255.0f);//красный
            //ta.GetComponent<Image>().color = new Color(81 / 255.0f, 92 / 255.0f, 255 / 255.0f);//синий
            //ta.GetComponent<Image>().color = new Color(255 / 255.0f, 211 / 255.0f, 61 / 255.0f);//золотой
            //ta.GetComponent<Image>().color = new Color(205 / 255.0f, 205 / 255.0f, 205 / 255.0f);//серебренный
        }
        else { reg = gp.ccard; }

        if (gp.ccard == reg)
        {
            reg = 0;
        }
        else { LoadColod(); }


       
    }
    public void ReLoadColod()//перзагрузка
    {
        switch (sde.frak)
        {
            case ("noname"):
                frak = 0; //гильдия
                break;
            case ("Hunter"):
                frak = 1; //охотники
                break;
            case ("Thief"):
                frak = 2;//Воры
                break;
            case ("Knight"):
                frak = 3;//Войны
                break;
            case ("Civilian"):
                frak = 4;//Ополченцы
                break;
            case ("Slave"):
                frak = 5;//Работорговцы
                break;
            case ("Wild"):
                frak = 6;//Дикари
                break;
            case ("Traider"):
                frak = 7;//Торговая гильдия
                break;
            case ("Engine"):
                frak = 8;//Инжинеры
                break;
            case ("Gull"):
                frak = 9;//Падальщики
                break;
            case ("HeadHunter"):
                frak = 10;//Наемники
                break;
            case ("Cash"):
                frak = 11;//Роставщики
                break;
        }
        frakname = sde.frak;
        frakSuport();
        //if(ret == 0) { download(); }
        Debug.Log(sde.frak);
        download();
        //ret++;
        PLoadCard();
        LoadCard();
        LoadColod();
        /*
         if (sde.bibsize > ret)
        {

            //библотека//фракция//колода
            cod = path + "/colods/" + sde.tayp + "/" + sde.cold + "/" + ret + ".json";//шаблон записывается по номеру

            var ta = Instantiate(av, new Vector3(0, 0, 0), Quaternion.identity);//вызываемый обект
            ta.transform.SetParent(doll.transform);
            ta.name = "card" + ret;



            ReBib();
        }
        else { ret = 0; }
         
         */




    }



    public void UpColod()
    {

        reg++;

        //cod = path + "/colods/" + sde.tayp + "/" + sde.cold + "/" + reg + ".json";//шаблон записывается по номеру
       // sd = JsonUtility.FromJson<colod>(File.ReadAllText(cod));

        if (gp.pcard >= reg)
        {
            //происходи выбор режима игры (потом переписать) //сделать портацию колод  

            GG = GameObject.Find("colod" + reg);
            sd.cardes = GG.GetComponent<card>().id;


            if (sd.cardes == 0) { cod = path + "/colods/ErorrColod/rest/0.json"; }
            else
            {
                if (sde.frak != frakname)
                {

                    cod = path + "/cold/" + frakname + "/" + sd.cardes + ".json";
                }
                else
                {

                    cod = path + "/cold/" + sde.frak + "/" + sd.cardes + ".json";//шаблон записывается по номеру
                }
            }


            //Debug.Log(cod);
            sg = JsonUtility.FromJson<cardessss>(File.ReadAllText(cod));
            
            
            GG.GetComponent<card>().neme = sg.names;
            GG.GetComponent<card>().dam = sg.dam;
            GG.GetComponent<card>().ddam = sg.ddam;
            GG.GetComponent<card>().hp = sg.hp;

            GG.GetComponent<card>().avatar = sg.Imagesss;

            GG.GetComponent<card>().slotName.GetComponent<Text>().text = sg.names;//переправить
            GG.GetComponent<card>().broe = sg.broe;
            GG.GetComponent<card>().crush = sg.crush;
            GG.GetComponent<card>().shilds = sg.shilds;
            GG.GetComponent<card>().shild = sg.shild;
            GG.GetComponent<card>().ship = sg.ship;
            GG.GetComponent<card>().def = sg.def;
            GG.GetComponent<card>().spas = sg.spas;
            GG.GetComponent<card>().sal = sg.sal;
            GG.GetComponent<card>().toh = sg.toh;
            GG.GetComponent<card>().zap = sg.zap;
            GG.GetComponent<card>().mobi = sg.mobi;
            GG.GetComponent<card>().izv = sg.izv;
            GG.GetComponent<card>().ura = sg.ura;
            GG.GetComponent<card>().mane = sg.mana;
            //sg.sizes = sizes;
            GG.GetComponent<card>().sp1 = sg.sp1;
            GG.GetComponent<card>().sp2 = sg.sp2;
            GG.GetComponent<card>().sp3 = sg.sp3;
            GG.GetComponent<card>().sp4 = sg.sp4;
            GG.GetComponent<card>().sp5 = sg.sp5;

            GG.GetComponent<card>().statys();
            //Debug.Log(sg.names);



        }
        else if (gp.ccard >= reg)
        {
            GG = GameObject.Find("colod" + reg);
            sd.cardes = GG.GetComponent<card>().id;


            cod = path + "/cold/" + sde.names + "/" + sd.cardes + ".json";//шаблон записывается по номеру
            if (!File.Exists(cod))
            {

                cod = path + "/colods/ErorrColod/rest/0.json";

            }
            sg = JsonUtility.FromJson<cardessss>(File.ReadAllText(cod));

            cod = path + "/colods/" + sde.tayp + "/" + sde.cold + "/" + ret + ".json";//шаблон записывается по номеру

            
            
            GG.GetComponent<card>().neme = sg.names;
            GG.GetComponent<card>().dam = sg.dam;
            GG.GetComponent<card>().ddam = sg.ddam;
            GG.GetComponent<card>().hp = sg.hp;



            GG.GetComponent<card>().avatar = sg.Imagesss;


            GG.GetComponent<card>().slotName.GetComponent<Text>().text = sg.names;//переправить
            GG.GetComponent<card>().broe = sg.broe;
            GG.GetComponent<card>().crush = sg.crush;
            GG.GetComponent<card>().shilds = sg.shilds;
            GG.GetComponent<card>().shild = sg.shild;
            GG.GetComponent<card>().ship = sg.ship;
            GG.GetComponent<card>().def = sg.def;
            GG.GetComponent<card>().spas = sg.spas;
            GG.GetComponent<card>().sal = sg.sal;
            GG.GetComponent<card>().toh = sg.toh;
            GG.GetComponent<card>().zap = sg.zap;
            GG.GetComponent<card>().mobi = sg.mobi;
            GG.GetComponent<card>().izv = sg.izv;
            GG.GetComponent<card>().ura = sg.ura;
            GG.GetComponent<card>().mane = sg.mana;
            //sg.sizes = sizes;
            GG.GetComponent<card>().sp1 = sg.sp1;
            GG.GetComponent<card>().sp2 = sg.sp2;
            GG.GetComponent<card>().sp3 = sg.sp3;
            GG.GetComponent<card>().sp4 = sg.sp4;
            GG.GetComponent<card>().sp5 = sg.sp5;

            GG.GetComponent<card>().statys();



            //ta.GetComponent<Image>().color = new Color(79 / 255.0f, 165 / 255.0f, 63 / 255.0f);//красный
            //ta.GetComponent<Image>().color = new Color(81 / 255.0f, 92 / 255.0f, 255 / 255.0f);//синий
            //ta.GetComponent<Image>().color = new Color(255 / 255.0f, 211 / 255.0f, 61 / 255.0f);//золотой
            //ta.GetComponent<Image>().color = new Color(205 / 255.0f, 205 / 255.0f, 205 / 255.0f);//серебренный
        }
        else { reg = gp.ccard; }

        if (gp.ccard == reg)
        {
            reg = 0;
        }
        else { UpColod(); }
















    }







    private void ReBib()
    {
        if (sde.size > ret)
        {
            ret++;
            //библотека//фракция//колода
            //cod = path + "/colods/" + sde.tayp + "/" + sde.cold + "/" + ret + ".json";//шаблон записывается по номеру

            GG = GameObject.Find("SetBibel");
            var ta = Instantiate(GenColod, new Vector3(0, 0, 0), Quaternion.identity);//вызываемый обект
            ta.transform.SetParent(GG.transform);
            ta.name = "Bib" + ret;



            ReBib();
        }
        else { ret = 0; }
    }



    private void ErorrColod()//аварийная колода
    {
        /*
         вызов аварийной колоды из нашего набора
         берется библотека режима,  подгружается безфракционаая фракция
         
        храним количество библиотек

        храним количесвто колод в библиотеках
        колоды, имеют теги, которые указывают на заданную фракцию

         */


        //cod = path + "/colods/ErorrColod/"+ sde.tayp +"/rest.json";


        //cod = path + "/colods/" + sde.tayp + "/" + sde.cold + ".json";
        //gp.tag = sde.tayp;
        if(control == false)
        {
            if (ret == 0)
            {
                cod = path + "/colods/ErorrColod/rest.json";

                if (File.Exists(cod))
                {

                    gp = JsonUtility.FromJson<genco>(File.ReadAllText(cod));
                }
                else { print("отсутсвует шаблон, произвести установку аварийной колоды"); }//SavColod(); }

                reg++;





                sde.cold = "colod" + reg;
                cod = path + "/colods/" + sde.tayp + "/" + sde.cold + ".json";

                if (File.Exists(cod)) { ErorrColod(); }
                Debug.Log(cod);
                File.WriteAllText(cod, JsonUtility.ToJson(gp));

                cod = path + "/colods/" + sde.tayp + "/" + sde.cold + "/";
                if (!Directory.Exists(cod)) { Debug.Log(cod); Directory.CreateDirectory(cod); }




                cod = path + "/colods/" + sde.tayp + "/gen_colod.json";
                sd.cardes++;
                //sd.cardes = sd.cardes + 1;
                File.WriteAllText(cod, JsonUtility.ToJson(sd));
                reg = 0;
            }
            ret++;

            //cod = path + "/colods/ErorrColod/" + sde.tayp + "/rest/" + ret + ".json";
            cod = path + "/colods/ErorrColod/rest/" + ret + ".json";
            sd = JsonUtility.FromJson<colod>(File.ReadAllText(cod));

            cod = path + "/colods/" + sde.tayp + "/" + sde.cold + "/" + ret + ".json";
            File.WriteAllText(cod, JsonUtility.ToJson(sd));

            //Debug.Log(ret);
           // Debug.Log(gp.ccard);
            if (ret < gp.ccard) { ErorrColod(); }
            else
            {
                control = true;

                cod = path + "/colods/" + sde.tayp + "/gen_colod.json";
                sd = JsonUtility.FromJson<colod>(File.ReadAllText(cod));
                Debug.Log(sd.cardes);
                //ret = 0;
                //File.WriteAllText(cod, JsonUtility.ToJson(sde));
            }
        }
        
            
            
            /*
            ret++;

            //fdfhbqysq ds,hjc

            if (ret < gp.ccard)
            {

                cod = path + "/colods/ErorrColod/" + sde.tayp + "/rest/" + ret + ".json";


                sd = JsonUtility.FromJson<colod>(File.ReadAllText(cod));

                var ta = Instantiate(av, new Vector3(0, 0, 0), Quaternion.identity);//вызываемый обект
                ta.transform.SetParent(doll.transform);
                ta.name = "colod" + ret;

                ta.GetComponent<Image>().color = new Color(205 / 255.0f, 205 / 255.0f, 205 / 255.0f);//серебренный



                ErorrColod();
            }

        */
       

    }


    public void swithCard()
    {
        //переключение нашей и пользовательской библиотеки
        if(doll4.active == true){ doll4.active = false; }
        else { doll4.active = true; }
        


    }










    private void download()//выгрузка библотеки
    {
        if(ret == 0)
        {
            if(doll4.active == false)
            {
                doll4.active = true;
            }
            
                cod = path + "/cold/" + sde.frak + ".json";
            sde = JsonUtility.FromJson<colodes>(File.ReadAllText(cod));
            reff = sde.size;

            cod = path + "/colods/general.json";
            sde = JsonUtility.FromJson<colodes>(File.ReadAllText(cod));

            cod = path + "/cold/" + sde.names + ".json";
            sde = JsonUtility.FromJson<colodes>(File.ReadAllText(cod));
            reg = sde.size;


            cod = path + "/colods/general.json";
            sde = JsonUtility.FromJson<colodes>(File.ReadAllText(cod));
            
        }
        ret++;
        
        GG = GameObject.Find("card" + ret);
        if (GG != null)
        {
            Destroy(GG);
            Debug.Log(GG);
        }
        GG = GameObject.Find("pcard" + ret);
        if (GG != null)
        {
            Destroy(GG);
        }

        GG = GameObject.Find("colod" + ret);
        if (GG != null)
        {
            Destroy(GG);
        }

        //if (ret >= sde.bibsize) { ret = 0; } else { download(); }
        if ((ret >= reg) & (ret >= reff) & (ret >= gp.ccard)) {
            Debug.Log(reg);
            Debug.Log(reff);
            Debug.Log(gp.ccard);
            Debug.Log(ret);

            ret = 0; reg = 0; reff = 0; } else { download(); }

        //if ((ret >= sde.bibsize) &(ret >= gp.ccard)) { ret = 0; reg = 0; reff = 0; } else { download(); }
    }
    
}
public class colodes
{
    public int bibsize;//количество карт

    

    public string names;//название библиотеки
    public string tayp;//библиотека
    public string frak;//фракиця
    public string cold;//колода
    public int size;//количестов библиотек

}
public class colod
{
    public int cardes;

    /*
    public string names;

    public int card1;
        public int card2;
        public int card3;
        public int card4;
        public int card5;
        public int card6;
        public int card7;
        public int card8;
        public int card9;
        public int card10;
        public int card11;
        public int card12;
        public int card13;
        public int card14;
        public int card15;
        public int card16;
        public int card17;
        public int card18;
        public int card19;
        public int card20;
        public int card21;
        public int card22;
        public int card23;
        public int card24;
        public int card25;
        */
}
public class genco
{
    public string names;//название заданной колоды
    public string tag;//фракция

    public int pcard;//админские
    public int ccard;//пользовательские
    //public int size;//количесвто библиотек
}
public class cardessss
{
    public string Imagesss;

    public string names;

    public int num;//номер объекта

    public int dam;//Ближний бой
    public int ddam;//Дальний бой
    public int broe;//Бронебойность
    public int crush;//Бронелом

    public int shilds;//размер щиты
    public int shild;//щиты
    public int ship;//шипы
    public int def;//броня


    public int spas;//спасение
    public int sal;//салто
    public int toh;//точность
    public int zap;//запугивание


    public int mobi;//перемещение
    public int izv;//изворотливость
    public int ura;//куворок

    public int hp;//жизнь
    public int mana;

    //public int sizes;//количество спосбностей

    public int sp1;
    public int sp2;
    public int sp3;
    public int sp4;
    public int sp5;
}