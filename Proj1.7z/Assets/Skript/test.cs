﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using System.IO;

public class test : MonoBehaviour
{
    private string path;
    private string cod;
    private gencola sc = new gencola(); 
    // Start is called before the first frame update
    void Start()
    {

        path = Path.Combine(Application.dataPath);
        cod = path + "/cold/generalst.json";
        //sc.names = ""; 

        File.WriteAllText(cod, JsonUtility.ToJson(sc));
    }

    // Update is called once per frame
    //void Update()
    //{
        
    //}
}

public class gencola
{
    public string names = "cold1";//название заданной колоды

}