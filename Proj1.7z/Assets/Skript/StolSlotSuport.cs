﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using UnityEngine.UI;
using UnityEngine.EventSystems;

public class StolSlotSuport : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    public GameObject canvas;
    public int team;
    public GameObject Gen;//основа
    public GameObject Slot;//неитраль
    public GameObject SlotA;//слот альтенатива

    public string clas = "SlotSuport";

    public bool turn; //указатель да перед или зад
    // Start is called before the first frame update
    void Start()
    {
        canvas = GameObject.Find("Canvas");
        team = Gen.GetComponent<StolSlot>().team;
    }
    

    public void OnPointerEnter(PointerEventData eventData)
    {
        if(Gen.GetComponent<StolSlot>().BObj == null)
        {
            
                Gen.GetComponent<StolSlot>().AObj.transform.SetParent(SlotA.transform);
            canvas.GetComponent<stol>().selector = gameObject;
            canvas.GetComponent<stol>().selClas = clas;
            //добавить сточку ограничтель для активации спец режима работы

        }
        //Debug.Log("Selest   " + gameObject.name);
        
        //if (canvas.GetComponent<GeneralSetting>().Mod == "Colod") {
        //    canvas.GetComponent<stol>().selector = gameObject;
        //}


    }
    public void OnPointerExit(PointerEventData eventData)
    {
        if(Gen.GetComponent<StolSlot>().BObj != null)
        {

            Gen.GetComponent<StolSlot>().AObj.transform.SetParent(Gen.transform);
            Gen.GetComponent<StolSlot>().BObj.transform.SetParent(Gen.transform);
        }
        else
        {
            Gen.GetComponent<StolSlot>().AObj.transform.SetParent(Slot.transform);
        }
        canvas.GetComponent<stol>().selector = null;
        canvas.GetComponent<stol>().selClas = null;

        //canvas.GetComponent<stol>().selector = null;
    }




}
