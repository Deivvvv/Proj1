﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpelSkroll : MonoBehaviour
{

    public GameObject general;
    private int lang;

    public string name;//имя
    public int sell;//стимость
    public int num;//размер способности
    public string tayp;//тип способности
    public int id;//номер



    public void skrol()
        {
        switch (id)
        {
            case (1):
                switch (lang)
                {
                    case (0):

                        name = "Скрыться из виду";
                        break;
                    case (1):

                        name = "Hide out of sight";
                        break;

                    default:
                        break;
                }
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (2):
                name = "Маскировка";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (3):
                name = "Удар в спину";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (4):
                name = "Двиерсия";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (5):
                name = "Подкуп";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (6):
                name = "Диверсия поставок";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (7):
                name = "Ликвидация";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (8):
                name = "Мастерство скрытности";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (9):
                name = "Выкрасть контраки";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (10):
                name = "Разведка";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (11):
                name = "Парирование";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (12):
                name = "Мастер фехтования";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (13):
                name = "Обезоруживание";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (14):
                name = "Болевой захват";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (15):
                name = "Таунт";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (16):
                name = "Телохранитель";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (17):
                name = "Имунитет к оглушению";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (18):
                name = "Всадник";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (19):
                name = "Тренерованный конь";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (20):
                name = "Работорговец";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (21):
                name = "Блок";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (22):
                name = "Инжинер";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (23):
                name = "Абсолютный шит";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (24):
                name = "Отражение";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (25):
                name = "Поспешность";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (26):
                name = "Рывок";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (27):
                name = "Натиск";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (28):
                name = "Двойной удар";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (29):
                name = "Удвоенный урон";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (30):
                name = "Скорострельность";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (31):
                name = "Яд";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (32):
                name = "Паралитический яд";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (33):
                name = "Медленый яд";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (34):
                name = "Ускор/замед яда //Поведелитель яда";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (35):
                name = "Первый удар";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (36):
                name = "Быстрый замах";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (37):
                name = "Микири";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (38):
                name = "Выстрел в упор";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (39):
                name = "Обман";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (40):
                name = "Навес";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (41):
                name = "Снайпер";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (42):
                name = "Пронзание";
                sell = 2;
                num = 1;
                tayp = "non";
                break;
            case (43):
                name = "Разгон";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (44):
                name = "Разбег";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (45):
                name = "Отвлечение";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (46):
                name = "Дуэль";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (47):
                name = "Лечение";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (48):
                name = "Стойкость";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (49):
                name = "Антидот";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (50):
                name = "Оглушение";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (51):
                name = "Ослепление";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (52):
                name = "Паралич";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (53):
                name = "Подточить";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (54):
                name = "Строить";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (55):
                name = "Ищейка";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (56):
                name = "Обеждвиживание";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (57):
                name = "Удушение";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (58):
                name = "Совместная атака";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (59):
                name = "Заслон";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (60):
                name = "Построиться";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (61):
                name = "Совместное строительство";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (62):
                name = "Отступление";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (63):
                name = "Построиться";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            case (64):
                name = "Топот";
                sell = 3;
                num = 1;
                tayp = "non";
                break;
            default:
                Debug.Log("Нет такой способности №"  + id);
                id = 0;
                name = "";
                sell = 0;
                num = 0;
                tayp = "";
                break;
        }

    }
     /*структура процедуры
      * отправляем номер  спосбноти в библотеку
      * обращаемся к библотеке и вызываем метод поиска в ней
      * забираем полученные данные из библотеки
      */ 


    //   лист способностей и вес из этого вытекающее
    void Start()
    {
        general = GameObject.Find("Canvas");
        lang = general.GetComponent<GeneralSetting>().Language;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
   

}
