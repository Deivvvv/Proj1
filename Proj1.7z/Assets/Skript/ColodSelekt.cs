﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ColodSelekt : MonoBehaviour
{
    public string name;
    public int frak;
    public int id;
    public GameObject gname;
    public GameObject gfrak;
    public GameObject GG;
    private int Lang;

    // Start is called before the first frame update
    void Start()
    {
        //gname.GetComponent<Text>().text = name;
        GG = GameObject.Find("Canvas");
        Lang = GG.GetComponent<GeneralSetting>().Language;
    }

    public void but()
    {
        GG = GameObject.Find("Canvas");
        GG.GetComponent<BibLoad>().frak = frak;

        GG.GetComponent<BibLoad>().boof = "colod" + id;
        GG.GetComponent<BibLoad>().bone(); 

        GG.GetComponent<BibLoad>().SwithFrak();
        GG = GameObject.Find("StColod");
        GG.GetComponent<Text>().text ="Колода: "+ name;
        GG = GameObject.Find("StFrak");
        switch (Lang)
        {
            case (0): GG.GetComponent<Text>().text = "Гильдия: ";break;
            case (1): GG.GetComponent<Text>().text = "Guild: "; break;
        }
        switch (frak)
        {
            case (0):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text += "Неитралы"; break;
                    case (1): GG.GetComponent<Text>().text += "noname"; break;
                }
                break;
            case (1):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text += "Охотники"; break;
                    case (1): GG.GetComponent<Text>().text += "Hunter"; break;
                }
                break;
            case (2):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text += "Воры"; break;
                    case (1): GG.GetComponent<Text>().text += "Thief"; break;
                }
                break;
            case (3):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text += "Войны"; break;
                    case (1): GG.GetComponent<Text>().text += "Warior"; break;
                }
                break;
            case (4):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text += "Ополченцы"; break;
                    case (1): GG.GetComponent<Text>().text += "Civilian"; break;
                }
                break;
            case (5):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text += "Работорговцы"; break;
                    case (1): GG.GetComponent<Text>().text += "Slave"; break;
                }
                break;
            case (6):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text += "Дикари"; break;
                    case (1): GG.GetComponent<Text>().text += "Wild"; break;
                }
                break;
            case (7):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text += "Торговая гильдия"; break;
                    case (1): GG.GetComponent<Text>().text += "Traider"; break;
                }
                break;
            case (8):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text += "Инжинеры"; break;
                    case (1): GG.GetComponent<Text>().text += "Engine"; break;
                }
                break;
            case (9):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text += "Падальщики"; break;
                    case (1): GG.GetComponent<Text>().text += "Gull"; break;
                }
                break;
            case (10):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text += "Наемники"; break;
                    case (1): GG.GetComponent<Text>().text += "HeadHunter"; break;
                }
                break;
            case (11):
                switch (Lang)
                {
                    case (0): GG.GetComponent<Text>().text += "Роставщики"; break;
                    case (1): GG.GetComponent<Text>().text += "Cash"; break;
                }
                break;
        }





    }
    // Update is called once per frame
    void Update()
    {
        
        
    }
}
