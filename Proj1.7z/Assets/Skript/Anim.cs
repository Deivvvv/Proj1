﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Anim : MonoBehaviour
{
    // анимация
    public string ima;//изображение что будет показано
    public int strong;//значение
    public GameObject GG;//место размещения
    //тип анимации
    public int time;//время жизни
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
