﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Nom : MonoBehaviour
{
    public int num;//номер способности
    public string frak;//фракция
    public int select;//счетчик указатель
    //public int sall;//цена
    public GameObject GG;//магазин способностей
    public GameObject can;//обращение к управляющему скрипту
    public GameObject nema;//имя способнотси
    public GameObject sell;//цена способности
    //

    // Start is called before the first frame update
    void Start()
    {
        can = GameObject.Find("genpanel");
       // GG = GameObject.Find("spelmen"); 
    }
   // public void stat()
    //{
    //    sell.GetComponent<Text>().text = sall;
    //}

    public void selct()
    {
        //if(can.GetComponent<basicgenrator>().sele != num)
        //{

           // can.GetComponent<basicgenrator>().sele = num;
            //if(GG != null)
        if (
        (can.GetComponent<basicgenrator>().sp1 != 0) &
        (can.GetComponent<basicgenrator>().sp2 != 0) &
        (can.GetComponent<basicgenrator>().sp3 != 0) &
        (can.GetComponent<basicgenrator>().sp4 != 0) &
        (can.GetComponent<basicgenrator>().sp5 != 0)
        ) { nema.GetComponent<Text>().text = "Использованны все способности"; }
        else if(GG.active == false)
            {
            GG.active = true;
        }
        //}
    }
    public void ext()
    {
        can.GetComponent<basicgenrator>().sele = 0;
        select = 0;
        GG = GameObject.Find("spelmen");
        GG.active = false;
    }
    private void led() {
        select++;
        switch (select)
        {
            case (1):
                if (can.GetComponent<basicgenrator>().sp1 == 0) {
                    can.GetComponent<basicgenrator>().sele = 1;
                    GG = GameObject.Find("spellDell1");
                    GG.GetComponent<Button>().interactable = true;
                } else { led(); }
                break;
            case (2):
                if (can.GetComponent<basicgenrator>().sp2 == 0)
                {
                    can.GetComponent<basicgenrator>().sele = 2;
                    GG = GameObject.Find("spellDell2");
                    GG.GetComponent<Button>().interactable = true;
                } else { led(); }
                break;
            case (3):
                if (can.GetComponent<basicgenrator>().sp3 == 0)
                {
                    can.GetComponent<basicgenrator>().sele = 3;
                    GG = GameObject.Find("spellDell3");
                    GG.GetComponent<Button>().interactable = true;
                } else { led(); }
                break;
            case (4):
                if (can.GetComponent<basicgenrator>().sp4 == 0)
                {
                    can.GetComponent<basicgenrator>().sele = 4;
                    GG = GameObject.Find("spellDell4");
                    GG.GetComponent<Button>().interactable = true;
                } else { led(); }
                break;
            case (5):
                if (can.GetComponent<basicgenrator>().sp5 == 0)
                {
                    can.GetComponent<basicgenrator>().sele = 5;
                    GG = GameObject.Find("spellDell5");
                    GG.GetComponent<Button>().interactable = true;
                } else { led(); }
                break;
            default:
                ext();
                break;
        }
        select = 0;
    } 
    public void nem()
    {
        //can.GetComponent<basicgenrator>().sele = num;
        can.GetComponent<basicgenrator>().ret = num;
        led();
        can.GetComponent<basicgenrator>().spap();
        can.GetComponent<basicgenrator>().ret = 0;
        //select = 0;
        //if(select > 5) { select = 1; }
        if (
            (can.GetComponent<basicgenrator>().sp1 != 0) &
            (can.GetComponent<basicgenrator>().sp2 != 0) &
            (can.GetComponent<basicgenrator>().sp3 != 0) &
            (can.GetComponent<basicgenrator>().sp4 != 0) &
            (can.GetComponent<basicgenrator>().sp5 != 0) 
            ) { ext(); }

        can.GetComponent<basicgenrator>().stat();

    }
    public void selectbibel()
    {//выбор библиотеки

        can.GetComponent<basicgenrator>().sele = num;
        sell = GameObject.Find("ButtonNew");//выбор селекторов
        sell.GetComponent<activ>().alt();
        if(num == 0) { can.GetComponent<basicgenrator>().boof = frak; }

        
        can.GetComponent<basicgenrator>().newdown();
        can.GetComponent<basicgenrator>().stat();

    }
    public void spelldel()
    {
        switch(num)
        {
            case (1):
                if( can.GetComponent<basicgenrator>().sp1 != 0)
                {
                    can.GetComponent<basicgenrator>().sp1 = 0;
                    can.GetComponent<basicgenrator>().sps1 = 0;

                    can.GetComponent<basicgenrator>().stat();
                    GG.GetComponent<Button>().interactable = false;
                }
                break;
            case (2):
                if (can.GetComponent<basicgenrator>().sp2 != 0)
                {
                    can.GetComponent<basicgenrator>().sp2 = 0;
                    can.GetComponent<basicgenrator>().sps2 = 0;

                    can.GetComponent<basicgenrator>().stat();
                    GG.GetComponent<Button>().interactable = false;
                }
                break;
            case (3):
                if (can.GetComponent<basicgenrator>().sp3 != 0)
                {
                    can.GetComponent<basicgenrator>().sp3 = 0;
                    can.GetComponent<basicgenrator>().sps3 = 0;

                    can.GetComponent<basicgenrator>().stat();
                    GG.GetComponent<Button>().interactable = false;
                }
                break;
            case (4):
                if (can.GetComponent<basicgenrator>().sp4 != 0)
                {
                    can.GetComponent<basicgenrator>().sp4 = 0;
                    can.GetComponent<basicgenrator>().sps4 = 0;

                    can.GetComponent<basicgenrator>().stat();
                    GG.GetComponent<Button>().interactable = false;
                }
                break;
            case (5):
                if (can.GetComponent<basicgenrator>().sp5 != 0)
                {
                    can.GetComponent<basicgenrator>().sp5 = 0;
                    can.GetComponent<basicgenrator>().sps5 = 0;

                    can.GetComponent<basicgenrator>().stat();
                    GG.GetComponent<Button>().interactable = false;
                }
                break;
        }
    }
   

}
