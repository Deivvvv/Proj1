﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class card : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    private GameObject boog;//указатель генератора
    private string boof;

    public GameObject Protect;//покрытие
    public bool avo;//авангард
    public GameObject Stol;//авангард

    public GameObject HPBuf;



    public string avatar;
    public GameObject avatarImage;

    public GameObject Suport;

    public int buffcost;//количество бафов

    public int id;//указатель оригинала

    public GameObject slotHp;

    public GameObject slotDam;//slotAtak1;
    public GameObject slotDDam;//slotAtak2;
    public GameObject slotBroe;//slotAtak3;
    public GameObject slotCrush;//slotAtak4;

    public GameObject barDam;//slotAtak1;
    public GameObject barDDam;//slotAtak2;
    public GameObject barBroe;//slotAtak3;
    public GameObject barCrush;//slotAtak4;

    public GameObject sposList;//способности

    private int reg;
    private int ret;
    private GameObject GG;//name

    public GameObject slotName;//name
    public GameObject slotMana;//mana


    public string textSup1;
    public string textSup2;
    public string textSup3;


    public GameObject slotSup1;
    public GameObject slotSup2;
    public GameObject slotSup3;


    public GameObject barSup1;
    public GameObject barSup2;
    public GameObject barSup3;


    public GameObject mel;

    public int broe;//Бронебойность
    public int crush;//Бронелом

    public int shilds;//размер щиты
    public int shild;//щиты
    public int ship;//шипы


    public int spas;//спасение
    public int sal;//салто
    public int toh;//точность
    public int zap;//запугивание


    public int mobi;//перемещение
    public int izv;//изворотливость
    public int ura;//куворок

    public int mana;

    //public int sizes;//количество спосбностей

    public int sp1;
    public int sp2;
    public int sp3;
    public int sp4;
    public int sp5;


    public int lovk = 5;

    public bool power;
    public bool Cast;

    public string neme = "Tor";
    public int mane = 1;
    public int def;
    public int hp = 3;
    public int dam = 1;
    public int ddam = 1;

    public string clas = "card";
    public int team = 0;//команада можно буль если их 2

    public GameObject canvas;
    public void Start() 
    {


        canvas = GameObject.Find("Canvas");
        if (avatar != "")
        {

            avatarImage.GetComponent<Image>().sprite = Resources.Load<Sprite>("Avatar/" + avatar);
            //Debug.Log(avatar);
        }

        //активатор способностей
        if (canvas.GetComponent<GeneralSetting>().Mod == "stol")
        {

            ret = 26;
            if ((sp1 == ret) || (sp2 == ret) || (sp3 == ret) || (sp4 == ret) || (sp5 == ret))//26 = рывок
            {
                power = true;
                SReader();
            }
            ret = 27;
            if ((sp1 == ret) || (sp2 == ret) || (sp3 == ret) || (sp4 == ret) || (sp5 == ret))//27 = таунт
            {
                power = true;
                SReader();
            }
            ret = 0;
        }

        if (Protect != null)
        {
            Protect.active = false; 
        }



        if (def > 0) { lovk -= 4; }
        if (shild > 0) {
            switch (shilds)
            {
                case (1):
                    lovk -= 1;
                    break;
                case (2):
                    lovk -= 2;
                    break;
                case (3):
                    lovk -= 3;
                    break;
            }

        }


        if (slotHp != null)
        {
            slotHp.GetComponent<Text>().text = "" + hp;
        }
        if (slotDam != null)
        {
            if (dam == 0)
            {
                slotDam.active = false;
            }
            else
            {
                barDam.GetComponent<Text>().text = "" + dam;
            }
        }
        if (slotDDam != null)
        {
            if (ddam == 0)
            {
                slotDDam.active = false;
            }
            else
            {
                barDDam.GetComponent<Text>().text = "" + ddam;
            }


        }
        if (slotBroe != null)
        {
            if (broe == 0)
            {
                slotBroe.active = false;
            }
            else
            {
                barBroe.GetComponent<Text>().text = "" + broe;
            }
        }
        if (slotCrush != null)
        {
            if (crush == 0)
            {
                slotCrush.active = false;
            }
            else
            {
                barCrush.GetComponent<Text>().text = "" + crush;
            }
        }



        if (slotName != null)
        {
            slotName.GetComponent<Text>().text = "" + neme;
        }
        if (slotMana != null)
        {
            slotMana.GetComponent<Text>().text = "" + mane;
        }






        cloc();


        if (slotSup1 != null)
        {
            if (textSup1 != "null")
            {
                switch (textSup1)
                {
                    case ("def"):

                        slotSup1.GetComponent<Image>().sprite = Resources.Load<Sprite>("Armor");//10
                        barSup1.GetComponent<Text>().text = "" + def;
                        break;
                    case ("shild"):
                        switch (shilds)
                        {
                            case (1):

                                slotSup1.GetComponent<Image>().sprite = Resources.Load<Sprite>("Small_Shild");//10
                                break;
                            case (2):

                                slotSup1.GetComponent<Image>().sprite = Resources.Load<Sprite>("Shild");//10
                                break;
                            case (3):

                                slotSup1.GetComponent<Image>().sprite = Resources.Load<Sprite>("Big_Shild");//10
                                break;
                        }
                        barSup1.GetComponent<Text>().text = "" + shild;
                        break;
                    case ("ship"):

                        slotSup1.GetComponent<Image>().sprite = Resources.Load<Sprite>("Ship");//10
                        barSup1.GetComponent<Text>().text = "" + ship;
                        break;
                    case ("spas"):

                        slotSup1.GetComponent<Image>().sprite = Resources.Load<Sprite>("Another");//10
                        barSup1.GetComponent<Text>().text = "" + spas;
                        break;
                    case ("sal"):

                        slotSup1.GetComponent<Image>().sprite = Resources.Load<Sprite>("Another");//10
                        barSup1.GetComponent<Text>().text = "" + sal;
                        break;
                    case ("toh"):

                        slotSup1.GetComponent<Image>().sprite = Resources.Load<Sprite>("Another");//10
                        barSup1.GetComponent<Text>().text = "" + toh;
                        break;
                    case ("zap"):

                        slotSup1.GetComponent<Image>().sprite = Resources.Load<Sprite>("Another");//10
                        barSup1.GetComponent<Text>().text = "" + zap;
                        break;
                    case ("mobi"):

                        slotSup1.GetComponent<Image>().sprite = Resources.Load<Sprite>("Another");//10
                        barSup1.GetComponent<Text>().text = "" + mobi;
                        break;
                    case ("izv"):

                        slotSup1.GetComponent<Image>().sprite = Resources.Load<Sprite>("Another");//10
                        barSup1.GetComponent<Text>().text = "" + izv;
                        break;
                    case ("ura"):

                        slotSup1.GetComponent<Image>().sprite = Resources.Load<Sprite>("Another");//10
                        barSup1.GetComponent<Text>().text = "" + ura;
                        break;


                    default:
                        Debug.Log("неисправность в slotSup1   " + textSup1);
                        break;
                }

            }
            else { slotSup1.active = false; }
            //Debug.Log("Ok");




        }
        if (slotSup2 != null)
        {
            if (textSup2 != "null")
            {
                switch (textSup2)
                {
                    case ("def"):

                        slotSup2.GetComponent<Image>().sprite = Resources.Load<Sprite>("Armor");//10
                        barSup2.GetComponent<Text>().text = "" + def;
                        break;
                    case ("shild"):
                        switch (shilds)
                        {
                            case (1):

                                slotSup2.GetComponent<Image>().sprite = Resources.Load<Sprite>("Small_Shild");//10
                                break;
                            case (2):

                                slotSup2.GetComponent<Image>().sprite = Resources.Load<Sprite>("Shild");//10
                                break;
                            case (3):

                                slotSup2.GetComponent<Image>().sprite = Resources.Load<Sprite>("Big_Shild");//10
                                break;
                        }
                        barSup2.GetComponent<Text>().text = "" + shild;
                        break;
                    case ("ship"):

                        slotSup2.GetComponent<Image>().sprite = Resources.Load<Sprite>("Ship");//10
                        barSup2.GetComponent<Text>().text = "" + ship;
                        break;
                    case ("spas"):

                        slotSup2.GetComponent<Image>().sprite = Resources.Load<Sprite>("Another");//10
                        barSup2.GetComponent<Text>().text = "" + spas;
                        break;
                    case ("sal"):

                        slotSup2.GetComponent<Image>().sprite = Resources.Load<Sprite>("Another");//10
                        barSup2.GetComponent<Text>().text = "" + sal;
                        break;
                    case ("toh"):

                        slotSup2.GetComponent<Image>().sprite = Resources.Load<Sprite>("Another");//10
                        barSup2.GetComponent<Text>().text = "" + toh;
                        break;
                    case ("zap"):

                        slotSup2.GetComponent<Image>().sprite = Resources.Load<Sprite>("Another");//10
                        barSup2.GetComponent<Text>().text = "" + zap;
                        break;
                    case ("mobi"):

                        slotSup2.GetComponent<Image>().sprite = Resources.Load<Sprite>("Another");//10
                        barSup2.GetComponent<Text>().text = "" + mobi;
                        break;
                    case ("izv"):

                        slotSup2.GetComponent<Image>().sprite = Resources.Load<Sprite>("Another");//10
                        barSup2.GetComponent<Text>().text = "" + izv;
                        break;
                    case ("ura"):

                        slotSup2.GetComponent<Image>().sprite = Resources.Load<Sprite>("Another");//10
                        barSup2.GetComponent<Text>().text = "" + ura;
                        break;


                    default:
                        Debug.Log("неисправность в slotSup2   " + textSup2);
                        break;
                }

            }
            else { slotSup2.active = false; }
        }
        if (slotSup3 != null)
        {
            if (textSup3 != "null")
            {
                switch (textSup3)
                {
                    case ("def"):

                        slotSup3.GetComponent<Image>().sprite = Resources.Load<Sprite>("Armor");//10
                        barSup3.GetComponent<Text>().text = "" + def;
                        break;
                    case ("shild"):
                        switch (shilds)
                        {
                            case (1):

                                slotSup3.GetComponent<Image>().sprite = Resources.Load<Sprite>("Small_Shild");//10
                                break;
                            case (2):

                                slotSup3.GetComponent<Image>().sprite = Resources.Load<Sprite>("Shild");//10
                                break;
                            case (3):

                                slotSup3.GetComponent<Image>().sprite = Resources.Load<Sprite>("Big_Shild");//10
                                break;
                        }
                        barSup3.GetComponent<Text>().text = "" + shild;
                        break;
                    case ("ship"):

                        slotSup3.GetComponent<Image>().sprite = Resources.Load<Sprite>("Ship");//10
                        barSup3.GetComponent<Text>().text = "" + ship;
                        break;
                    case ("spas"):

                        slotSup3.GetComponent<Image>().sprite = Resources.Load<Sprite>("Another");//10
                        barSup3.GetComponent<Text>().text = "" + spas;
                        break;
                    case ("sal"):

                        slotSup3.GetComponent<Image>().sprite = Resources.Load<Sprite>("Another");//10
                        barSup3.GetComponent<Text>().text = "" + sal;
                        break;
                    case ("toh"):

                        slotSup3.GetComponent<Image>().sprite = Resources.Load<Sprite>("Another");//10
                        barSup3.GetComponent<Text>().text = "" + toh;
                        break;
                    case ("zap"):

                        slotSup3.GetComponent<Image>().sprite = Resources.Load<Sprite>("Another");//10
                        barSup3.GetComponent<Text>().text = "" + zap;
                        break;
                    case ("mobi"):

                        slotSup3.GetComponent<Image>().sprite = Resources.Load<Sprite>("Another");//10
                        barSup3.GetComponent<Text>().text = "" + mobi;
                        break;
                    case ("izv"):

                        slotSup3.GetComponent<Image>().sprite = Resources.Load<Sprite>("Another");//10
                        barSup3.GetComponent<Text>().text = "" + izv;
                        break;
                    case ("ura"):

                        slotSup3.GetComponent<Image>().sprite = Resources.Load<Sprite>("Another");//10
                        barSup3.GetComponent<Text>().text = "" + ura;
                        break;


                    default:
                        Debug.Log("неисправность в slotSup3   " + textSup3);
                        break;
                }

            }
            else { slotSup3.active = false; }
        }




        if (sp1 != 0)
        {
            canvas.GetComponent<SpelSkroll>().id = sp1;//отправка запроса
            canvas.GetComponent<SpelSkroll>().skrol();
            boof = "" + canvas.GetComponent<SpelSkroll>().name;
        }
        else { boof = ""; }
        if (sp2 != 0)
        {
            canvas.GetComponent<SpelSkroll>().id = sp2;//отправка запроса
            canvas.GetComponent<SpelSkroll>().skrol();
            boof += "\n" + canvas.GetComponent<SpelSkroll>().name;
        }
        else { boof += "\n"; }
        if (sp3 != 0)
        {
            canvas.GetComponent<SpelSkroll>().id = sp3;//отправка запроса
            canvas.GetComponent<SpelSkroll>().skrol();
            boof += "\n" + canvas.GetComponent<SpelSkroll>().name;

        }
        else { boof += "\n"; }
        if (sp4 != 0)
        {
            canvas.GetComponent<SpelSkroll>().id = sp4;//отправка запроса
            canvas.GetComponent<SpelSkroll>().skrol();
            boof += "\n" + canvas.GetComponent<SpelSkroll>().name;

        }
        else { boof += "\n"; }
        if (sp5 != 0)
        {
            canvas.GetComponent<SpelSkroll>().id = sp5;//отправка запроса
            canvas.GetComponent<SpelSkroll>().skrol();
            boof += "\n" + canvas.GetComponent<SpelSkroll>().name;

        }
        else { boof += "\n"; }

        if (sposList != null)
        {
            sposList.GetComponent<Text>().text = "" + boof;
        }




    }



    private void cloc()//служит для управления слотами поддержки
    {
        if (textSup1 == "")
        {
            if (def > 0) { textSup1 = "def"; }
            else if (shild > 0) { textSup1 = "shild";  }
            else if (ship > 0) { textSup1 = "ship"; }
            if (lovk > 0)
            {

                if (spas > 0) { textSup1 = "spas"; }
                else if (sal > 0) { textSup1 = "sal"; }
                else if (toh > 0) { textSup1 = "toh"; }
                else if (zap > 0) { textSup1 = "zap"; }
                else if (mobi > 0) { textSup1 = "mobi"; }
                else if (izv > 0) { textSup1 = "izv"; }
                else if (ura > 0) { textSup1 = "ura"; }
                if (textSup1 == "") { textSup1 = "null"; }
            }

        }
        if (textSup2 == "")
        {
            if ((def > 0) & (textSup1 != "def")) { textSup2 = "def"; }
            else if ((shild > 0) & (textSup1 != "shild")) { textSup2 = "shild"; }
            else if ((ship > 0) & (textSup1 != "ship")) { textSup2 = "ship"; }
            if (lovk > 0)
            {

                if ((spas > 0) & (textSup1 != "spas")) { textSup2 = "spas"; }
                else if ((sal > 0) & (textSup1 != "sal")) { textSup2 = "sal"; }
                else if ((toh > 0) & (textSup1 != "toh")) { textSup2 = "toh"; }
                else if ((zap > 0) & (textSup1 != "zap")) { textSup2 = "zap"; }
                else if ((mobi > 0) & (textSup1 != "mobi")) { textSup2 = "mobi"; }
                else if ((izv > 0) & (textSup1 != "izv")) { textSup2 = "izv"; }
                else if ((ura > 0) & (textSup1 != "ura")) { textSup2 = "ura"; }
                if (textSup2 == "") { textSup2 = "null"; }
            }
        }
        if (textSup3 == "")
        {

            if ((def > 0) & (textSup1 != "def") & (textSup2 != "def")) { textSup3 = "def"; }
            else if ((shild > 0) & (textSup1 != "shild") & (textSup2 != "shild")) { textSup3 = "shild"; }
            else if ((ship > 0) & (textSup1 != "ship") & (textSup2 != "ship")) { textSup3 = "ship"; }
            if (lovk > 0)
            {

                if ((spas > 0) & (textSup1 != "spas") & (textSup2 != "spas")) { textSup3 = "spas"; }
                else if ((sal > 0) & (textSup1 != "sal") & (textSup2 != "sal")) { textSup3 = "sal"; }
                else if ((toh > 0) & (textSup1 != "toh") & (textSup2 != "toh")) { textSup3 = "toh"; }
                else if ((zap > 0) & (textSup1 != "zap") & (textSup2 != "zap")) { textSup3 = "zap"; }
                else if ((mobi > 0) & (textSup1 != "mobi") & (textSup2 != "mobi")) { textSup3 = "mobi"; }
                else if ((izv > 0) & (textSup1 != "izv") & (textSup2 != "izv")) { textSup3 = "izv"; }
                else if ((ura > 0) & (textSup1 != "ura") & (textSup2 != "ura")) { textSup3 = "ura"; }
                if (textSup3 == "") { textSup3 = "null"; }
            }

        }


        if (textSup1 == "null") { textSup2 = "null"; }
        if (textSup2 == "null") { textSup3 = "null"; }

    }



    public void statys()
    {

        if (hp <= 0)//разрушение
        {destrukt();}

        if (avatar != ""){avatarImage.GetComponent<Image>().sprite = Resources.Load<Sprite>("Avatar/" + avatar);}


        textSup1 = "";
        textSup2 = "";
        textSup3 = "";
        if (def > 0) { lovk -= 4; }
        if (shild > 0)
        {
            switch (shilds)
            {
                case (1):
                    lovk -= 1;
                    break;
                case (2):
                    lovk -= 2;
                    break;
                case (3):
                    lovk -= 3;
                    break;
            }

        }


        if (slotHp != null)
        {
            slotHp.GetComponent<Text>().text = "" + hp;
        }
        if (slotDam != null)
        {
            if (dam == 0)
            {
                slotDam.active = false;
            }
            else
            {
                if (slotDam.active != true)
                {

                    slotDam.active = true;
                }
                barDam.GetComponent<Text>().text = "" + dam;
            }
        }
        if (slotDDam != null)
        {
            if (ddam == 0)
            {
                slotDDam.active = false;
            }
            else
            {
                if (slotDDam.active != true)
                {

                    slotDDam.active = true;
                }
                barDDam.GetComponent<Text>().text = "" + ddam;
            }


        }
        if (slotBroe != null)
        {
            if (broe == 0)
            {
                slotBroe.active = false;
            }
            else
            {
                if (slotBroe.active != true)
                {

                    slotBroe.active = true;
                }
                barBroe.GetComponent<Text>().text = "" + broe;
            }
        }
        if (slotCrush != null)
        {
            if (crush == 0)
            {
                slotCrush.active = false;
            }
            else
            { if (slotCrush.active != true)
                {

                    slotCrush.active = true;
                }
                barCrush.GetComponent<Text>().text = "" + crush;
            }
        }



        if (slotName != null)
        {
            slotName.GetComponent<Text>().text = "" + neme;
        }
        if (slotMana != null)
        {
            slotMana.GetComponent<Text>().text = "" + mane;
        }






        cloc();


        if (slotSup1 != null)
        {
            if (textSup1 != "null")
            {
                if (slotSup1.active != true)
                {

                    slotSup1.active = true;
                }
                switch (textSup1)
                {
                    case ("def"):

                        slotSup1.GetComponent<Image>().sprite = Resources.Load<Sprite>("Armor");//10
                        barSup1.GetComponent<Text>().text = "" + def;
                        break;
                    case ("shild"):
                        switch (shilds)
                        {
                            case (1):

                                slotSup1.GetComponent<Image>().sprite = Resources.Load<Sprite>("Small_Shild");//10
                                break;
                            case (2):

                                slotSup1.GetComponent<Image>().sprite = Resources.Load<Sprite>("Shild");//10
                                break;
                            case (3):

                                slotSup1.GetComponent<Image>().sprite = Resources.Load<Sprite>("Big_Shild");//10
                                break;
                        }
                        barSup1.GetComponent<Text>().text = "" + shild;
                        break;
                    case ("ship"):

                        slotSup1.GetComponent<Image>().sprite = Resources.Load<Sprite>("Ship");//10
                        barSup1.GetComponent<Text>().text = "" + ship;
                        break;
                    case ("spas"):

                        slotSup1.GetComponent<Image>().sprite = Resources.Load<Sprite>("Another");//10
                        barSup1.GetComponent<Text>().text = "" + spas;
                        break;
                    case ("sal"):

                        slotSup1.GetComponent<Image>().sprite = Resources.Load<Sprite>("Another");//10
                        barSup1.GetComponent<Text>().text = "" + sal;
                        break;
                    case ("toh"):

                        slotSup1.GetComponent<Image>().sprite = Resources.Load<Sprite>("Another");//10
                        barSup1.GetComponent<Text>().text = "" + toh;
                        break;
                    case ("zap"):

                        slotSup1.GetComponent<Image>().sprite = Resources.Load<Sprite>("Another");//10
                        barSup1.GetComponent<Text>().text = "" + zap;
                        break;
                    case ("mobi"):

                        slotSup1.GetComponent<Image>().sprite = Resources.Load<Sprite>("Another");//10
                        barSup1.GetComponent<Text>().text = "" + mobi;
                        break;
                    case ("izv"):

                        slotSup1.GetComponent<Image>().sprite = Resources.Load<Sprite>("Another");//10
                        barSup1.GetComponent<Text>().text = "" + izv;
                        break;
                    case ("ura"):

                        slotSup1.GetComponent<Image>().sprite = Resources.Load<Sprite>("Another");//10
                        barSup1.GetComponent<Text>().text = "" + ura;
                        break;


                    default:
                        Debug.Log("неисправность в slotSup1   " + textSup1);
                        break;
                }

            }
            else { slotSup1.active = false; }
            //Debug.Log("Ok");




        }
        if (slotSup2 != null)
        {
            if (textSup2 != "null")
            {
                if (slotSup2.active != true)
                {

                    slotSup2.active = true;
                }
                switch (textSup2)
                {
                    case ("def"):

                        slotSup2.GetComponent<Image>().sprite = Resources.Load<Sprite>("Armor");//10
                        barSup2.GetComponent<Text>().text = "" + def;
                        break;
                    case ("shild"):
                        switch (shilds)
                        {
                            case (1):

                                slotSup2.GetComponent<Image>().sprite = Resources.Load<Sprite>("Small_Shild");//10
                                break;
                            case (2):

                                slotSup2.GetComponent<Image>().sprite = Resources.Load<Sprite>("Shild");//10
                                break;
                            case (3):

                                slotSup2.GetComponent<Image>().sprite = Resources.Load<Sprite>("Big_Shild");//10
                                break;
                        }
                        barSup2.GetComponent<Text>().text = "" + shild;
                        break;
                    case ("ship"):

                        slotSup2.GetComponent<Image>().sprite = Resources.Load<Sprite>("Ship");//10
                        barSup2.GetComponent<Text>().text = "" + ship;
                        break;
                    case ("spas"):

                        slotSup2.GetComponent<Image>().sprite = Resources.Load<Sprite>("Another");//10
                        barSup2.GetComponent<Text>().text = "" + spas;
                        break;
                    case ("sal"):

                        slotSup2.GetComponent<Image>().sprite = Resources.Load<Sprite>("Another");//10
                        barSup2.GetComponent<Text>().text = "" + sal;
                        break;
                    case ("toh"):

                        slotSup2.GetComponent<Image>().sprite = Resources.Load<Sprite>("Another");//10
                        barSup2.GetComponent<Text>().text = "" + toh;
                        break;
                    case ("zap"):

                        slotSup2.GetComponent<Image>().sprite = Resources.Load<Sprite>("Another");//10
                        barSup2.GetComponent<Text>().text = "" + zap;
                        break;
                    case ("mobi"):

                        slotSup2.GetComponent<Image>().sprite = Resources.Load<Sprite>("Another");//10
                        barSup2.GetComponent<Text>().text = "" + mobi;
                        break;
                    case ("izv"):

                        slotSup2.GetComponent<Image>().sprite = Resources.Load<Sprite>("Another");//10
                        barSup2.GetComponent<Text>().text = "" + izv;
                        break;
                    case ("ura"):

                        slotSup2.GetComponent<Image>().sprite = Resources.Load<Sprite>("Another");//10
                        barSup2.GetComponent<Text>().text = "" + ura;
                        break;


                    default:
                        Debug.Log("неисправность в slotSup2   " + textSup2);
                        break;
                }

            }
            else { slotSup2.active = false; }
        }
        if (slotSup3 != null)
        {
            if (textSup3 != "null")
            {
                if (slotSup3.active != true)
                {

                    slotSup3.active = true;
                }
                switch (textSup3)
                {
                    case ("def"):

                        slotSup3.GetComponent<Image>().sprite = Resources.Load<Sprite>("Armor");//10
                        barSup3.GetComponent<Text>().text = "" + def;
                        break;
                    case ("shild"):
                        switch (shilds)
                        {
                            case (1):

                                slotSup3.GetComponent<Image>().sprite = Resources.Load<Sprite>("Small_Shild");//10
                                break;
                            case (2):

                                slotSup3.GetComponent<Image>().sprite = Resources.Load<Sprite>("Shild");//10
                                break;
                            case (3):

                                slotSup3.GetComponent<Image>().sprite = Resources.Load<Sprite>("Big_Shild");//10
                                break;
                        }
                        barSup3.GetComponent<Text>().text = "" + shild;
                        break;
                    case ("ship"):

                        slotSup3.GetComponent<Image>().sprite = Resources.Load<Sprite>("Ship");//10
                        barSup3.GetComponent<Text>().text = "" + ship;
                        break;
                    case ("spas"):

                        slotSup3.GetComponent<Image>().sprite = Resources.Load<Sprite>("Another");//10
                        barSup3.GetComponent<Text>().text = "" + spas;
                        break;
                    case ("sal"):

                        slotSup3.GetComponent<Image>().sprite = Resources.Load<Sprite>("Another");//10
                        barSup3.GetComponent<Text>().text = "" + sal;
                        break;
                    case ("toh"):

                        slotSup3.GetComponent<Image>().sprite = Resources.Load<Sprite>("Another");//10
                        barSup3.GetComponent<Text>().text = "" + toh;
                        break;
                    case ("zap"):

                        slotSup3.GetComponent<Image>().sprite = Resources.Load<Sprite>("Another");//10
                        barSup3.GetComponent<Text>().text = "" + zap;
                        break;
                    case ("mobi"):

                        slotSup3.GetComponent<Image>().sprite = Resources.Load<Sprite>("Another");//10
                        barSup3.GetComponent<Text>().text = "" + mobi;
                        break;
                    case ("izv"):

                        slotSup3.GetComponent<Image>().sprite = Resources.Load<Sprite>("Another");//10
                        barSup3.GetComponent<Text>().text = "" + izv;
                        break;
                    case ("ura"):

                        slotSup3.GetComponent<Image>().sprite = Resources.Load<Sprite>("Another");//10
                        barSup3.GetComponent<Text>().text = "" + ura;
                        break;


                    default:
                        Debug.Log("неисправность в slotSup3   " + textSup3);
                        break;
                }

            }
            else { slotSup3.active = false; }
        }


        canvas = GameObject.Find("Canvas");



        if (sp1 != 0)
        {
            canvas.GetComponent<SpelSkroll>().id = sp1;//отправка запроса
            canvas.GetComponent<SpelSkroll>().skrol();
            boof = "" + canvas.GetComponent<SpelSkroll>().name;
        }
        else { boof = ""; }
        if (sp2 != 0)
        {
            canvas.GetComponent<SpelSkroll>().id = sp2;//отправка запроса
            canvas.GetComponent<SpelSkroll>().skrol();
            boof += "\n" + canvas.GetComponent<SpelSkroll>().name;
        }
        else { boof += "\n"; }
        if (sp3 != 0)
        {
            canvas.GetComponent<SpelSkroll>().id = sp3;//отправка запроса
            canvas.GetComponent<SpelSkroll>().skrol();
            boof += "\n" + canvas.GetComponent<SpelSkroll>().name;

        }
        else { boof += "\n"; }
        if (sp4 != 0)
        {
            canvas.GetComponent<SpelSkroll>().id = sp4;//отправка запроса
            canvas.GetComponent<SpelSkroll>().skrol();
            boof += "\n" + canvas.GetComponent<SpelSkroll>().name;

        }
        else { boof += "\n"; }
        if (sp5 != 0)
        {
            canvas.GetComponent<SpelSkroll>().id = sp5;//отправка запроса
            canvas.GetComponent<SpelSkroll>().skrol();
            boof += "\n" + canvas.GetComponent<SpelSkroll>().name;

        }
        else { boof += "\n"; }

        if (sposList != null)
        {
            sposList.GetComponent<Text>().text = "" + boof;
        }

    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        switch (canvas.GetComponent<GeneralSetting>().Mod)
        {

            case ("Colod"):

                canvas.GetComponent<colodss>().selector = gameObject;
                //if ()
                //{

                // }
                if (sp1 != 0)
                {
                    canvas.GetComponent<SpelSkroll>().id = sp1;//отправка запроса
                    canvas.GetComponent<SpelSkroll>().skrol();
                    boof = "" + canvas.GetComponent<SpelSkroll>().name;
                }
                //else { boof = ""; }
                if (sp2 != 0)
                {
                    canvas.GetComponent<SpelSkroll>().id = sp2;//отправка запроса
                    canvas.GetComponent<SpelSkroll>().skrol();
                    boof += ", " + canvas.GetComponent<SpelSkroll>().name;
                }
                if (sp3 != 0)
                {
                    canvas.GetComponent<SpelSkroll>().id = sp3;//отправка запроса
                    canvas.GetComponent<SpelSkroll>().skrol();
                    boof += ", " + canvas.GetComponent<SpelSkroll>().name;

                }
                if (sp4 != 0)
                {
                    canvas.GetComponent<SpelSkroll>().id = sp4;//отправка запроса
                    canvas.GetComponent<SpelSkroll>().skrol();
                    boof += ", " + canvas.GetComponent<SpelSkroll>().name;

                }
                if (sp5 != 0)
                {
                    canvas.GetComponent<SpelSkroll>().id = sp5;//отправка запроса
                    canvas.GetComponent<SpelSkroll>().skrol();
                    boof += ", " + canvas.GetComponent<SpelSkroll>().name;

                }

                GG = GameObject.Find("PLTEXT");
                if (GG != null)
                {
                    GG.GetComponent<Text>().text = "" + boof;
                }

                break;
            case ("Stol"):
                if (clas == "Card")
                {
                    canvas.GetComponent<stol>().selector = gameObject;

                   

                }
                if (clas == "Сreator")
                {
                    if ((power == true) & (team == 0))
                    {
                        Suport.active = true;
                    }
                    if (canvas.GetComponent<stol>().sel != null)
                    {
                        canvas.GetComponent<stol>().selector = gameObject;
                        //canvas.GetComponent<stol>().eror1();
                        canvas.GetComponent<stol>().selClas = clas;
                    }

                }

                break;
            default:


                break;
        }
    }
    public void OnPointerExit(PointerEventData eventData)
    {
        switch (canvas.GetComponent<GeneralSetting>().Mod)
        {
            case ("Colod"):

                canvas.GetComponent<colodss>().selector = null;
                GG = GameObject.Find("PLTEXT");
                if (GG != null)
                {
                    GG.GetComponent<Text>().text = "";
                }

                break;
            case ("Stol"):
                if (clas == "Card")
                {
                    canvas.GetComponent<stol>().selector = null;
                }
                else if (clas == "Сreator")
                {
                    Suport.active = false;
                    if (canvas.GetComponent<stol>().sel != null)
                    {
                        canvas.GetComponent<stol>().selector = null;
                        canvas.GetComponent<stol>().selClas = null;
                    }
                    else
                    {

                        canvas.GetComponent<stol>().mood = null;
                    }



                }

                break;
            default:


                break;
        }
    }
    public void Hod()
    {

        //процедура восполнения энерги карт
        power = true;
        spell();
        SReader();
        //проерка каста
    }
    public void SReader()
    {
        if (power == true)
        {
            mel.GetComponent<Image>().color = new Color(205 / 255.0f, 205 / 255.0f, 205 / 255.0f);//серебренный
        }
        else
        {
            //добавить гибридные отметки
            /*
             if (GG.GetComponent<Arow>().tayp == "Taynt")
            {
                mel.GetComponent<Image>().color = new Color(255 / 255.0f, 211 / 255.0f, 61 / 255.0f);//золотой
            }
            else
             
             */


            if (Cast == true)
            {
                mel.GetComponent<Image>().color = new Vector4(197 / 255.0f, 0 / 255.0f, 0 / 255.0f, 1);//вероятно красный
            }
            else
            {
                mel.GetComponent<Image>().color = new Vector4(39 / 255.0f, 39 / 255.0f, 39 / 255.0f, 1);//заполненый(белый?)
            }
        }
    }

    public void SReader12()
    {
        //расширенный болок
        // if (canvas.GetComponent<stol>().clas == "Card")
        //  {

        // }
        if (canvas.GetComponent<stol>().sel != null)
        {
            if (mel.GetComponent<card>().team == 1)
            {
                if (mel.GetComponent<card>().dam == 0)
                {
                    mel.GetComponent<Image>().color = new Vector4(0 / 255.0f, 0 / 255.0f, 255 / 255.0f, 1); //поставить синий!!
                }
                else if (mel.GetComponent<card>().dam > 0) { mel.GetComponent<Image>().color = new Vector4(220 / 255.0f, 0 / 255.0f, 0 / 255.0f, 1); }
                else
                {
                    mel.GetComponent<Image>().color = new Vector4(0 / 255.0f, 0 / 255.0f, 255 / 255.0f, 1); //незнаю какой это
                }
            }
            else
            {
                if(canvas.GetComponent<stol>().sel == mel)
                {
                    mel.GetComponent<Image>().color = new Vector4(0 / 255.0f, 255 / 255.0f, 12/ 255.0f, 1); //поставить зеленый!!
                }
                else
                {
                    mel.GetComponent<Image>().color = new Vector4(0 / 255.0f, 0 / 255.0f, 255 / 255.0f, 1); //поставить синий!!
                }
            }
        }
        else
        {
            SReader();
        }
                
    }


    private void spell()
    {
        if (buffcost > 0)
        {
            ret++;
            GG = GameObject.Find("Buf" + ret);
            if (GG != null)
            {
                reg++;
                GG.GetComponent<Arow>().next();
            }

            if (ret < buffcost)
            {
                spell();
            }
            else { ret = 0; if (reg == 0) { buffcost = 0; } reg = 0; }//могут быть неисправности
        }

    }
    public void instal(){

        if (Protect != null)
        {
            //протект
            ret = 15;
            if ((sp1 == ret) || (sp2 == ret) || (sp3 == ret) || (sp4 == ret) || (sp5 == ret))//15 = таунт
            {
                if (avo == true)
                {
                    if (Protect.active != false)
                    {
                        canvas.GetComponent<StolSuport>().Sek = "Taynt";
                        canvas.GetComponent<StolSuport>().lok = team;
                        canvas.GetComponent<StolSuport>().bsek();
                        if (canvas.GetComponent<StolSuport>().res != true)
                        {
                            instal();

                        }

                        GG = GameObject.Find("boof" + team + ":" + canvas.GetComponent<StolSuport>().ret);
                    //    if (GG != null)
                       // {
                        //    ret = canvas.GetComponent<StolSuport>().boof2;
                        //    ret--;
                       //     canvas.GetComponent<StolSuport>().boof2 = ret;
                      //  }
                        Destroy(GG);
                        canvas.GetComponent<StolSuport>().ret = 0;

                        Protect.active = false;
                    }
                }
                else
                {
                    if (reg == 0)
                    {

                        if (team == 0)
                        {
                            reg = canvas.GetComponent<StolSuport>().boof1;
                            reg++;
                            canvas.GetComponent<StolSuport>().boof1 = reg;
                        }
                        else
                        {

                            ret = canvas.GetComponent<StolSuport>().boof2;
                            ret++;
                            canvas.GetComponent<StolSuport>().boof2 = ret;
                        }
                        reg = 0;
                    }
                    reg++;
                    GG = GameObject.Find("boof" + team + ":" + reg);
                    if (GG != null)
                    {
                        instal();
                    }
                    if (reg != 0)
                    {
                        Protect.active = true;
                        var ta = Instantiate(canvas.GetComponent<stol>().Spell, new Vector3(0, 0, 0), Quaternion.identity);//вызываемый обект
                        ta.transform.SetParent(canvas.transform);
                        ta.name = "boof" + team + ":" + reg;

                        ta.GetComponent<Arow>().tayp = "Taynt";
                        //ta.GetComponent<Arow>().deep = ;
                        reg = 0;
                    }

                }

            }
            else { Protect.active = false; }
            ret = 0;




        }
        //маскировка
           /*  ret = 2;
             if ((sp1 == ret) || (sp2 == ret) || (sp3 == ret) || (sp4 == ret) || (sp5 == ret))//2 = маскировка
             { 
                if (avo == true)
                 {
                     if (Protect.active != false)
                     {
                         canvas.GetComponent<StolSuport>().Sek = "mask";
                         canvas.GetComponent<StolSuport>().lok = team;
                         canvas.GetComponent<StolSuport>().bsek();
                         if (canvas.GetComponent<StolSuport>().res != true)
                         {
                             instal();

                         }

                         GG = GameObject.Find("boof" + team + ":" + canvas.GetComponent<StolSuport>().ret);
                         if (GG != null)
                         {
                             ret = canvas.GetComponent<StolSuport>().boof2;
                             ret--;
                             canvas.GetComponent<StolSuport>().boof2 = ret;
                         }
                         Destroy(GG);
                         canvas.GetComponent<StolSuport>().ret = 0;

                         Protect.active = ter;
                     }
                 }
                 else
                 {
                     if (reg == 0)
                     {

                         if (team == 0)
                         {
                             reg = canvas.GetComponent<StolSuport>().boof1;
                             reg++;
                             canvas.GetComponent<StolSuport>().boof1 = reg;
                         }
                         else
                         {

                             ret = canvas.GetComponent<StolSuport>().boof2;
                             ret++;
                             canvas.GetComponent<StolSuport>().boof2 = ret;
                         }
                         reg = 0;
                     }
                     reg++;
                     GG = GameObject.Find("boof" + team + ":" + reg);
                     if (GG != null)
                     {
                         instal();
                     }
                     if (reg != 0)
                     {
                         Protect.active = false;
                         var ta = Instantiate(canvas.GetComponent<stol>().Spell, new Vector3(0, 0, 0), Quaternion.identity);//вызываемый обект
                         ta.transform.SetParent(canvas.transform);
                         ta.name = "boof" + team + ":" + reg;

                         ta.GetComponent<Arow>().tayp = "mask";
                         ta.GetComponent<Arow>().deep = 1;
                         reg = 0;
                     }

                 }

             }
             else { Protect.active = true; }*/
            ret = 0;
        
        

    }

    public void destrukt()
    {
        if(Protect != null)
        {
            if (Protect.active == true)
            {
                canvas.GetComponent<StolSuport>().ret = 0 ;//должно решить проблему нескольких эффектов
                canvas.GetComponent<StolSuport>().Sek = "Taynt";
                canvas.GetComponent<StolSuport>().lok = team;
                canvas.GetComponent<StolSuport>().bsek();
                if (canvas.GetComponent<StolSuport>().res != true)
                {
                    destrukt();
                    
                }
                GG = GameObject.Find("boof" + team + ":" + canvas.GetComponent<StolSuport>().ret);
                if(GG != null)
                {
                    //  if (team == 0)
                    //  {
                    //
                    // }
                    // ret = canvas.GetComponent<StolSuport>().boof2;
                    //ret--;
                    // canvas.GetComponent<StolSuport>().boof2 = ret;
                }
                else
                {
                    canvas.GetComponent<StolSuport>().ret = 0;
                    destrukt();
                }
                Debug.Log(GG);
                Destroy(GG);
                canvas.GetComponent<StolSuport>().ret = 0;
                canvas.GetComponent<StolSuport>().bsek();
                canvas.GetComponent<StolSuport>().ret = 0;




                Protect.active = false;
                
            }
        }

        //if((boog != null)|(boog.active == false))
        //{
        //    boog.GetComponent<basicgenrator>().cardDestruct();
        //}
        if( Stol != null)
        {
            if (avo == true)
            {
                Stol.GetComponent<StolSlot>().BObj = null;
            }
            else
            {
                Stol.GetComponent<StolSlot>().AObj = null;
            }
        }
        if (canvas.GetComponent<GeneralSetting>().Mod != "bibel" )
        {

            canvas.GetComponent<stol>().stage5();
        }
        Destroy(mel);
    }
    
    public void redact()
    {
        boog = GameObject.Find("genpanel");
        boog.GetComponent<basicgenrator>().idcard = id;//? ret
        boog.GetComponent<basicgenrator>().CardData();
    }



}
