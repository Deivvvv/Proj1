﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Arow : MonoBehaviour
{
    //стрела(баф)
    public GameObject host;//тело(носителя)
    public GameObject mell;//тело бафа
    public GameObject mel;//цель
    public int taym;//время каста
    public int strong;//сила
    public string tayp;//тип
    public string clas;
    public GameObject deep;//указвает близнеца
    public GameObject canvas;//указвает близнеца


    private int ret;
    // Start is called before the first frame update
    void Start()
    {
        canvas = GameObject.Find("Canvas");
    }
    public void next()
    {
        taym--;
        
        if(taym <= 0)
        {
            switch (tayp)
            {
                case ("Aroww"):
                    if (clas == "Сreator")
                    {/*
                        if (mel == null)
                        {
                            host.GetComponent<card>().Cast = false;//отключаем
                            Destroy(mell);
                        }
                         */


                        if (mel != null)
                        {
                            Debug.Log(""+mel +"="+host);
                            if (host != null)
                            {
                               // host.GetComponent<card>().Cast = false;
                            }
                                
                            if (mel.GetComponent<card>().shilds > 1) { ret = mel.GetComponent<card>().def - strong; }
                            else
                            {
                                ret = (mel.GetComponent<card>().def + mel.GetComponent<card>().shild) - strong;
                            }
                            if (ret < 0)
                            {
                                mel.GetComponent<card>().hp += ret;
                            }
                            ret = 0;
                            mel.GetComponent<card>().statys();
                            tayp = null;
                           host = host.GetComponent<card>().Stol;
                            host.GetComponent<StolSlot>().Restruct();
                            //host.GetComponent<card>().buffcost--;
                             Destroy(mell);
                        }
                        else
                        {
                            host.GetComponent<card>().Cast = false;
                            //host.GetComponent<card>().power = false;//времнно// тут true он возращает стрелу
                            host.GetComponent<card>().SReader();//времнно
                            Destroy(mell);
                        }
                    }
                    else if (clas == "Head")
                    {
                        tayp = null;
                        if (mel.GetComponent<StolSlot>().team == 1)
                        {
                            canvas.GetComponent<stol>().Ehp -= strong;
                        }
                        else
                        {
                            canvas.GetComponent<stol>().hp -= strong;
                        }
                        canvas.GetComponent<stol>().HpHead();


                        if (host != null)
                        {

                            host.GetComponent<card>().Cast = false;
                           // host.GetComponent<card>().power = false;//времнно
                            host.GetComponent<card>().SReader();//времнно
                        }
                        Destroy(mell);
                    }


                        break;
                case ("Taynt")://провакатор
                    

                    break;
            }
        }
        
    }
    // Update is called once per frame
    void Update()
    {
        
    }
}
