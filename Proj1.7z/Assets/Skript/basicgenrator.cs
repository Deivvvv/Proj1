﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

using System.IO;

public class basicgenrator : MonoBehaviour
{


    public GameObject caree;//шаблон карты
    public GameObject spel;//шаблон способности
    public GameObject bibell;//шаблон библиотек


    public GameObject bookbibl;//хранилище ссылок
    public GameObject book;//бибилотека
    public GameObject can;//ссылка на канвас
    public GameObject bookspell;//ссылка на магазин способностей
    public GameObject kolod;//пространство колоды



    //расширенный блок счетчиков для синхронизации

    private int reca;
    private int recb;
    private int recc;
    private int recd;
    private int rece;



    public string avatar;
    public GameObject avatarGame;

    public int idcard;

    //public int sdksize;
    private bool look;
    private GameObject GG;
    //народы (выбор класса)Темнолесье и беловодье(используют боевых котов)
    //два генератора один для админа и другой для игрока
    private string path;
    private string cod;
    public string names;
    public GameObject nome;//поля ввода


    private gencol sdc = new gencol();
    private carde sg = new carde();
    private general sv = new general();
    private Sinx si = new Sinx();
    private Siny sy = new Siny();

    public string boof;//буфер

    private float manaplus;
    private int mana = 0;
    private int reg;
    private int rel;


    public GameObject adam;//Ближний бой
    public GameObject asdam;//Дальний бой
    public GameObject abroe;//Бронебойность
    public GameObject acrush;//Бронелом

    public GameObject atoh;//Точность
    public GameObject azap;//запугивание

    public GameObject aspas;//спасение 
    public GameObject ashilds;//размер щиты
    public GameObject ashild;//щиты
    public GameObject aship;//шипы
    public GameObject adef;//броня


    public GameObject asal;//Сальто
    public GameObject amobi;//перемещение
    public GameObject aizv;//изворотливость
    public GameObject aura;//куворок

    public GameObject amana;//мана
    public GameObject ahp;//жизнь

    private int rek;//счетчик количества 
    public int ret;


    public int reke;//счетчик количества 
    public int rete;


    private int dam = 0;//Ближний бой
    private int ddam = 0;//Дальний бой
    private int broe = 0;//Бронебойность
    private int crush = 0;//Бронелом

    private int shilds = 1;//размер щиты
    private int shild = 0;//щиты
    private int ship = 0;//шипы    Ненужно!!
    private int def = 0;//броня


    private int spas = 0;//спасение
    private int sal = 0;//салто
    private int toh = 0;//точность
    private int zap = 0;//запугивание


    private int mobi = 0;//перемещение Ненужно!!
    private int izv = 0;//изворотливость
    private int ura = 0;//куворок

    private int hp = 1;//жизнь



    public int sele;//количество спосбностей
    public int sp1;
    public int sp2;
    public int sp3;
    public int sp4;
    public int sp5;

    //цены на способности
    public int sps1;
    public int sps2;
    public int sps3;
    public int sps4;
    public int sps5;



    private int lovk;//ловкость, вычитается броней
    private int relovk;//предел доп характеристик




    public int sizehand;//размер колоды


    //генерато выпоолнен в виде архива, и книг, при созданни магии открывается страница с магической пентограммой 
    public void damp() { dam++; stat(); }
    public void damm() { if (dam > 0) { dam--; } stat(); }

    public void ddamp() { ddam++; stat(); stat(); }
    public void ddamm() { if (ddam > 0) { ddam--; } stat(); }

    public void broep() { broe++; stat(); }
    public void broem() { if (broe > 0) { broe--; } stat(); }

    public void crushp() { crush++; stat(); }
    public void crushm() { if (crush > 0) { crush--; } stat(); }


    public void shildsp() { if (shilds <= 2) { shilds++; } stat(); }
    public void shildsm() { if (shilds > 1) { shilds--; } stat(); }

    public void shildp() { shild++; stat(); }
    public void shildm() { if (shild > 0) { shild--; } stat(); }

    public void shipp() { if (shild > 0) { ship++; stat(); } }
    public void shipm() { if (ship > 0) { ship--; } stat(); }

    public void defp() { def++; stat(); }
    public void defm() { if (def > 0) { def--; } stat(); }



    // private int spas = 0;//спасение
    // private int sal = 0;//салто
    //  private int toh = 0;//точность
    // private int zap = 0;//запугивание
        public void spasp() { if(lovk > 0) { spas++; } stat(); }
        public void spasm() { if (spas > 0) { spas--; } stat(); }

        public void salp() { if(lovk > 3){sal++; stat();} }
        public void salm() { if (sal > 0) { sal--; } stat(); }

        public void tohp() {if(lovk > 0) {toh++; stat();} }
        public void tohm() { if (toh > 0) { toh--; } stat(); }

        public void zapp() {if(lovk > 1){zap++; stat();}  }
        public void zapm() { if (zap > 0) { zap--; } stat(); }



    public void mobip() { if(lovk > 0){ mobi++; stat(); }  }
    public void mobim() { if (mobi > 0) { mobi--; } stat(); }

    public void izvp() { if (lovk > 1) { izv++; stat(); } }
    public void izvm() { if (izv > 0) { izv--; } stat(); }

    public void urap() { if (lovk > 2) { ura++; stat(); } }
    public void uram() { if (ura > 0) { ura--; } stat(); }


    public void hpp() { hp++; stat(); }
    public void hpm() { if (hp > 1) { hp--; } stat(); }


   



    // Start is called before the first frame update
    void Start()
    {
       // adam = GameObject.Find("dam");//Ближний бой
        //asdam = GameObject.Find("sdam");//Дальний бой
        //abroe = GameObject.Find("broe"); //Бронебойность
      //  acrush = GameObject.Find("crush");//Бронелом


      //  ashilds = GameObject.Find("shilds"); //размер щиты
     //   ashild = GameObject.Find("shild"); //щиты
     //   aship = GameObject.Find("ship");//шипы
     //   adef = GameObject.Find("def");//броня


     //   amobi = GameObject.Find("mobi");//перемещение
     //   aizv = GameObject.Find("izv");//изворотливость
     //   aura = GameObject.Find("ura");//куворок

        //ahp = GameObject.Find("hp");//жизнь
        amana = GameObject.Find("mana");
        nome = GameObject.Find("nome");

        //загрузка sdc блока

        path = Path.Combine(Application.dataPath);

        cod = path + "/cold/";
        if (!Directory.Exists(cod)) { Debug.Log(cod); Directory.CreateDirectory(cod); }


        cod = path + "/cold/generalst.json";

        if (!File.Exists(cod)) { sdc.names = "cold1"; sdc.size = 100; File.WriteAllText(cod, JsonUtility.ToJson(sdc));}
        sdc = JsonUtility.FromJson<gencol>(File.ReadAllText(cod));
        //sdksize = sdc.size;
        //names = sdc.names;
        //nome.GetComponent<InputField>().text = names;
        


        
        cod = path + "/cold/" + sdc.names + ".json";
        if (!File.Exists(cod)) {  newbib();  }
            sv = JsonUtility.FromJson<general>(File.ReadAllText(cod));
        sizehand = sv.size;

        //загрузка гильдеиских библиотек
        GG = GameObject.Find("actbib");
        if (GG == null) { GG = GameObject.Find("ButtonNew"); GG.GetComponent<activ>().active(); }

        
        
        cod = path + "/cold/noname.json";
        if (!File.Exists(cod)){ sv.nome = "noname"; sv.pname = "Без гильдии "; sv.size = 0; File.WriteAllText(cod, JsonUtility.ToJson(sv)); cod = path + "/cold/noname"; if (!Directory.Exists(cod)) { Directory.CreateDirectory(cod); } }
        if (GG != null)
        {
            var ta = Instantiate(bibell, new Vector3(0, 0, 0), Quaternion.identity); ta.transform.SetParent(bookbibl.transform); ta.GetComponent<Nom>().num = 0; ta.name = "hunt1"; ta.GetComponent<Nom>().frak = "noname"; ta.GetComponent<Nom>().nema.GetComponent<Text>().text = "Без гильдии ";//тут вписать подержку локализации
        }
        cod = path + "/cold/Hunter.json";
        if (!File.Exists(cod)) { sv.nome = "Hunter"; sv.pname = "Гильдия охотников "; sv.size = 0; File.WriteAllText(cod, JsonUtility.ToJson(sv)); cod = path + "/cold/Hunter"; if (!Directory.Exists(cod)) {Directory.CreateDirectory(cod); } }
        if (GG != null)
        { var ta = Instantiate(bibell, new Vector3(0, 0, 0), Quaternion.identity); ta.transform.SetParent(bookbibl.transform); ta.GetComponent<Nom>().num = 0; ta.name = "hunt2"; ta.GetComponent<Nom>().frak = "Hunter"; ta.GetComponent<Nom>().nema.GetComponent<Text>().text = "Гильдия охотников ";
        }
        cod = path + "/cold/Thief.json";
        if (!File.Exists(cod)) { sv.nome = "Thief"; sv.pname = "Гильдия воров "; sv.size = 0; File.WriteAllText(cod, JsonUtility.ToJson(sv)); cod = path + "/cold/Thief"; if (!Directory.Exists(cod)) {Directory.CreateDirectory(cod); } }
        if (GG != null)
        { var ta = Instantiate(bibell, new Vector3(0, 0, 0), Quaternion.identity); ta.transform.SetParent(bookbibl.transform); ta.GetComponent<Nom>().num = 0; ta.name = "hunt3"; ta.GetComponent<Nom>().frak = "Thief"; ta.GetComponent<Nom>().nema.GetComponent<Text>().text = "Гильдия воров ";
        }
        cod = path + "/cold/Knight.json";
        if (!File.Exists(cod)) { sv.nome = "Knight"; sv.pname = "Гильдия воинов "; sv.size = 0; File.WriteAllText(cod, JsonUtility.ToJson(sv)); cod = path + "/cold/Knight"; if (!Directory.Exists(cod)) { Directory.CreateDirectory(cod); } }
        if (GG != null)
        { var ta = Instantiate(bibell, new Vector3(0, 0, 0), Quaternion.identity); ta.transform.SetParent(bookbibl.transform); ta.GetComponent<Nom>().num = 0; ta.name = "hunt4"; ta.GetComponent<Nom>().frak = "Knight"; ta.GetComponent<Nom>().nema.GetComponent<Text>().text = "Гильдия воинов ";
        }
        cod = path + "/cold/Civilian.json";
        if (!File.Exists(cod)) { sv.nome = "Civilian"; sv.pname = "Ополченцы "; sv.size = 0; File.WriteAllText(cod, JsonUtility.ToJson(sv)); cod = path + "/cold/Civilian"; if (!Directory.Exists(cod)) { Directory.CreateDirectory(cod); } }
        if (GG != null)
        { var ta = Instantiate(bibell, new Vector3(0, 0, 0), Quaternion.identity); ta.transform.SetParent(bookbibl.transform); ta.GetComponent<Nom>().num = 0; ta.name = "hunt5"; ta.GetComponent<Nom>().frak = "Civilian"; ta.GetComponent<Nom>().nema.GetComponent<Text>().text = "Ополченцы ";
        }
        cod = path + "/cold/Slave.json";
        if (!File.Exists(cod)) { sv.nome = "Slave"; sv.pname = "Гильдия работорговцев "; sv.size = 0; File.WriteAllText(cod, JsonUtility.ToJson(sv)); cod = path + "/cold/Slave"; if (!Directory.Exists(cod)) { Directory.CreateDirectory(cod); } }
        if (GG != null)
        { var ta = Instantiate(bibell, new Vector3(0, 0, 0), Quaternion.identity); ta.transform.SetParent(bookbibl.transform); ta.GetComponent<Nom>().num = 0; ta.name = "hunt6"; ta.GetComponent<Nom>().frak = "Slave"; ta.GetComponent<Nom>().nema.GetComponent<Text>().text = "Гильдия работорговцев ";
        }
        cod = path + "/cold/Wild.json";
        if (!File.Exists(cod)) { sv.nome = "Wild"; sv.pname = "Дикари "; sv.size = 0; File.WriteAllText(cod, JsonUtility.ToJson(sv)); cod = path + "/cold/Wild"; if (!Directory.Exists(cod)) { Directory.CreateDirectory(cod); } }
        if (GG != null)
        { var ta = Instantiate(bibell, new Vector3(0, 0, 0), Quaternion.identity); ta.transform.SetParent(bookbibl.transform); ta.GetComponent<Nom>().num = 0; ta.name = "hunt7"; ta.GetComponent<Nom>().frak = "Wild"; ta.GetComponent<Nom>().nema.GetComponent<Text>().text = "Дикари ";
        }
        cod = path + "/cold/Traider.json";
        if (!File.Exists(cod)) { sv.nome = "Traider"; sv.pname = "Торговая гильдия "; sv.size = 0; File.WriteAllText(cod, JsonUtility.ToJson(sv)); cod = path + "/cold/Traider"; if (!Directory.Exists(cod)) { Directory.CreateDirectory(cod); } }
        if (GG != null)
        { var ta = Instantiate(bibell, new Vector3(0, 0, 0), Quaternion.identity); ta.transform.SetParent(bookbibl.transform); ta.GetComponent<Nom>().num = 0; ta.name = "hunt8"; ta.GetComponent<Nom>().frak = "Traider"; ta.GetComponent<Nom>().nema.GetComponent<Text>().text = "Торговая гильдия";
        }
        cod = path + "/cold/Engine.json";
        if (!File.Exists(cod)) { sv.nome = "Engine"; sv.pname = "Гильдия инжинеров "; sv.size = 0; File.WriteAllText(cod, JsonUtility.ToJson(sv)); cod = path + "/cold/Engine"; if (!Directory.Exists(cod)) { Directory.CreateDirectory(cod); } }
        if (GG != null)
        { var ta = Instantiate(bibell, new Vector3(0, 0, 0), Quaternion.identity); ta.transform.SetParent(bookbibl.transform); ta.GetComponent<Nom>().num = 0; ta.name = "hunt9"; ta.GetComponent<Nom>().frak = "Engine"; ta.GetComponent<Nom>().nema.GetComponent<Text>().text = "Гильдия инжинеров ";
        }
        cod = path + "/cold/Gull.json";
        if (!File.Exists(cod)) { sv.nome = "Gull"; sv.pname = "Падальщики "; sv.size = 0; File.WriteAllText(cod, JsonUtility.ToJson(sv)); cod = path + "/cold/Gull"; if (!Directory.Exists(cod)) {Directory.CreateDirectory(cod); } }
        if (GG != null)
        { var ta = Instantiate(bibell, new Vector3(0, 0, 0), Quaternion.identity); ta.transform.SetParent(bookbibl.transform); ta.GetComponent<Nom>().num = 0; ta.name = "hunt10"; ta.GetComponent<Nom>().frak = "Gull"; ta.GetComponent<Nom>().nema.GetComponent<Text>().text = "Падальщики ";
        }
        cod = path + "/cold/HeadHunter.json";
        if (!File.Exists(cod)) { sv.nome = "HeadHunter"; sv.pname = "Гильдия наемников "; sv.size = 0; File.WriteAllText(cod, JsonUtility.ToJson(sv)); cod = path + "/cold/HeadHunter"; if (!Directory.Exists(cod)) { Directory.CreateDirectory(cod); } }
        if (GG != null)
        { var ta = Instantiate(bibell, new Vector3(0, 0, 0), Quaternion.identity); ta.transform.SetParent(bookbibl.transform); ta.GetComponent<Nom>().num = 0; ta.name = "hunt11"; ta.GetComponent<Nom>().frak = "HeadHunter"; ta.GetComponent<Nom>().nema.GetComponent<Text>().text = "Гильдия наемников";
        }
        cod = path + "/cold/Cash.json";
        if (!File.Exists(cod)) { sv.nome = "Cash"; sv.pname = "Роставщики "; sv.size = 0; File.WriteAllText(cod, JsonUtility.ToJson(sv)); cod = path + "/cold/Cash"; if (!Directory.Exists(cod)) {  Directory.CreateDirectory(cod); } }
        if (GG != null)
        {
            var ta = Instantiate(bibell, new Vector3(0, 0, 0), Quaternion.identity); ta.transform.SetParent(bookbibl.transform); ta.GetComponent<Nom>().num = 0; ta.name = "hunt12"; ta.GetComponent<Nom>().frak = "Cash"; ta.GetComponent<Nom>().nema.GetComponent<Text>().text = "Роставщики ";
        }


        //загрузка библиотек

        //var ta = Instantiate(bibell, new Vector3(0, 0, 0), Quaternion.identity);   ta.transform.SetParent(bookbibl.transform); ta.name = "hunt1" + ret; ta.GetComponent<Nom>().nema.GetComponent<Text>().text = sv.pname;









        stat();
        norm();
        loadcard();
        spellplus();
        loadbib();
        }

    // Update is called once per frame
    // void Update()
    // { }
    public void spap()
    {
        switch (sele)
        {
            case (1):
                if((ret != sp2)& (ret != sp3) & (ret != sp4) & (ret != sp5))
                {
                    sp1 = ret;
                    //can.GetComponent<SpelSkroll>().id = ret;//отправка запроса
                    //can.GetComponent<SpelSkroll>().skrol();
                    //sps1 = can.GetComponent<SpelSkroll>().sell;
                    sele = 0;
                }
                
                break;
            case (2):
                if ((ret != sp1) & (ret != sp3) & (ret != sp4) & (ret != sp5))
                {
                    sp2 = ret;
                    //can.GetComponent<SpelSkroll>().id = ret;//отправка запроса
                    //can.GetComponent<SpelSkroll>().skrol();
                    //sps2 = can.GetComponent<SpelSkroll>().sell;
                    sele = 0;
                }
                    
                break;
            case (3):
                if ((ret != sp1) & (ret != sp2) & (ret != sp4) & (ret != sp5))
                {
                    sp3 = ret;
                    //can.GetComponent<SpelSkroll>().id = ret;//отправка запроса
                    //can.GetComponent<SpelSkroll>().skrol();
                    //sps3 = can.GetComponent<SpelSkroll>().sell;
                    sele = 0;
                }
                break;
            case (4):
                if ((ret != sp1) & (ret != sp3) & (ret != sp2) & (ret != sp5))
                {
                    sp4 = ret;
                    //can.GetComponent<SpelSkroll>().id = ret;//отправка запроса
                    //can.GetComponent<SpelSkroll>().skrol();
                    //sps4 = can.GetComponent<SpelSkroll>().sell;
                    sele = 0;
                }
                    
                break;
            case (5):
                if ((ret != sp1) & (ret != sp3) & (ret != sp4) & (ret != sp2))
                {
                    sp5 = ret;
                    //can.GetComponent<SpelSkroll>().id = ret;//отправка запроса
                    //can.GetComponent<SpelSkroll>().skrol();
                    //sps5 = can.GetComponent<SpelSkroll>().sell;
                    sele = 0;
                }
                    
                break;
            default:
                Debug.Log("Выбран номер "+ sele);
                sele = 0;
                ret = 0;
                break;
        }


        //if(ret >=6)
        //{ ret = 0; }

        stat();


    }

    public void loadcard()//выгрузка карт в библиотеку
    {
        Debug.Log(sizehand);
        if (sizehand > 0)
        {
            ret++;
            path = Path.Combine(Application.dataPath);
            cod = path + "/cold/" + sv.nome+ "/" + ret+".json";//шаблон записывается по номеру
            if (File.Exists(cod))
            {
                sg = JsonUtility.FromJson<carde>(File.ReadAllText(cod));


                var ta = Instantiate(caree, new Vector3(0, 0, 0), Quaternion.identity);//вызываемый обект
                ta.transform.SetParent(book.transform);
                ta.name = "card" + ret;
                ta.GetComponent<card>().id = sg.num;//? ret
                ta.GetComponent<card>().neme = sg.names;
                ta.GetComponent<card>().dam = sg.dam;
                ta.GetComponent<card>().ddam = sg.ddam;
                ta.GetComponent<card>().hp = sg.hp;
                //ta.GetComponent<card>().clas = "card";//времнно по умолчанию
                //ta.GetComponent<card>().team = 0;//времнно по умолчанию

                ta.GetComponent<card>().avatar = sg.Imagesss;


                ta.GetComponent<card>().slotName.GetComponent<Text>().text = sg.names;//переправить
                ta.GetComponent<card>().broe = sg.broe;
                ta.GetComponent<card>().crush = sg.crush;
                ta.GetComponent<card>().shilds = sg.shilds;
                ta.GetComponent<card>().shild = sg.shild;
                ta.GetComponent<card>().ship = sg.ship;
                ta.GetComponent<card>().def = sg.def;
                ta.GetComponent<card>().spas = sg.spas;
                ta.GetComponent<card>().sal = sg.sal;
                ta.GetComponent<card>().toh = sg.toh;
                ta.GetComponent<card>().zap = sg.zap;
                ta.GetComponent<card>().mobi = sg.mobi;
                ta.GetComponent<card>().izv = sg.izv;
                ta.GetComponent<card>().ura = sg.ura;
                ta.GetComponent<card>().mane = sg.mana;
                //sg.sizes = sizes;
                ta.GetComponent<card>().sp1 = sg.sp1;
                ta.GetComponent<card>().sp2 = sg.sp2;
                ta.GetComponent<card>().sp3 = sg.sp3;
                ta.GetComponent<card>().sp4 = sg.sp4;
                ta.GetComponent<card>().sp5 = sg.sp5;
            }



            if (ret < sizehand) { loadcard(); } else { ret = 0; }
        }
     
    }
    public void newbib()
    {//создает новую бибилиотеку
        ret++;
        path = Path.Combine(Application.dataPath);
        cod = path + "/cold/cold" + ret + ".json"; 
        Debug.Log(cod);
        if (!File.Exists(cod)) {
            //создание новой библиотеки

            
            sv.nome = "cold" + ret;
            sv.pname = "Тестовая бибилотека " + ret;
            sv.size = 0;
            cod = path + "/cold/" + sv.nome;
            if (!Directory.Exists(cod)) { Debug.Log(cod); Directory.CreateDirectory(cod); }
            cod +=".json";
            File.WriteAllText(cod, JsonUtility.ToJson(sv));
            sdc.names = sv.nome;
            path = Path.Combine(Application.dataPath);
            cod = path + "/cold/generalst.json";
            sdc = JsonUtility.FromJson<gencol>(File.ReadAllText(cod));

            
            
            if((sdc.size !=1)|| (ret != 1))
            {
                var ta = Instantiate(bibell, new Vector3(0, 0, 0), Quaternion.identity);//вызываемый обект
                ta.transform.SetParent(bookbibl.transform);
                ta.GetComponent<Nom>().num = ret;
                ta.name = "but" + ret;
                ta.GetComponent<Nom>().nema.GetComponent<Text>().text = sv.pname;
            }
            


            sdc.size++;
            //sdc.names = sv.nome;
            //sdksize = sdc.size;



            File.WriteAllText(cod, JsonUtility.ToJson(sdc));

            


            GG = GameObject.Find("selbib");
            GG.GetComponent<Text>().text = sv.pname;

            
            ret = 0;
            download();
            sizehand = 0;
        } else { newbib(); }
    }

    public void loadbib()
    {//создает сылки на библиотеки
        if (ret == 0)
        {
            if(sdc.size <= 0) { sdc.size = 599; }

            GG = GameObject.Find("actbib");
            if(GG == null) { GG = GameObject.Find("ButtonNew"); GG.GetComponent<activ>().active(); }
            Debug.Log(GG);

        }
        //print(sdc.size);
        


        ret++;
        path = Path.Combine(Application.dataPath);
        cod = path + "/cold/cold" + ret + ".json";

        GG = GameObject.Find("but" + ret);
        

        if (File.Exists(cod))
        {
            reg++;

            if (GG == null)
            {
                //print("create giper");
                var ta = Instantiate(bibell, new Vector3(0, 0, 0), Quaternion.identity);//вызываемый обект
                ta.transform.SetParent(bookbibl.transform);
                ta.GetComponent<Nom>().num = ret;
                ta.name = "but" + ret;


                sv = JsonUtility.FromJson<general>(File.ReadAllText(cod));

                //GG = GameObject.Find("bibsell");
                //GG.GetComponent<Text>().text = sv.pname;

                ta.GetComponent<Nom>().nema.GetComponent<Text>().text = sv.pname;
            }
            
               
            

        }
        else
        {
            //print("destoi giper" + cod);
            if (GG != null) {  Destroy(GG); sdc.size--;}
        }

        if (reg >= sdc.size) { ret = 0; reg = 0;
            // path = Path.Combine(Application.dataPath);
            //cod = path + "/cold/generalst.json";

            //sdc = JsonUtility.FromJson<gencol>(File.ReadAllText(cod));

            //names = sdc.names;
            //nome.GetComponent<InputField>().text = names;

            path = Path.Combine(Application.dataPath);
            cod = path + "/cold/" + sdc.names + ".json";
            sv = JsonUtility.FromJson<general>(File.ReadAllText(cod));
            sizehand = sv.size;

            GG = GameObject.Find("selbib");
            GG.GetComponent<Text>().text = sv.pname;

            GG = GameObject.Find("actbib");
            GG.active = false;

        } else if ((ret > 600)&(sdc.size < 600)) {
            sdc.size = reg;
            //sdksize = sdc.size;
            cod = path + "/cold/generalst.json";
            File.WriteAllText(cod, JsonUtility.ToJson(sdc));
            loadbib();
        }//лимит библиотек 600 штук для защиты от пользователя
        else { loadbib(); }
    }


   



    public void downSVbib()
    {//запись бибилиотеки
        if(ret == 0) { idcard = 0;
            path = Path.Combine(Application.dataPath);
            cod = path + "/cold/generalst.json";
            sdc = JsonUtility.FromJson<gencol>(File.ReadAllText(cod));
        }
        
        ret++;
        GG = GameObject.Find("card" + ret);
        
        if(GG != null)
        {
            reg++;
            //path = Path.Combine(Application.dataPath);
            //cod = path + "/cold/" + sdc.names + "/"+reg+".json";
            cod = path + "/cold/" + sdc.names + "/" + ret + ".json";

            //cod = path + sizehand;
            sg.names = GG.GetComponent<card>().neme;
            sg.dam = GG.GetComponent<card>().dam;
            sg.ddam = GG.GetComponent<card>().ddam;
            sg.broe = GG.GetComponent<card>().broe;
            sg.crush = GG.GetComponent<card>().crush;
            sg.shilds = GG.GetComponent<card>().shilds;
            sg.shild = GG.GetComponent<card>().shild;
            sg.ship = GG.GetComponent<card>().ship;
            sg.def = GG.GetComponent<card>().def;
            sg.spas = GG.GetComponent<card>().spas;
            sg.sal = GG.GetComponent<card>().sal;
            sg.toh = GG.GetComponent<card>().toh;
            sg.zap = GG.GetComponent<card>().zap;
            sg.mobi = GG.GetComponent<card>().mobi;
            sg.izv = GG.GetComponent<card>().izv;
            sg.ura = GG.GetComponent<card>().ura;
            sg.hp = GG.GetComponent<card>().hp;
            sg.mana = GG.GetComponent<card>().mane;
            sg.num = GG.GetComponent<card>().id;
            sg.sp1 = GG.GetComponent<card>().sp1;
            sg.sp2 = GG.GetComponent<card>().sp2;
            sg.sp3 = GG.GetComponent<card>().sp3;
            sg.sp4 = GG.GetComponent<card>().sp4;
            sg.sp5 = GG.GetComponent<card>().sp5;
            sg.Imagesss = GG.GetComponent<card>().avatar;
            Debug.Log("выполнен"+cod);
            File.WriteAllText(cod, JsonUtility.ToJson(sg));
        }else
        {
            //path = Path.Combine(Application.dataPath);
            //cod = path + "/cold/" + sv.nome + "/" + ret + ".json";
            cod = path + "/cold/" + sdc.names + "/" + ret + ".json";
            print(cod);
            File.Delete(cod);
        }


        if (ret >= sizehand) { ret = 0; reg = 0;
            path = Path.Combine(Application.dataPath);
            cod = path + "/cold/" + sdc.names +".json";
            sv.size = sizehand;
            File.WriteAllText(cod, JsonUtility.ToJson(sv));
            norm();//активировал
        } else { downSVbib(); }
    }



    
    public void newdown()//смена библотеки.. аналогично для колоды
    {
        //сделать код включть, выключить для вызова команд

        idcard = 0;
        download();
        path = Path.Combine(Application.dataPath);
        if (sele == 0) { cod = path + "/cold/" + boof + ".json"; Debug.Log(cod); if (!File.Exists(cod)) { cod = path + "/cold/" + sdc.names + ".json"; } }
        //cod = path + "/cold/" + sdc.names + ".json"; }
        else
        {
            cod = path + "/cold/cold" + sele + ".json";
            sele = 0;
        }

        sv = JsonUtility.FromJson<general>(File.ReadAllText(cod));
        sizehand = sv.size;
        path = Path.Combine(Application.dataPath);
        cod = path + "/cold/generalst.json";
        //names = sv.nome;
        sdc.names =sv.nome;
        //sdc.size = sdksize;
        print(sdc.size );
        print(cod);
        File.WriteAllText(cod, JsonUtility.ToJson(sdc));

        GG = GameObject.Find("actbib");
        if(GG !=null)
        {
            GG.active = false;
        }
        GG = GameObject.Find("selbib");
        GG.GetComponent<Text>().text = sv.pname;
        Debug.Log("st2");
        sele = 0;
        norm();
        loadcard();
        
    }

    public void reload()
    {
        sele = 0;
        newdown();
    }



    public void delbib(){//Удаление библиотеки
        //удаляем текущую библиотеку
        //смотрим количесвто библиотек
        //если есть сущестувюущие, то перходим на них

        //Удалить ссылку на библиотеку
        //загрузить новую библиотеку
        
        


            if (ret == 0)
            {
                path = Path.Combine(Application.dataPath);
                cod = path + "/cold/" + sv.nome + ".json";
                File.Delete(cod);
                cod = path + "/cold/" + sv.nome + "/";
                Directory.Delete(cod, true);

            //этот участок перейнесен в участок созданяи ссылок
            //sdksize--;
            //sdc.size--;// = sdksize;
            //GG = GameObject.Find("actbib");
            //if (GG == null) { GG = GameObject.Find("ButtonNew"); GG.GetComponent<activ>().active(); }




            download();

            }
            if(sdc.size == 1) {  newbib(); ret++; delbib(); }
        else
        {
            //ret++;

            cod = path + "/cold/cold" + ret + ".json";
            if (File.Exists(cod))
            {

                cod = path + "/cold/generalst.json";
                sdc.names = "cold" + ret;
                File.WriteAllText(cod, JsonUtility.ToJson(sdc));

                cod = path + "/cold/" + sdc.names + ".json";
                sv = JsonUtility.FromJson<general>(File.ReadAllText(cod));
                sizehand = sv.size;
                print(sdc.size);



                GG = GameObject.Find("selbib");
                GG.GetComponent<Text>().text = sv.pname;
                ret = 0;
                loadcard();
                loadbib();
            }
            else { ret++; delbib(); }
        }
        //ret++;

                
    }
    
    private void download()//выгрузка библотеки
    {
        reg++;
        GG = GameObject.Find("card" + reg);
        if(GG != null)
        {
            Destroy(GG);
        }

        if(reg >= sizehand) { reg = 0; } else { download(); }
    }
    //редактирывание происходи путем полученяи ссылки на оригинал





    public void stat()
    {
        //раздел загрузки колоды
        lovk = 5;
        if (def > 0) { lovk -= 4; }
        if (shild > 0)
        {
            switch (shilds)
            {
                case (1):
                    lovk -= 1;
                    break;
                case (2):
                    lovk -= 2;
                    break;
                case (3):
                    lovk -= 3;
                    break;
            }

        }
        else { ship = 0; }

         //для ограничения количества способностей
        relovk = 0;
        if (ura> 0){ relovk++; }
        if (izv > 0) { relovk++; }
        if (mobi > 0) { relovk++; } 
        if (def > 0) { relovk++; }
        if (ship > 0) { relovk++; }
        if (shild > 0) { relovk++; }
        if (spas > 0) { relovk++; }
        if (sal > 0) { relovk++; }
        if (toh > 0) { relovk++; }
        if (zap > 0) { relovk++; }
        
        //          жизнь /     куворок / изворотливость / перемещение / броня /   шипы          /щиты + размер щиты  / Бронелом  /     Бронебойность /  Дальний бой / Ближний бой / cпасение /   сальто /   точность /  запугивание
        manaplus = (hp * 1f) + (ura * 4f) + (izv * 2f) + (mobi * 1f) + (def * 4f) + (ship * 1f) + (shild * (shilds + 1f)) + (crush * 4f) + (broe * 3f) + (ddam * 2f) + (dam * 1f) + (spas * 1) + (sal * 4) + (toh * 1) + (zap * 2) + sps1 + sps2 + sps3 + sps4 +sps5;
        mana = Mathf.RoundToInt(((manaplus) / 4f) + 0.3f);////2f
        if(mana == 0) { mana = 1; }


        names = nome.GetComponent<InputField>().text;
        
        //avatarGame.GetComponent<InputField>().text = Avatar;

        if (avatar == "")
        {

            avatar = "Civ0";//тут будет выбор партрета
        }

        avatarGame.GetComponent<Text>().text = avatar;

        if(sp1 == 0) { sps1 = 0;
            GG = GameObject.Find("spellDell1");
            GG.GetComponent<Button>().interactable = false;
        } else {
            can.GetComponent<SpelSkroll>().id = sp1;//отправка запроса
            can.GetComponent<SpelSkroll>().skrol();
            sps1 = can.GetComponent<SpelSkroll>().sell;

            GG = GameObject.Find("spellDell1");
            GG.GetComponent<Button>().interactable = true;
        }
        if (sp2 == 0) { sps2 = 0;
            GG = GameObject.Find("spellDell2");
            GG.GetComponent<Button>().interactable = false;
        }
        else
        {
            can.GetComponent<SpelSkroll>().id = sp2;//отправка запроса
            can.GetComponent<SpelSkroll>().skrol();
            sps2 = can.GetComponent<SpelSkroll>().sell;
            GG = GameObject.Find("spellDell2");
            GG.GetComponent<Button>().interactable = true;
        }
        if (sp3 == 0) { sps3 = 0;
            GG = GameObject.Find("spellDell3");
            GG.GetComponent<Button>().interactable = false;
        }
        else
        {
            can.GetComponent<SpelSkroll>().id = sp3;//отправка запроса
            can.GetComponent<SpelSkroll>().skrol();
            sps3 = can.GetComponent<SpelSkroll>().sell;
            GG = GameObject.Find("spellDell3");
            GG.GetComponent<Button>().interactable = true;
        }
        if (sp4 == 0) { sps4 = 0;
            GG = GameObject.Find("spellDell4");
            GG.GetComponent<Button>().interactable = false;
        }
        else
        {
            can.GetComponent<SpelSkroll>().id = sp4;//отправка запроса
            can.GetComponent<SpelSkroll>().skrol();
            sps4 = can.GetComponent<SpelSkroll>().sell;

            GG = GameObject.Find("spellDell4");
            GG.GetComponent<Button>().interactable = true;
        }
        if (sp5 == 0) { sps5 = 0;
            GG = GameObject.Find("spellDell5");
            GG.GetComponent<Button>().interactable = false;
        }
        else
        {
            can.GetComponent<SpelSkroll>().id = sp5;//отправка запроса
            can.GetComponent<SpelSkroll>().skrol();
            sps5 = can.GetComponent<SpelSkroll>().sell;

            GG = GameObject.Find("spellDell5");
            GG.GetComponent<Button>().interactable = true;
        }


        adam.GetComponent<Text>().text = "" + dam;//Ближний бой
        asdam.GetComponent<Text>().text = "" + ddam;//Дальний бой
        abroe.GetComponent<Text>().text = "" + broe;//Бронебойность
        acrush.GetComponent<Text>().text = "" + crush;//Бронелом

        switch (shilds)
        {
            // case (0):
            //  boof = "нету";
            //   break;
            case (1):
                boof = "Малый щит";
                break;
            case (2):
                boof = "Щит";
                break;
            case (3):
                boof = "Ростовой щит";
                break;
        }
        ashilds.GetComponent<Text>().text = boof;//размер щиты
        ashild.GetComponent<Text>().text = "" + shild;//щиты
        aship.GetComponent<Text>().text = "" + ship;//шипы
        adef.GetComponent<Text>().text = "" + def;//броня



        aspas.GetComponent<Text>().text = "" + spas;//щиты
        atoh.GetComponent<Text>().text = "" + toh;//щиты
        azap.GetComponent<Text>().text = "" + zap;//шипы
        asal.GetComponent<Text>().text = "" + sal;//броня


        amobi.GetComponent<Text>().text = "" + mobi;//перемещение
        aizv.GetComponent<Text>().text = "" + izv;//изворотливость
        aura.GetComponent<Text>().text = "" + ura;//куворок

        ahp.GetComponent<Text>().text = "" + hp;//жизнь
        amana.GetComponent<Text>().text = "" + mana;


        GG = GameObject.Find("spellname");
        if (sp1 != 0)
        {
            can.GetComponent<SpelSkroll>().id = sp1;//отправка запроса
            can.GetComponent<SpelSkroll>().skrol();
            boof = "" + can.GetComponent<SpelSkroll>().name;
        }
        else { boof = ""; }
        if (sp2 != 0)
        {
            can.GetComponent<SpelSkroll>().id = sp2;//отправка запроса
        can.GetComponent<SpelSkroll>().skrol();
        boof += "\n" + can.GetComponent<SpelSkroll>().name;
        }
        else { boof += "\n"; }
        if (sp3 != 0)
            {
                can.GetComponent<SpelSkroll>().id = sp3;//отправка запроса
        can.GetComponent<SpelSkroll>().skrol();
        boof += "\n" + can.GetComponent<SpelSkroll>().name;

        }
        else { boof += "\n"; }
        if (sp4 != 0)
                {
                    can.GetComponent<SpelSkroll>().id = sp4;//отправка запроса
        can.GetComponent<SpelSkroll>().skrol();
        boof += "\n" + can.GetComponent<SpelSkroll>().name;

        }
        else { boof += "\n"; }
        if (sp5 != 0)
                    {
                        can.GetComponent<SpelSkroll>().id = sp5;//отправка запроса
        can.GetComponent<SpelSkroll>().skrol();
        boof += "\n" + can.GetComponent<SpelSkroll>().name;

        }
        else { boof += "\n"; }
        GG.GetComponent<Text>().text = "" + boof;


        GG = GameObject.Find("sps1");

    if (sps1 != 0)
        {
            ret = sps1 / 4;
            reg = sps1 - ret * 4;
            if (ret == 0) { GG.GetComponent<Text>().text = ""; } else { GG.GetComponent<Text>().text = "" + ret; }
            if (reg == 0) { } else { if (ret != 0) { GG.GetComponent<Text>().text += " + "; } GG.GetComponent<Text>().text += reg + "/4"; }
        }
        else { GG.GetComponent<Text>().text = "0"; }


        GG = GameObject.Find("sps2");
    if (sps2 != 0)
        {
        ret = sps2 / 4;
        reg = sps2 - ret * 4;
        if (ret == 0) { GG.GetComponent<Text>().text = ""; } else { GG.GetComponent<Text>().text = "" + ret; }
            if (reg == 0) { } else { if (ret != 0) { GG.GetComponent<Text>().text += " + "; } GG.GetComponent<Text>().text += reg + "/4"; }
        }
        else { GG.GetComponent<Text>().text = "0"; }

        GG = GameObject.Find("sps3");
    if (sps3 != 0)
        {
        ret = sps3 / 4;
        reg = sps3 - ret * 4;
        if (ret == 0) { GG.GetComponent<Text>().text = ""; } else { GG.GetComponent<Text>().text = "" + ret; }
            if (reg == 0) { } else { if (ret != 0) { GG.GetComponent<Text>().text += " + "; } GG.GetComponent<Text>().text += reg + "/4"; }
        }
        else { GG.GetComponent<Text>().text = "0"; }


        GG = GameObject.Find("sps4");
    if (sps4 != 0)
        {
        ret = sps4 / 4;
        reg = sps4 - ret * 4;
        if (ret == 0) { GG.GetComponent<Text>().text = ""; } else { GG.GetComponent<Text>().text = "" + ret; }
            if (reg == 0) { } else { if (ret != 0) { GG.GetComponent<Text>().text += " + "; } GG.GetComponent<Text>().text += reg + "/4"; }
        }
        else { GG.GetComponent<Text>().text = "0"; }



        GG = GameObject.Find("sps5");
    if (sps5 != 0)
    {
        ret = sps5 / 4;
        reg = sps5 - ret * 4;
        if (ret == 0) { GG.GetComponent<Text>().text = ""; } else { GG.GetComponent<Text>().text = "" + ret; }
        if (reg == 0) { } else {   if (ret != 0) { GG.GetComponent<Text>().text += " + "; } GG.GetComponent<Text>().text += reg + "/4"; }
    }
        else { GG.GetComponent<Text>().text = "0"; }



        GG = GameObject.Find("spsall");
        ret = sps1 + sps2 + sps3 +sps4 +sps5;
    if (ret != 0)
        {
            ret = ret / 4;
            reg = (sps1 + sps2 + sps3 + sps4 + sps5) - ret * 4;
            if (ret == 0) { GG.GetComponent<Text>().text = ""; } else { GG.GetComponent<Text>().text = "" + ret; }
            if (reg == 0) { } else { if (ret != 0) { GG.GetComponent<Text>().text += " + "; } GG.GetComponent<Text>().text += reg + "/4"; }
        }
        else { GG.GetComponent<Text>().text = "0"; }

        ret = 0;
        reg = 0;

    }
    public void spellplus()
    {
        //цикл поиска свобойдно позиции в колоде var a
        reg++;
        /*отправляем запрос в библотеку
         * если возвращенный запрос не равен 0 и сответсвует требованиям производим выгрузку данных, 
         */
        can.GetComponent<SpelSkroll>().id = reg;//отправка запроса
        can.GetComponent<SpelSkroll>().skrol();
        //Debug.Log("spel"+reg);


        if (can.GetComponent<SpelSkroll>().id == 0) { reg = 0; GG = GameObject.Find("spelmen"); GG.active = false; }
        else//выгрузка результата
        {
            var ta = Instantiate(spel, new Vector3(0, 0, 0), Quaternion.identity);//вызываемый обект
            ta.transform.SetParent(bookspell.transform);
            //ta.GetComponent<card>().neme = sg.names;//переправить
            ta.GetComponent<Nom>().num = reg;
            ta.GetComponent<Nom>().nema.GetComponent<Text>().text = can.GetComponent<SpelSkroll>().name;
            ta.GetComponent<Nom>().sell.GetComponent<Text>().text = "" +can.GetComponent<SpelSkroll>().sell;
            //Debug.Log("spelbook" + reg);
            spellplus();
        }
    }
    public void CardData()//получение данных с оригинала
    {
        GG = GameObject.Find("card"+idcard);

        //cod = path + sizehand;
        nome.GetComponent<InputField>().text = GG.GetComponent<card>().neme;
        //nome.GetComponent<Text>().text = names;
        dam = GG.GetComponent<card>().dam;
        ddam = GG.GetComponent<card>().ddam;
        broe = GG.GetComponent<card>().broe;
        crush = GG.GetComponent<card>().crush;
        shilds = GG.GetComponent<card>().shilds;
        shild = GG.GetComponent<card>().shild;
        ship = GG.GetComponent<card>().ship;
        def = GG.GetComponent<card>().def;
        spas = GG.GetComponent<card>().spas;
        sal = GG.GetComponent<card>().sal;
        toh = GG.GetComponent<card>().toh;
        zap = GG.GetComponent<card>().zap;
        mobi = GG.GetComponent<card>().mobi;
        izv = GG.GetComponent<card>().izv;
        ura = GG.GetComponent<card>().ura;
        hp = GG.GetComponent<card>().hp;

        sp1 = GG.GetComponent<card>().sp1;
        sp2 = GG.GetComponent<card>().sp2;
        sp3 = GG.GetComponent<card>().sp3;
        sp4 = GG.GetComponent<card>().sp4;
        sp5 = GG.GetComponent<card>().sp5;
        avatar = GG.GetComponent<card>().avatar;
        stat();
    }


    public void SartRed()//запуск редактирывания карты
    {
        //передать id карты в хранилище idcard
        if(idcard != 0)
        {
            stat();
            path = Path.Combine(Application.dataPath);



            cod = path + "/cold/" + sv.nome + ".json";//шаблон записывается по номеру

            File.WriteAllText(cod, JsonUtility.ToJson(sv));
           /* path += "/cold/" + sv.nome + "/";
            Debug.Log(path);//



            if (!Directory.Exists(path)) { Directory.CreateDirectory(path); }//создание папки
                                                                             //шаблон обЪявлен
                                                                             */
            //names = nome.GetComponent<InputField>().text;
            //cod = path + idcard + ".json";
            //if ("" == names) { names = "Артур"; }


            GG = GameObject.Find("card"+idcard);

            GG.GetComponent<card>().neme = names;//переправить
            GG.GetComponent<card>().slotName.GetComponent<Text>().text = names;//переправить
            GG.GetComponent<card>().dam = dam;
            GG.GetComponent<card>().ddam = ddam;
            GG.GetComponent<card>().hp = hp;

            //GG.name = "card" + sizehand;
            //GG.GetComponent<card>().id = sizehand;//? ret

            GG.GetComponent<card>().avatar = avatar;


            GG.GetComponent<card>().avatarImage.GetComponent<Image>().sprite = Resources.Load<Sprite>("Avatar/" + avatar);


            GG.GetComponent<card>().broe = broe;
            GG.GetComponent<card>().crush = crush;
            GG.GetComponent<card>().shilds = shilds;
            GG.GetComponent<card>().shild = shild;
            GG.GetComponent<card>().ship = ship;
            GG.GetComponent<card>().def = def;
            GG.GetComponent<card>().spas = spas;
            GG.GetComponent<card>().sal = sal;
            GG.GetComponent<card>().toh = toh;
            GG.GetComponent<card>().zap = zap;
            GG.GetComponent<card>().mobi = mobi;
            GG.GetComponent<card>().izv = izv;
            GG.GetComponent<card>().ura = ura;
            GG.GetComponent<card>().mane = mana;
            GG.GetComponent<card>().sp1 = sp1;
            GG.GetComponent<card>().sp2 = sp2;
            GG.GetComponent<card>().sp3 = sp3;
            GG.GetComponent<card>().sp4 = sp4;
            GG.GetComponent<card>().sp5 = sp5;
            GG.GetComponent<card>().statys();
            idcard = 0;
        }
        


    }
   
        
public void saveg()
    {
        boof = "";
        path = Path.Combine(Application.dataPath);
        //тестовое поле
        if (reke > sizehand)
        {
            //boof = path + "/cold/" + sdc.names + "/" + sizehand + ".json";
            boof = "conect";
            Debug.Log("Это   " + boof);
            rete = 2;

        }
        else if (rete == 0)
        {
            reke++;
            if(reke == 0) { reke = 1; }
            // sv.nome = "cold1";
            GG = GameObject.Find("card"+ reke);

            cod = path + "/cold/" + sdc.names +"/"+ reke + ".json";//шаблон записывается по номеру
            if ((!File.Exists(cod))&(GG == null))
            {

                Debug.Log("OK YEs");
                boof = "conect";
                    rete++;
            }
            else { saveg(); }
        }

        if (boof == "conect")
        {

            sizehand++;
            //if(reke == 0) { saveg(); }

            // Debug.Log("Это   " + boof);

            //цикл иницализации карты



            //sv = JsonUtility.FromJson<general>(File.ReadAllText(cod));
            sv.size = sizehand;
            //cod = path + "/cold/";
            Debug.Log("OK");
            // File.Exists
            //if (!Directory.Exists(cod)) { Debug.Log(cod); Directory.CreateDirectory(cod); }


            cod = path + "/cold/" + sdc.names + ".json";//шаблон записывается по номеру







            //File.Delete(path);
            File.WriteAllText(cod, JsonUtility.ToJson(sv));
            sv = JsonUtility.FromJson<general>(File.ReadAllText(cod));
            cod = path + "/cold/" + sdc.names + "/";
            Debug.Log(path);//



            if (!Directory.Exists(cod)) { Directory.CreateDirectory(cod); }//создание папки
                                                                           //шаблон обЪявлен

            //names = nome.GetComponent<InputField>().text;



            stat();
            //sizehand++;
            idcard = 0;


            //cod = path + sizehand + ".json";
            if ("" == names) { names = "Артур"; }




            var ta = Instantiate(caree, new Vector3(0, 0, 0), Quaternion.identity);//вызываемый обект
            ta.transform.SetParent(book.transform);
            ta.GetComponent<card>().neme = names;//переправить
            ta.GetComponent<card>().slotName.GetComponent<Text>().text = names;//переправить
            ta.GetComponent<card>().dam = dam;
            ta.GetComponent<card>().ddam = ddam;
            ta.GetComponent<card>().hp = hp;
            //ta.GetComponent<card>().clas = "card";//времнно по умолчанию
            //ta.GetComponent<card>().team = 0;//времнно по умолчанию


            if (rete == 2)
            {
                ta.name = "card" + sizehand;
                ta.GetComponent<card>().id = sizehand;//? ret 
            }
            else
            {
                ta.name = "card" + reke;
                ta.GetComponent<card>().id = reke;//? ret 
            }


            ta.GetComponent<card>().avatar = avatar;



            ta.GetComponent<card>().broe = broe;
            ta.GetComponent<card>().crush = crush;
            ta.GetComponent<card>().shilds = shilds;
            ta.GetComponent<card>().shild = shild;
            ta.GetComponent<card>().ship = ship;
            ta.GetComponent<card>().def = def;
            ta.GetComponent<card>().spas = spas;
            ta.GetComponent<card>().sal = sal;
            ta.GetComponent<card>().toh = toh;
            ta.GetComponent<card>().zap = zap;
            ta.GetComponent<card>().mobi = mobi;
            ta.GetComponent<card>().izv = izv;
            ta.GetComponent<card>().ura = ura;
            ta.GetComponent<card>().mane = mana;
            ta.GetComponent<card>().sp1 = sp1;
            ta.GetComponent<card>().sp2 = sp2;
            ta.GetComponent<card>().sp3 = sp3;
            ta.GetComponent<card>().sp4 = sp4;
            ta.GetComponent<card>().sp5 = sp5;



            reke = 0;
            rete = 0;
        }


       

        //ta.GetComponent<card>().sposz();

        /*
                names = nome.GetComponent<InputField>().text;
                cod = path + sizehand +".json";
                if ("" == names) { names = "Артур"; }
                    sg.names = names;
                Debug.Log(names);
                sg.dam = dam;
                sg.ddam = ddam;
                sg.broe = broe;
                sg.crush = crush;
                sg.shilds = shilds;
                sg.shild = shild;
                sg.ship = ship;
                sg.def = def;
                sg.spas = spas;
                sg.sal = sal;
                sg.toh = toh;
                sg.zap = zap;
                sg.mobi = mobi;
                sg.izv = izv;
                sg.ura = ura;
                sg.hp = hp;
                sg.mana = mana;
                sg.num = sizehand;

                sg.sp1 = sp1;
                sg.sp2 = sp2;
                sg.sp3 = sp3;
                sg.sp4 = sp4;
                sg.sp5 = sp5;

                File.WriteAllText(cod, JsonUtility.ToJson(sg));

                var ta = Instantiate(caree, new Vector3(0, 0, 0), Quaternion.identity);//вызываемый обект
                ta.transform.SetParent(book.transform);
                ta.GetComponent<card>().neme = sg.names;//переправить
                ta.GetComponent<card>().slotName.GetComponent<Text>().text = sg.names;//переправить
                ta.GetComponent<card>().dam = sg.dam;
                ta.GetComponent<card>().ddam = sg.ddam;
                ta.GetComponent<card>().hp = sg.hp;
                ta.GetComponent<card>().clas = "card";//времнно по умолчанию
                ta.GetComponent<card>().team = 0;//времнно по умолчанию

                ta.name = "card" + sizehand;
                ta.GetComponent<card>().id = sizehand;//? ret

                ta.GetComponent<card>().broe = sg.broe;
                ta.GetComponent<card>().crush = sg.crush;
                ta.GetComponent<card>().shilds = sg.shilds;
                ta.GetComponent<card>().shild = sg.shild;
                ta.GetComponent<card>().ship = sg.ship;
                ta.GetComponent<card>().def = sg.def;
                ta.GetComponent<card>().spas = sg.spas;
                ta.GetComponent<card>().sal = sg.sal;
                ta.GetComponent<card>().toh = sg.toh;
                ta.GetComponent<card>().zap = sg.zap;
                ta.GetComponent<card>().mobi = sg.mobi;
                ta.GetComponent<card>().izv = sg.izv;
                ta.GetComponent<card>().ura = sg.ura;
                ta.GetComponent<card>().mane = sg.mana;
                ta.GetComponent<card>().sp1 = sg.sp1;
                ta.GetComponent<card>().sp2 = sg.sp2;
                ta.GetComponent<card>().sp3 = sg.sp3;
                ta.GetComponent<card>().sp4 = sg.sp4;
                ta.GetComponent<card>().sp5 = sg.sp5;
        */


        //norm();

    }



    private void norm()
    {
         
            path = Path.Combine(Application.dataPath);

            cod = path + "/cold/" + sdc.names + ".json";
            sv = JsonUtility.FromJson<general>(File.ReadAllText(cod));


            //path += "/cold/" + sv.nome + "/";
        
        //расширить механику под способности
        rek++;
        //Debug.Log("norm 1");


        




        Debug.Log(cod);
        cod = path + "/cold/" + sv.nome + "/" + rek +".json";// File.Exists
        //Debug.Log(cod);
        //цикл сортировки простраснтва колоды
        if (!File.Exists(cod)) 
        {
            //Debug.Log("delok");
            if (ret == 0)
            {
                ret = rek;
                sele--;
            }
            sele++;//|||| продолжить от сюда
        }
        else
        {
            if (ret != 0)
            {//если ret++ не null
             //cod = path + rek;

                //код переопределения колоды
                //rel = -1;
                NormPS();

                //код переопределенгия библиотеки
                /*
                sg = JsonUtility.FromJson<carde>(File.ReadAllText(cod));
                sg.num = ret;
                cod = path + "/cold/" + sv.nome + "/" + ret + ".json";
                File.WriteAllText(cod, JsonUtility.ToJson(sg));
                //path = path + rek +".json" ;
                cod = path + "/cold/" + sv.nome + "/" + rek + ".json";
                Debug.Log(cod);

                //File.Move(path, cod );
                //File.Delete(cod + ".json");
                File.Delete(cod);
                //sele++;*/
                ret++;
            }
        }
        if (rek <= sizehand)
        {
            
            norm();
        }
        else
        {
            //sizehand -= sele;//?
            //sv.size = sizehand;


            sizehand = ret;//?
            sv.size = sizehand;


            // names = sv.nome;
             path = Path.Combine(Application.dataPath);
             cod = path + "/cold/" + sv.nome + ".json";

              File.WriteAllText(cod, JsonUtility.ToJson(sv));

            sele = 0;





            rek = 0;
            ret = 0;

        }
    }



    private void NormPS()
    {
        //процедура работы с колдоами
        //rel указатель шага
        //reg указатель библиотеки
        
        
        if (sdc.size > 0)
        {
            if (reca == 0)
            {

                /* иструкция
                 * 
                 * Получаем количество колод и библотект из general
                 * 
                 * если библиотеки = 0 выключаем?
                 * если задиствованых библиотек(режимов) = 0 выключаем
                 * если количество колод =0 сбрасываем и смотрим следующую библиотеку
                 * 
                 * производим проверку обновляемой библиотеки и потом смотрим, относится ли колода к этой фракции илил библотеке
                 * при фракции берем pcard 
                 * при библилиотеке мах ccard  мин pcard
                 * 
                 * 
                 * reca служит для выбора библотеки
                 * recb служит для окнчания проверки генерального фаила
                 * recc служит для индикации окнчания проверки
                 * recd указатель номеар обрабатываемой карты
                 * rece указывает на обрабатываему карту
                 * rel
                 * reg
                */
                //получаем количество задеиствованых библиотек

                cod = path + "/colods/" + sdc.names + "/general.json";//шаблон записывается по номеру
                if (!File.Exists(cod)) { si.bibsize = 0; } else { si = JsonUtility.FromJson<Sinx>(File.ReadAllText(cod)); }
            }

           



            //проверка всех библиотек
            if ((si.bibsize > 0) & (si.bibsize < rel))
            {
                if ( (sdc.names == "noname")|| (sdc.names == "Hunter") || (sdc.names == "Thief") || (sdc.names == "Knight") || (sdc.names == "Civilian") || (sdc.names == "Slave") || (sdc.names == "Wild") || (sdc.names == "Traider") || (sdc.names == "Engine") || (sdc.names == "Gull") || (sdc.names == "HeadHunter") || (sdc.names == "Cash"))
                {
                    //процедура считывания gen_colod
                    if (recb == 0)
                    {
                        reca++;

                        //нужна ген колода по бибилотеке

                        boof = "cold" + reca;
                        cod = path + "/colods/" + boof + "/gen_colod.json";//шаблон записывается по номеру

                        if (File.Exists(cod))
                        {
                            si = JsonUtility.FromJson<Sinx>(File.ReadAllText(cod));
                            recb++;//указатель цикла проверки библиотеки
                                   //reca = 0;//?
                                   //NormPS();
                        }
                        else { NormPS(); }
                    }


                    if (si.cardes > 0)//указатель библиотеки
                    {
                        if (si.cardes <= recc)
                        {
                            rel++;
                            recc = 0;
                            recb = 0;
                            recd = 0;
                            NormPS();
                        }
                        else
                        {
                            //берем колоду
                            if (rece == 0)
                            {
                                recd++;
                                cod = path + "/colods/" + boof + "/colod" + recd + ".json";
                                if (File.Exists(cod))
                                {
                                    //проверка данных колоды, читаем тег
                                    si = JsonUtility.FromJson<Sinx>(File.ReadAllText(cod));

                                    //rece++;
                                    if (si.tag != sdc.names)
                                    {
                                        //нам неинтересна эта колода
                                        recc++;

                                        recb = 0;
                                        NormPS();
                                    }


                                    //NormPS();
                                }
                                else { NormPS(); }


                            }
                            rece++;

                            cod = path + "/colods/" + boof + "/colod" + recd + "/" + rece + ".json";


                            sy = JsonUtility.FromJson<Siny>(File.ReadAllText(cod));

                            //номер rek устанавливается на ret
                            if(sy.cardes == rek)
                            {
                                sy.cardes = 0;
                                // sy.cardes = ret;
                                File.WriteAllText(cod, JsonUtility.ToJson(sy));

                            }


                            if (si.pcard <= rece)//продолить здесь rece
                            {

                                rece = 0;
                                recc++;
                                NormPS();
                            }
                            else { NormPS(); }
                        }
                    }
                    else { recb = 0; rel++; NormPS(); }
                }
                else
                {
                    //варинт для пользовательской колоды

                    //процедура считывания gen_colod
                    if (recb == 0)
                    {
                        reca++;
                        boof = sdc.names;
                        cod = path + "/colods/" + boof + "/gen_colod.json";//шаблон записывается по номеру

                        if (File.Exists(cod))
                        {
                            si = JsonUtility.FromJson<Sinx>(File.ReadAllText(cod));
                            recb++;//указатель цикла проверки библиотеки
                                   //reca = 0;//?
                                   //NormPS();
                        }
                        else { si.bibsize = 0; NormPS(); }//аварийный сброс
                    }


                    if (si.cardes > 0)//указатель библиотеки
                    {
                        //берем  колоды в текущей библотеке


                        if (si.cardes <= recc)
                        {
                            rel++;
                            recc = 0;
                            recb = 0;
                            recd = 0;
                            NormPS();
                        }
                        else
                        {
                            //берем колоду
                            if (rece == 0)
                            {
                                recd++;
                                cod = path + "/colods/" + boof + "/colod" + recd + ".json";
                                if (File.Exists(cod))
                                {
                                    //проверка данных колоды, читаем тег
                                    si = JsonUtility.FromJson<Sinx>(File.ReadAllText(cod));
                                    
                                    //NormPS();
                                }
                                else { NormPS(); }


                            }
                            rece++;
                            if(rece > si.pcard)
                            {
                                cod = path + "/colods/" + boof + "/colod" + recd + "/" + rece + ".json";


                                sy = JsonUtility.FromJson<Siny>(File.ReadAllText(cod));

                                //номер rek устанавливается на ret
                                if (sy.cardes == rek)
                                {
                                    sy.cardes = 0;
                                    // sy.cardes = ret;
                                    File.WriteAllText(cod, JsonUtility.ToJson(sy));

                                }
                            }
                            


                            if (si.ccard <= rece)//продолить здесь rece
                            {

                                rece = 0;
                                recc++;
                                NormPS();
                            }
                            else { NormPS(); }
                        }
                    }
                    else { recb = 0; rel++; NormPS(); }


                }
            }
            /*else
            {
                //окончание процедуры

                rel = 0;
                reca = 0;
                recb = 0;
                recc = 0;
                recd = 0;
                rece = 0;
            }*/
            rel = 0;
            reca = 0;
            recb = 0;
            recc = 0;
            recd = 0;
            rece = 0;


        }
    }

}



public class general
{
    public string nome;//Name
    public string pname;//публичное имя
    public int size;//нужно добавить считывание обема буфера
}


    public class carde
    {
    public string Imagesss;
        public string names;

        public int num;//номер объекта

        public int dam;//Ближний бой
        public int ddam;//Дальний бой
        public int broe;//Бронебойность
        public int crush;//Бронелом

        public int shilds;//размер щиты
        public int shild;//щиты
        public int ship;//шипы
        public int def;//броня


        public int spas;//спасение
        public int sal;//салто
        public int toh;//точность
        public int zap;//запугивание


        public int mobi;//перемещение
        public int izv;//изворотливость
        public int ura;//куворок

        public int hp;//жизнь
        public int mana;

        //public int sizes;//количество спосбностей

        public int sp1;
        public int sp2;
        public int sp3;
        public int sp4;
        public int sp5;
    }
    
public class gencol
{
    public string names;//название заданной колоды
    public int size;//количесвто библиотек
}

public class Sinx
{
    //файл синхронизации

    public int bibsize;//количесвто задиствованых режимов
    public int pcard;
    public int ccard;
    public string tag;//frak
    public int cardes;
}
public class Siny
{
    //файл синхронизации
    public int cardes;
}