﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AIBasik : MonoBehaviour
{
    //bot
    public int Emana;
    public int EHp;
    public int Ecard;

    public int mana;
    public int Hp;
    public int card;

    public bool bolk;//перед или зад

    private string BP1= "spam";//на что смотрим
    private string mood = "";//на что смотрим
    private int rot;//текущий
    private int ret;//просаматриваемый



    public int reg;//просаматриваемый
    public int rel;//просаматриваемый
    public bool com = false;//выполнена команда

    public GameObject GG;
    public GameObject GP;
    // Start is called before the first frame update
    void Start()
    {
        /*
         процедура
         смотрим что у нас есть и сиздаем приоритет
         смотрим что мы можем седалать с отдельно взятым обектом
         */
    }
    public void Sinx()
    {//получение данных
        Ecard =  - gameObject.GetComponent<stol>().Ecard;
        card = -(gameObject.GetComponent<stol>().coun - gameObject.GetComponent<stol>().str5);
        mana = (gameObject.GetComponent<stol>().manebatel);
        Emana = (gameObject.GetComponent<stol>().Emanebatel);
        Hp = (gameObject.GetComponent<stol>().hp);
        EHp = (gameObject.GetComponent<stol>().Ehp);
    }

    public void skan()
    {//оценка стола
        //выводит тактику и приоритет
        //добавить режим зеркало
        reg++;
        GP = GameObject.Find("Acard" +reg);
        if(GP != null){
            switch (GP.GetComponent<card>().clas)
            {
                case ("Card"):
                   // Debug.Log(GP.GetComponent<card>().mane);
                    //Debug.Log(Emana);
                    if ((GP.GetComponent<card>().ddam > 0) || (GP.GetComponent<card>().ddam > GP.GetComponent<card>().dam))
                    {
                        bolk = true;
                    }
                    else { bolk = false; }

                    if (Emana >= GP.GetComponent<card>().mane)
                    {
                        world();
                        if (GG!= null)
                        {
                            //Debug.Log(Emana);
                            //Debug.Log(GP.GetComponent<card>().mane);
                            Emana -= GP.GetComponent<card>().mane;
                            gameObject.GetComponent<stol>().Emanebatel = Emana;
                            gameObject.GetComponent<stol>().maness();
                            GP.GetComponent<card>().clas = "Сreator";
                            GP.GetComponent<card>().Stol = GG;
                            GP.transform.SetParent(GG.transform);
                            if(GG.GetComponent<StolSlot>().BObj != null)
                            {
                                GG.GetComponent<StolSlot>().BObj.transform.SetParent(GG.transform);
                            } 
                            gameObject.GetComponent<stol>().Ehand--;
                            GP.GetComponent<card>().SReader();
                            bolk = false;
                        }
                       


                    }
                    break;
                case ("Сreator"):
                    if (GP.GetComponent<card>().power == true)
                    {
                        if ((GP.GetComponent<card>().ddam > 0) || (GP.GetComponent<card>().ddam > GP.GetComponent<card>().dam))
                        {
                            bolk = true;
                        }
                        else { bolk = false; }
                        // bolk = false;
                        WorldAlt();
                        // if (GG.GetComponent<StolSlot>().AObj != null)
                        //{
                        if (mood == "Head")
                        {
                            gameObject.GetComponent<Codex>().select = GG;
                            gameObject.GetComponent<Codex>().selClas = "Head";

                        }
                        else
                        {

                            gameObject.GetComponent<Codex>().selClas = "Сreator";
                            if (GG != null)
                            {
                                gameObject.GetComponent<Codex>().select = GG.GetComponent<StolSlot>().AObj;
                            }
                            else
                            {
                                WorldAlt();
                                gameObject.GetComponent<Codex>().select = GG.GetComponent<StolSlot>().AObj;
                            }
                        }
                        
                       
                        gameObject.GetComponent<Codex>().clas = "Сreator";
                        
                        if (bolk == true)
                        {
                            gameObject.GetComponent<Codex>().mood = "DDam"; mood = "DDam";
                        }
                        else
                        {
                            if(mood != "Null")
                            { 
                                gameObject.GetComponent<Codex>().mood = "Dam"; mood = "Dam";
                            }
                        }


                        if (mood != "Null")//временая мера
                        {
                            gameObject.GetComponent<Codex>().sel = GP;

                            gameObject.GetComponent<Codex>().codex();

                            bolk = false;

                            GP.GetComponent<card>().SReader();//вызов обработки состояний
                        }
                        // WorldAlt();
                        rel = 0;
                    }
                    break;
            }
        }
       



        if ( reg < Ecard)
        {
            skan();
        }
        else {
            gameObject.GetComponent<ListAnimator>().stop = false;
            rel = 0;
            reg = 0;
            gameObject.GetComponent<stol>().Newhod();
        }
    }
    void world()
    {//сканируем стол
        rel++;
        GG = GameObject.Find("SlotA" + rel);
        
        if (bolk == true)
        {
            if (GG.GetComponent<StolSlot>().AObj != null)
            {
                if (GG.GetComponent<StolSlot>().BObj == null)
                { 
                    GG.GetComponent<StolSlot>().BObj = GP;
                    bolk = false;
                   // rel = 0;
                   // GG = null;
                    //GP.transform.SetParent(GG.transform);
                }
                else
                {
                    if (rel == 7)
                    {
                        bolk = false;
                        rel = 0;
                        GG = null;
                        //world();
                    }
                    else if (rel < 7)
                    { world(); }
                }
            }
            else
            {
                if (rel == 7)
                {
                    bolk = false;
                    rel = 0; int lok = 2;
                    if ((GP.GetComponent<card>().sp1 == lok)
                        || (GP.GetComponent<card>().sp2 == lok)
                        || (GP.GetComponent<card>().sp3 == lok)
                        || (GP.GetComponent<card>().sp4 == lok)
                        || (GP.GetComponent<card>().sp5 == lok)
                        )
                    {
                        world();
                    }
                    else
                    {
                        GG = null;
                    }
                }
                else if (rel < 7)
                { world(); }
            }
            
          
           // else { rel = 0; }

        }
        else
        {
            // если нет силы атаки
            //Debug.Log(GG);
            //Debug.Log(GG.GetComponent<StolSlot>().AObj);
            if (GG.GetComponent<StolSlot>().AObj == null)
            {
                
                    GG.GetComponent<StolSlot>().AObj = GP;
               // rel = 0;
            }
            else
            {
                if(GG.GetComponent<StolSlot>().AObj.GetComponent<card>().ddam > 0)
                {
                    GG.GetComponent<StolSlot>().BObj = GG.GetComponent<StolSlot>().AObj;
                    GG.GetComponent<StolSlot>().AObj = GP;
                }
                else
                if (rel < 7)
                { world(); }
                else { rel = 0; GG = null; }
            }
        }
            

        

        
              
    }
    void WorldAlt()
    {//сканируем стол
        rel++;
        GG = GameObject.Find("Slot" + rel);//слоты игрока
        if (bolk == true)
        {
            if (GG.GetComponent<StolSlot>().AObj != null)
            {
                mood = "DDam";

                gameObject.GetComponent<Codex>().select = GG.GetComponent<StolSlot>().AObj;
                //rel = 0;
            }
            else
            //{
                if (rel < 7)
                { WorldAlt(); }
            else
            if (rel == 7)
            {
               // bolk = false;
                rel = 0;
                mood = "Head";
                GG = GameObject.Find("MyHome");
                bolk = true;
                //world();
            }

            // }


        }
        else
        {
            if (GG.GetComponent<StolSlot>().AObj == null)
            {
                if (rel < 7)
                { WorldAlt(); }
                else { //rel = 0;
                    mood = "Head";
                    GG = GameObject.Find("MyHome");
                }
            }
            else
            {
                int DP = GP.GetComponent<card>().def + GP.GetComponent<card>().shild + GP.GetComponent<card>().hp;
                int rem = 35;
                //35 = первый удар)
                if (((GG.GetComponent<StolSlot>().AObj.GetComponent<card>().sp1 == rem)
                        || (GG.GetComponent<StolSlot>().AObj.GetComponent<card>().sp2 == rem)
                        || (GG.GetComponent<StolSlot>().AObj.GetComponent<card>().sp3 == rem)
                        || (GG.GetComponent<StolSlot>().AObj.GetComponent<card>().sp4 == rem)
                        || (GG.GetComponent<StolSlot>().AObj.GetComponent<card>().sp5 == rem))
                        & ((GP.GetComponent<card>().sp1 == rem)
                        || (GP.GetComponent<card>().sp2 == rem)
                        || (GP.GetComponent<card>().sp3 == rem)
                        || (GP.GetComponent<card>().sp4 == rem)
                        || (GP.GetComponent<card>().sp5 == rem)))
                {
                    if (DP > GG.GetComponent<StolSlot>().AObj.GetComponent<card>().dam)
                    {
                        mood = "Dam";

                        gameObject.GetComponent<Codex>().select = GG.GetComponent<StolSlot>().AObj;
                    }
                    else { WorldAlt(); }
                }
                else if ((GG.GetComponent<StolSlot>().AObj.GetComponent<card>().sp1 == rem)
                       || (GG.GetComponent<StolSlot>().AObj.GetComponent<card>().sp2 == rem)
                       || (GG.GetComponent<StolSlot>().AObj.GetComponent<card>().sp3 == rem)
                       || (GG.GetComponent<StolSlot>().AObj.GetComponent<card>().sp4 == rem)
                       || (GG.GetComponent<StolSlot>().AObj.GetComponent<card>().sp5 == rem))
                {
                    if (DP > GG.GetComponent<StolSlot>().AObj.GetComponent<card>().dam)
                    {
                        mood = "Dam";

                        gameObject.GetComponent<Codex>().select = GG.GetComponent<StolSlot>().AObj;
                    }
                    else { WorldAlt(); }
                }
                else
                {
                    if(GP.GetComponent<card>().dam > 0)
                    { 
                        mood = "Dam";
                    }
                    else { mood = "Null"; }

                    gameObject.GetComponent<Codex>().select = GG.GetComponent<StolSlot>().AObj;
                }

                // rel = 0;
            }
        }






    }

    void simhod()
    {//для болванчика
        com = false;
        if (mana > 0)
        {

        }

        if(com != false)
        {
            simhod();
        }
    }
    // Update is called once per frame
    void Update()
    {
        
    }


    void HP()//просчитываем выживаемость карты
    {
        int DP;//Damag Protect
        if (GP.GetComponent<card>().def >0) { }
        DP = GP.GetComponent<card>().def + GP.GetComponent<card>().shild + GP.GetComponent<card>().hp;
    }
}
