using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;
using System.IO;

public class PixVriter : MonoBehaviour
{
    public WorldConstructor Gen;
    public Tilemap Lmap;
    public Tilemap SubLmap;
    public Tilemap BorderLmap;

    public TileBase G2_Grass;
    public Tile G1_Grass;
    public Tile G1_Rook;
    public Tile G1_Def;
    public Tile G1_Border;
    public int Chunk_Size;
    public int X_Chunk;
    public int id;
    public int g;

    public Color[] pix;
    public Color[] pix1;
    public Texture2D noiseTex;
    // Start is called before the first frame update

    void PrintFlor(int L, int x, int y, bool ty)
    {//����� �������� ����
     // Debug.Log($"{x}, {y} + {L} * 2, {L}*5");
        if (ty)
        {
            Lmap.SetTile(new Vector3Int(x, y + L * 2, L * -25), G2_Grass);
        }
        else
        {
            Lmap.SetTile(new Vector3Int(x, y + L * 2, L * -25), G1_Def);
          //  BorderLmap.SetTile(new Vector3Int(x, y + L * 2, L * -25), G1_Def);
        }
    }
    void PrintFlor3(int ii)
    {
        int sample = 1;
        int L = id;
        int x = ii % (Chunk_Size * X_Chunk);
        int y = ii / (Chunk_Size * X_Chunk);
        Vector3Int xc =  new Vector3Int(x, y + L * 2, L * -25);
        if (x < 1)
        {
            xc = new Vector3Int(x - 1, y + L * 2, L * -25);
            BorderLmap.SetTile(xc, G1_Def);
        }
      else  if (x < (Chunk_Size * X_Chunk) - 1)

        {
            xc = new Vector3Int(x + 1, y + L * 2, L * -25);
            BorderLmap.SetTile(xc, G1_Def);
        }
        if (y < 1)
        {
            xc = new Vector3Int(x, y - 1 + L * 2, L * -25);
            BorderLmap.SetTile(xc, G1_Def);
        }
      else  if (y > (Chunk_Size * X_Chunk) - 1)
        {

            xc = new Vector3Int(x, y + 1 + L * 2, L * -25);
            BorderLmap.SetTile(xc, G1_Def);
        }

    }
    void PrintFlor2(int ii)
    {
        int sample = 1;
        int L = id;
        int x = ii % (Chunk_Size * X_Chunk);
        int y = ii / (Chunk_Size * X_Chunk);
        Vector3Int xc = new Vector3Int(x, y + L * 2, L * -25);
        if (x > 1)
        {
            if (pix[ii -1].b < 0.8f)
            {
                sample = 0;
            }
            if (sample == 0)
            {
                xc = new Vector3Int(x-1, y + L * 2, L * -25);
                BorderLmap.SetTile(xc, G1_Def);
            }
            sample = 1;
        }
        else
        {
            xc = new Vector3Int(x - 1, y + L * 2, L * -25);
            BorderLmap.SetTile(xc, G1_Def);
        }
        if ( x < (Chunk_Size * X_Chunk)-1)
        {
            if (pix[ii + 1].b < 0.8f)
            {
                sample = 0;
            }
            if (sample == 0)
            {
                xc = new Vector3Int(x + 1, y + L * 2, L * -25);
                BorderLmap.SetTile(xc, G1_Def);
            }
            sample = 1;
        }
        else
        {
            xc = new Vector3Int(x + 1, y + L * 2, L * -25);
            BorderLmap.SetTile(xc, G1_Def);
        }
        if (y > 1)
        {
            if (pix[ii - (Chunk_Size * X_Chunk)].b < 0.8f)
            {
                sample = 0;
            }
            if (sample == 0)
            {
                xc = new Vector3Int(x, y - 1 + L * 2, L * -25);
                BorderLmap.SetTile(xc, G1_Def);
            }
            sample = 1;
        }
        else
        { 
            xc = new Vector3Int(x, y - 1 + L * 2, L * -25);
            BorderLmap.SetTile(xc, G1_Def);
        }
        if (y < (Chunk_Size * X_Chunk)-1)
        {
            if (pix[ii + (Chunk_Size * X_Chunk)].b < 0.8f)
            {
                sample = 0;
            }
            if (sample == 0)
            {
                xc = new Vector3Int(x , y +1+ L * 2, L * -25);
                BorderLmap.SetTile(xc, G1_Def);
            }
        }
        else 
        {

            xc = new Vector3Int(x, y + 1 + L * 2, L * -25);
            BorderLmap.SetTile(xc, G1_Def);
        }

    }

    void PrintFlor1(int L, int x, int y)
    {//����� �������� ����
     // Debug.Log($"{x}, {y} + {L} * 2, {L}*5");
     //  Debug.Log(TS.G1_Rook[0]);
     //  Vector3Int xc = new Vector3Int(x, y + L-1 * 5, L * -25);
     //    TileBase s1 = Lmap.GetTile(xc);
     // xc = new Vector3Int(x, y - 2 + L * 5, L * -25);
     //TileBase s2 = SubLmap.GetTile(xc);
     //Debug.Log(s1);
     //if(s2 == null)
     //{

        //    xc = new Vector3Int(x, y - 2 + L * 5, L * -25);
        //   s2 = SubLmap.GetTile(xc);
        //}
        //if (s2 == null)
        //{

        //    xc = new Vector3Int(x, y + L * 5, L * -25);
        //   s2 = SubLmap.GetTile(xc);
        //}
        // if (s1 == null)
        //  {
        //if (s2 == null)
        //{
        Vector3Int xc = new Vector3Int(x, y - 1 +L*2 , L * -25);
                SubLmap.SetTile(xc, G1_Rook);
           // }
       // }
    }
    void Start()
    {
        //BorderLmap.gameObject.GetComponent<BorderSys>().id = id;
        Chunk_Size =Gen.Chunk_Size;

       // X_Chunk= Gen.X_Chunk;

        // Debug.Log(id);
        // Debug.Log($"/Map/Global/DataFullLevel{Gen.WorldLevel - id}.jpg");
        byte[] img = File.ReadAllBytes(Application.dataPath + $"/Map/Global/g{g}/DataFullLevel{Gen.WorldLevel-(id+0)}.png");//(filePath);

        byte[] img1 = null;
        if (File.Exists(Application.dataPath + $"/Map/Global/g{g}/DataFullLevel{Gen.WorldLevel - (id + 1)}.png"))
        {
            img1 = File.ReadAllBytes(Application.dataPath + $"/Map/Global/g{g}/DataFullLevel{Gen.WorldLevel - (id+1 )}.png");//(filePath);
        }

        //  Texture2D
        noiseTex = new Texture2D(1, 1);
        Texture2D noiseTex1 = new Texture2D(1, 1);
        noiseTex.LoadImage(img);
        noiseTex.Apply();

       // Color[] 
            pix = noiseTex.GetPixels(0, 0, noiseTex.width, noiseTex.height);
     //   Debug.Log($"{noiseTex.width}, {noiseTex.height}");
        if (img1 != null)
        {
            noiseTex1.LoadImage(img1);
            noiseTex1.Apply();
            pix1 = noiseTex1.GetPixels(0, 0, noiseTex1.width, noiseTex1.height);
            if (pix.Length != pix1.Length)
                img1 = null;
        }
        //Debug.Log(pix.Length);
        //Debug.Log(pix1.Length);
        for (int ii = 0; ii < pix.Length; ii++)
        {

            float sample = 1;
            if (pix[ii].b < 0.8f)
            {
                sample = 0;
            }
            //   Debug.Log($"{pix[ii].b} > {n}");


            if (sample == 1)
            {
                bool top = true;
                //   Debug.Log(ii);
                if (img1 != null)
                {
                    
                    if (pix1[ii ].b > 0.8f)
                    {
                        top = false;
                    }
                }


                PrintFlor(id, ii % (noiseTex.width), ii / (noiseTex.width), top);
                if ((ii - (noiseTex.width)) >= 0)
                {
                    //Debug.Log(ii );
                    //Debug.Log(ii - (Chunk_Size * X_Chunk));
                    //Debug.Log(pix[ii ].b);
                    //Debug.Log(pix[ii - (Chunk_Size * X_Chunk)].b);
                    //Debug.Log(n);
                    // Debug.Log(pix[ii - (Chunk_Size * X_Chunk)].b);
                    // if (pix[ii - (Chunk_Size * X_Chunk)].b <= 0.4f)
                    // {
                    if (pix[ii - (noiseTex.width)].b < 0.8f)
                    {
                        sample = 0;
                    }
                    if (sample == 0)
                    {
                        PrintFlor1(id, ii % (noiseTex.width), ii / (noiseTex.width));
                    }
                }
                else 
                {
                   PrintFlor1(id, ii % (noiseTex.width), ii / (noiseTex.width));
                }

               //PrintFlor2( ii );
            }
         //   PrintFlor3(ii);
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
