﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Xml;
using System.IO;
using UnityEngine.Tilemaps;
//using System.Threading.Tasks;

public class WorldConstructor : MonoBehaviour
{
    public bool PixComp;
 //   private XmlTextReader reader;
    private XmlDocument _xmlDoc;//для управляющих фаилов
   // private XmlDocument xmlDoc1;//для данных карты
    private XmlNode userNode;//lev2
    private XmlAttribute attribute;
    private XmlElement _element;//lev3



    public GameObject Compres;
    [SerializeField] private TailStore TS;

    [SerializeField] private int _xChunk;
    [SerializeField] private int _yChunk;
    public int Chunk_Size;

    private int pixWidth;
    private int pixHeight;
    public int WorldLevel = 6;
    public float[] _ScaleMod;//маштаб слоя 
    /*нулевая карта должна стать картой биомов, но это будет гораздо позже
     * на основе ее идут множители бома
     */
    public float[] mapMod;//предписывает значения перехода
    public float[] mapModAlt;//предписывает множитель после перехода

    // private float scale = 1.0F;
    //  private float scale1 = 1.0F;
    public Texture2D noiseTex;
    public Texture2D FullMap;
   // private Color[] pix;
    private Renderer rend;
    //public Renderer rend1;

    // public Color C1;


    public GameObject GG;
    public GameObject GG1;
    public GameObject GG2;
    public GameObject GG3;
    public int _seed = 42;

    public GameObject Cass;
    public Chunk_Con CH;

    public Texture2D _sysWorld;
    public Texture2D[] World_Noise;
    public Texture2D[] World_Buffer;

    public float taime;
    [SerializeField] private Tilemap[] _tilemap;
    [SerializeField] private GameObject[] _worldGrid;

    /*
     новая ирархия
     * start
    NewWorld глобальная карта
   Island -сборка макетов островов
   NoiseGeneration --сборка шума для моделирования островов
   IslandConversion ---разборка остравов на слои
    -+-(доп)добавочные слои
     */

    void FixedUpdate()
    {
    }

    void Start()
    {
        Application.targetFrameRate = 60;

        rend = GetComponent<Renderer>();
        taime = 1;
        if (_seed != 0)
        {
            Random.seed = _seed;
        }

       // byte[] img = File.ReadAllBytes(Application.dataPath + $"/Map/Global/WorldMapColor.png");//(filePath);

        //byte[] img1 = null;
        //if (File.Exists(Application.dataPath + $"/Map/Global/g{g}/DataFullLevel{Gen.WorldLevel - (id + 1)}.jpg"))
        //{
        //    img1 = File.ReadAllBytes(Application.dataPath + $"/Map/Global/g{g}/DataFullLevel{Gen.WorldLevel - (id + 1)}.jpg");//(filePath);
        //}

        //  Texture2D
        //noiseTex = new Texture2D(1, 1);
        //noiseTex.filterMode = FilterMode.Point;
        //noiseTex.LoadImage(img);
        //noiseTex.Apply();
        //rend.material.mainTexture = noiseTex;

        NewWorld();

    }

    private void NewWorld()
    {
        Texture2D xc = new Texture2D(_xChunk, _yChunk);//64 64
        xc.filterMode = FilterMode.Point;
        Color[] pix = new Color[xc.width * xc.height];
        int[] pixInt = new int[pix.Length];


        float scale = Mathf.Sqrt(_xChunk * _xChunk + _yChunk * _yChunk);

        int xOrg = (int)Random.Range(0, 1512);
        int yOrg = (int)Random.Range(0, 1512);

        int i = 0;
        float y = 0.0F;
        while (y < xc.height)
        {
            float x = 0.0F;
            while (x < xc.width)
            {
                int cof1 = Random.Range(0, 100);
                float xCoord = xOrg + x / xc.width * scale;
                float yCoord = yOrg + y / xc.height * scale;

                float sample = Mathf.PerlinNoise(xCoord, yCoord);

                Color C1 = new Color(0, 0, 0);
                if (cof1 >60)
                {
                    //     if (!Directory.Exists(Application.dataPath + "/Map/Global/g"+i))
                    //         Directory.CreateDirectory(Application.dataPath + "/Map/Global/g" + i);
                    //     WorldMapSage1(i);
                    // pixBit[i] = true;
                    pixInt[i] =1;
                  //  Debug.Log(pixInt[i]);
                     C1 = new Color(0, 0, 5);
                }

                pix[i] = C1;
                x++;
                i++;
            }
            y++;
        }
        //if (!Directory.Exists(Application.dataPath + "/Map/Global/g" + 0))
        //    Directory.CreateDirectory(Application.dataPath + "/Map/Global/g" + 0);
     //   Debug.Log(pixInt);
      //  Debug.Log(pixInt.Length);
       Island(pixInt);

        xc.SetPixels(pix);
        xc.Apply();
       // rend.material.mainTexture = xc;
        byte[]  bytes = xc.EncodeToPNG();

        // For testing purposes, also write to a file in the project folder
        File.WriteAllBytes(Application.dataPath + $"/Map/Global/WorldMap.png", bytes);
        // SysWorld = xc;


    }

    private void Island(int[] pixInt)
    {
        //  Debug.Log("ok");
        //Color[] gh = new Color[];
        Color[] colors = new Color[(_xChunk* _yChunk)];//(0,0,0);
        for (int i = 0; i < colors.Length; i++)
        {
            colors[i]= new Color(Random.value, Random.value, Random.value, 1);
        }

        int[] g1Blok = new int [colors.Length];
        int g1 = 0;

        Texture2D xc = new Texture2D(_xChunk, _yChunk);//64 64
        xc.filterMode = FilterMode.Point;

        Color[] pix = new Color[xc.width * xc.height];
        int[] pixInt1 = new int[pix.Length];

        bool flip = false;
   //     Debug.Log("ok" + pixInt.Length);
        for (int i1 = 0; i1 < pixInt.Length; i1++)
        {
            if (i1 % _xChunk == 0) g1++;
                //    flip = true;
                //     Debug.Log("ok"+i1);
                if (pixInt[i1] == 1)
            {
                flip = true;
               // Debug.Log($"{i1}  {g1}");
                if (pixInt1[i1] > 0)
                {
                    int i3 = 0;
                    i3 = i1 - 1 - _xChunk;
                    if (i3 > 0)
                        if (pixInt[i3] == 1)
                            if (i3 % _xChunk != 9)
                            {
                            g1Blok[pixInt1[i3]]--;
                            pixInt1[i3] = pixInt1[i1];
                            g1Blok[pixInt1[i3]]++;
                            pix[i3] = colors[pixInt1[i1]];
                        }

                    i3 = i1 - _xChunk;
                    if (i3 > 0)
                        if (pixInt[i3] == 1)
                            {
                            g1Blok[pixInt1[i3]]--;
                            pixInt1[i3] = pixInt1[i1];
                            g1Blok[pixInt1[i3]]++;
                            pix[i3] = colors[pixInt1[i1]];
                        }

                    i3 = i1 + 1 - _xChunk;
                    if (i3 > 0)
                        if (pixInt[i3] == 1)
                            if (i3 % _xChunk != 0)
                            {
                            g1Blok[pixInt1[i3]]--;
                            pixInt1[i3] = pixInt1[i1];
                            g1Blok[pixInt1[i3]]++;
                            pix[i3] = colors[pixInt1[i1]];
                        }



                    i3 = i1 - 1;
                    if (i3 > 0)
                        if (pixInt[i3] == 1)
                            if (i3 % _xChunk != 9)
                            {
                            g1Blok[pixInt1[i3]]--;
                            pixInt1[i3] = pixInt1[i1];
                            g1Blok[pixInt1[i3]]++;
                            pix[i3] = colors[pixInt1[i1]];
                    }

                    i3 = i1 + 1;
                    if (i3 < pixInt.Length)
                        if (i3 % _xChunk != 0)
                            if (pixInt[i3] == 1)
                        {
                            g1Blok[pixInt1[i3]]--;
                            pixInt1[i3] = pixInt1[i1];
                            g1Blok[pixInt1[i3]]++;
                            pix[i3] = colors[pixInt1[i1]];
                        }



                    i3 = i1 - 1 + _xChunk;
                    if (i3 < pixInt.Length)
                        if (i3 % _xChunk != 9)
                            if (pixInt[i3] == 1)
                        {
                            g1Blok[pixInt1[i3]]--;
                            pixInt1[i3] = pixInt1[i1];
                            g1Blok[pixInt1[i3]]++;
                            pix[i3] = colors[pixInt1[i1]];
                        }

                    i3 = i1 + _xChunk;
                    if (i3 < pixInt.Length)
                            if (pixInt[i3] == 1)
                        {
                            g1Blok[pixInt1[i3]]--;
                            pixInt1[i3] = pixInt1[i1];
                            g1Blok[pixInt1[i3]]++;
                            pix[i3] = colors[pixInt1[i1]];
                        }

                    i3 = i1 + 1 + _xChunk;
                    if (i3 < pixInt.Length)
                        if (i3 % _xChunk != 0)
                            if (pixInt[i3] == 1)
                        {
                            g1Blok[pixInt1[i3]]--;
                            pixInt1[i3] = pixInt1[i1];
                            g1Blok[pixInt1[i3]]++;
                            pix[i3] = colors[pixInt1[i1]];
                        }
                }
                else
                {
                    //  g1++;
                    int g2 = 0;// g1;
                    int i3 = 0;

                    i3 = i1 - 1 - _xChunk;
                    if (i3 > 0)
                        if (i3 % _xChunk != 9)
                            if (pixInt[i3] == 1)
                        {
                            if (pixInt1[i3] > 0)
                            {
                                g2 = pixInt1[i3];
                            }
                        }

                    i3 = i1 - _xChunk;
                    if (i3 > 0)
                            if (pixInt[i3] == 1)
                        {
                            if (pixInt1[i3] > 0)
                            {
                                g2 = pixInt1[i3];
                            }
                        }

                    i3 = i1 + 1 - _xChunk;
                    if (i3 > 0)
                        if (i3 % _xChunk != 0)
                            if (pixInt[i3] == 1)
                        {
                            if (pixInt1[i3] > 0)
                            {
                                g2 = pixInt1[i3];
                            }
                        }

                    i3 = i1 - 1;
                    if (i3 > 0)
                        if (i3 % _xChunk != 9)
                            if (pixInt[i3] == 1)
                        {
                            if (pixInt1[i3] > 0)
                            {
                                g2 = pixInt1[i3];
                            }
                        }

                    if (g2 == 0)
                    {
                        g1++;
                        g2 = g1;
                    }


                        i3 = i1;
                        if (pixInt[i3] == 1)
                    {
                        g1Blok[g2]++;
                        pixInt1[i3] = g2;
                            pix[i3] = colors[g2];
                        }


                    i3 = i1 + 1;
                    if (i3 < pixInt.Length)
                        if (i3 % _xChunk != 0)
                            if (pixInt[i3] == 1)
                        {
                            g1Blok[g2]++;
                            pixInt1[i3] = g2;
                            pix[i3] = colors[g2];
                        }

                    i3 = i1 - 1 + _xChunk;
                    if (i3 < pixInt.Length)
                        if (i3 % _xChunk != 9)
                            if (pixInt[i3] == 1)
                        {
                            g1Blok[g2]++;
                            pixInt1[i3] = g2;
                            pix[i3] = colors[g2];
                        }

                    i3 = i1 + _xChunk;
                    if (i3 < pixInt.Length)
                            if (pixInt[i3] == 1)
                        {
                            g1Blok[g2]++;
                            pixInt1[i3] = g2;
                            pix[i3] = colors[g2];
                        }

                    i3 = i1 + 1 + _xChunk;
                    if (i3 < pixInt.Length)
                        if (i3 % _xChunk != 0)
                            if (pixInt[i3] == 1)
                        {
                            g1Blok[g2]++;
                            pixInt1[i3] = g2;
                            pix[i3] = colors[g2];
                        }

                }
            }
            else
            {
                if(flip == true)
                {
                  //  Debug.Log(i1);
                    flip = false;
                    g1++;
                }
              //  Debug.Log($"{i1}  {g1}");
              //  Debug.Log(g1);
            }
        }
        xc.SetPixels(pix);
        xc.Apply();
        rend.material.mainTexture = xc;
        byte[] bytes = xc.EncodeToPNG();
        
        // For testing purposes, also write to a file in the project folder
        File.WriteAllBytes(Application.dataPath + $"/Map/Global/WorldMapColor.png", bytes);
        int g3 = 0;
     //   pix = new Color[xc.width * xc.height];
        for (int i1 =0; i1 < g1Blok.Length; i1++)
        {
            //Debug.Log($"{g1}  {i1}   {g1Blok[i1]}");
            if (g1Blok[i1] > 0)
            {
                g3++;


                Texture2D xc1 = new Texture2D(_xChunk, _yChunk);//64 64
                xc1.filterMode = FilterMode.Point;

                Color[] pix2 = new Color[_xChunk * _yChunk];

                //   pix = new Color[xc.width * xc.height];
                int xConst = 1;
                int yConst = 1;
                int t1 = -1;
               // int t2 = -1;
                int t3 = 0;
                int t4 = 0;
                int t5 = 0;
                for (int i2 = 0; i2 < pixInt.Length; i2++)
                {
                    pix2[i2] = new Color(0, 0, 0);
                    if (pixInt[i2] == 1)
                    {
                        if (pixInt1[i2] == i1)
                        {
                            pix2[i2] = new Color(0, 0, 1);
                            t4++;
                            if (t1 == -1) { t1 = i2; //Debug.Log(i2);
                            }

                            t3 = i2 % _xChunk;
                            if (t3 < (t1 % _xChunk))
                            { //Debug.Log($"{t1}, {t3}");
                                //   Debug.Log(xConst);
                                t1 = t3 + (t1 / _xChunk) * _xChunk;
                                //  Debug.Log($"{t1}, {t3}");
                            }

                            t3 = i2 % _xChunk;// - t1 % _xChunk;
                            if (t3 >= t5)
                            {
                                t5 = t3;
                               // xConst = 
                              //  Debug.Log($"{xConst} {g3}");
                               // xConst = t3 + 1;
                            }
                            // Debug.Log($"{ t3}({i2} {t1}) ={g3}=     _{xConst}");

                            t3 = i2 / _xChunk - t1 / _xChunk ;
                            if (t3 >= yConst)
                            {
                                yConst = t3 + 1; 
                            }

                          //  t2 = i2;

                          //  pix[i2] = colors[i1];
                        }
                    }
                }
                if (t1 > -1)
                {
                    if ((xConst + yConst) > 2)
                    {
                        xConst = 1 + t5 - t1 % _xChunk;

                        xc1.SetPixels(pix2);
                        xc1.Apply();
                        pix2 = xc1.GetPixels((t1 % _xChunk), (t1 / _xChunk), xConst, yConst);
                        xc1 = new Texture2D(xConst, yConst);
                        xc1.SetPixels(pix2);
                        xc1.Apply();


                        if (Directory.Exists(Application.dataPath + $"/Map/Global/g{g3}/"))
                            Directory.Delete(Application.dataPath + $"/Map/Global/g{g3}/", true);
                        Directory.CreateDirectory(Application.dataPath + $"/Map/Global/g{g3}/");

                        byte[] bytes1 = xc1.EncodeToPNG();
                        File.WriteAllBytes(Application.dataPath + $"/Map/Global/g{g3}/OrigIsland.png", bytes1);


                        IslandDecoder(t1, xConst, yConst, pix2, g3, i1);//pixInt1
                    }
                }
            }

            //  Debug.Log($"{t1},{t2},{pixInt1}, {i1}");
            //  if (t1 != 0) 
            ///   IslandDecoder(t1,t2,pixInt1, g2);
        }

        //
    }
    void IslandDecoder(int t1,int t3, int t4, Color[] pixInt,int i0, int i00)
    {

        //if (Directory.Exists(Application.dataPath + $"/Map/Global/g{i0}/"))
        //    Directory.Delete(Application.dataPath + $"/Map/Global/g{i0}/", true);
        //Directory.CreateDirectory(Application.dataPath + $"/Map/Global/g{i0}/");

        #region XML
        _xmlDoc = new XmlDocument();
        _element = _xmlDoc.CreateElement("World");

    //    int t2 = t1 + t3 + t4 * _xChunk;
        //int t3 = t2 % _xChunk - t1;
        //if (t3 <0)
        //{
        //    t3 = -t3;
        //}

        //int t4 = t2 / _xChunk - t1;

        _element.SetAttribute("WorldX", "" + (t1 % _xChunk));//имя
        _element.SetAttribute("WorldY", "" + (t1 / _xChunk));//имя
        _element.SetAttribute("XSize", "" + t3);//имя
        _element.SetAttribute("YSize", "" + t4);//имя
                                                //_element.SetAttribute("id5", "" + t3);//имя
                                                //_element.SetAttribute("id6", "" + t4);//имя

        _xmlDoc.AppendChild(_element);
        _xmlDoc.Save(Application.dataPath + $"/Map/Global/g{i0}/sys.xml");//запись карты
        #endregion

        //  #region JPG
        // Texture2D xc = new Texture2D(t3, t4);//64 64
        // xc.filterMode = FilterMode.Point;

        // Color[] pix = new Color[xc.width * xc.height];
        //  Debug.Log($"{pix.Length}  {t1}  {i0}");
        //// Debug.Log();
        // for(int i = 0; i< pix.Length; i++)
        // {
        //     Debug.Log($"{t1}+{i} {pixInt[t1 + i]} =={i00}  {i0}");
        //     if (pixInt[t1 + i] == i00)
        //     {
        //         pix[i] = new Color(0, 0, 1);
        //     }
        // }

        // xc.SetPixels(pix);
        // xc.Apply();

        // byte[] bytes = xc.EncodeToJPG(100);
        // File.WriteAllBytes(Application.dataPath + $"/Map/Global/g{i0}/OrigIsland.jpg", bytes);
        //#endregion
        float[] sample = new float[pixInt.Length];
        for (int i = 0; i < sample.Length; i++)
        {
            if (pixInt[i].b > 0.4f)
            {
                sample[i] = 1;
            }
            else
            {
                sample[i] = 0;
            }
         //   sample[i] = pixInt[i].b;
            // Debug.Log(sample[i]);
        }
        NoiseGeneration(t1, t3, t4, i0);
    }

    void NoiseGeneration(int t1, int X, int Y, int g)
    {
        //if (g == 1)
        //{
            World_Noise = new Texture2D[_ScaleMod.Length];//создаем карты высот для генрации


        //int X = (int)Random.Range(20, 30);
        //int Y = (int)Random.Range(20, 30);
        for (int i = 0; i < World_Noise.Length; i++)
        {
            altMap(i, "World_Noise",X,Y,g);
        }
            CallData(t1, g, X, Y);//обсчитываем полученные карты
       // }
    }




    void altMap(int id, string mood, int xChunk, int yChunk, int g)
    {
        Texture2D xc = new Texture2D(Chunk_Size * xChunk, Chunk_Size * yChunk);
        Color[] pix = new Color[xc.width * xc.height];

       float scale = Mathf.Sqrt(xChunk * xChunk + yChunk * yChunk);
        float scale1 = 0;
        float localScale = 0;
        //if (mood == "World_Cave") { localScale = ScaleMod[3]; }
        //else { 
            localScale = _ScaleMod[id]; 
      //  }
        scale *= localScale;
        if (scale > 1)
        {
            scale1 = (int)Random.Range(1, scale);
        }
        int xOrg = (int)Random.Range(0, 1512);
        int yOrg = (int)Random.Range(0, 1512);
        int xOrg1 = (int)Random.Range(0, 1512);
        int yOrg1 = (int)Random.Range(0, 1512);

        //if (id == 0)
        //{
        //    xOrg = 0;
        //        yOrg = 0;
        //    xOrg1 = 0;
        //    yOrg1 = 0;
        //    scale1 = 1;
        //}
            float y = 0.0F;
        while (y < xc.height)
        {
            float x = 0.0F;
            while (x < xc.width)
            {
                float xCoord = xOrg + x / xc.width * scale;
                float yCoord = yOrg + y / xc.height * scale;

                float sample = Mathf.PerlinNoise(xCoord, yCoord);
                if (id == 0)
                {
                    xCoord = xOrg1 + x / xc.width * scale1;
                    yCoord = yOrg1 + y / xc.height * scale1;
                    sample += Mathf.PerlinNoise(xCoord, yCoord) - 0.5f;
                }
                //if (sample > 0.999f) { sample = 0.999f; }
                //else if (sample < 0) { sample = 0.001f; }

                Color C1 = new Color(0, 0, sample);


                pix[(int)(y * xc.width + x)] = C1;
                x++;
            }
            y++;
        }

        xc.SetPixels(pix);
        xc.Apply();
        byte[] bytes = null; 
        string pat = "";
        World_Noise[id] = xc;
        bytes = World_Noise[id].EncodeToPNG();
        pat += $"Data{ id}.png";
        //switch (mood)
        //{
        //    case ("World_Noise"):
        //        World_Noise[id] = xc;
        //        bytes = World_Noise[id].EncodeToJPG();
        //        pat += $"Data{ id}.jpg";
        //        break;
        //    case ("World_Cave"):
        //        World_Cave[id] = xc;
        //        bytes = World_Cave[id].EncodeToJPG();
        //        pat += $"DataCave{ id}.jpg";
        //        break;
        //}


        // For testing purposes, also write to a file in the project folder

        File.WriteAllBytes(Application.dataPath + $"/Map/Global/g{g}/{pat}", bytes);
    }
   
    void CallData(int t1, int g, int X_Chun, int Y_Chun)
    {//обсчитываем полученные карты

        Texture2D xc = new Texture2D(X_Chun*Chunk_Size, Y_Chun * Chunk_Size);

        byte[] img = File.ReadAllBytes(Application.dataPath + $"/Map/Global/g{g}/OrigIsland.png");//(filePath);
        float[] sample1 = new float[X_Chun * Y_Chun];
        if(sample1 != null)
        {
            Texture2D noiseTex = new Texture2D(1, 1);
            noiseTex.LoadImage(img);
            noiseTex.Apply();
            Color[] pix = noiseTex.GetPixels(0, 0, noiseTex.width, noiseTex.height);
            for (int i1 =0;i1 < pix.Length; i1++)
            {
              //  Debug.Log(pix[i1].b);
                sample1[i1] = pix[i1].b;
            }
        }

        // Debug.Log(World_Noise[0].width);
        // Color[] pix0 = World_Noise[0].GetPixels(0, 0, World_Noise[0].width, World_Noise[0].height);
        Color[] pix1 = World_Noise[0].GetPixels(0, 0, World_Noise[0].width, World_Noise[0].height);
        Color[] pix2 = World_Noise[1].GetPixels(0, 0, World_Noise[1].width, World_Noise[1].height);
        Color[] pix3 = World_Noise[2].GetPixels(0, 0, World_Noise[2].width, World_Noise[2].height);

        int iFix = 0;
        int worldX = 0;
        int worldY = 0;
       // int worldI = 0;
       // int worldI1 = 0;
        Debug.Log($"{World_Noise[0].width}   {World_Noise[0].height}");
        Debug.Log($"{sample1.Length} ");
        //while (worldI < sample1.Length)
        //{
            //worldX = worldI % X_Chun;
            //worldY = worldI / X_Chun;
            int i = 0;
            float y = 0.0F;
          //  Debug.Log(sample1[worldI]);
        
              //  worldI1 = worldX *Chunk_Size + worldY * Chunk_Size * worldX;
                while (y < Chunk_Size * X_Chun * Y_Chun)
                {
            worldY = i / ( X_Chun * Chunk_Size * Chunk_Size);
          //  Debug.Log($"{i}   {pix1.Length}  {y}   {Chunk_Size * X_Chun * Y_Chun}  ");
            //  i = (int)y * Chunk_Size * X_Chun + worldI1;//+ worldI * Chunk_Size * Chunk_Size;// worldY * Chunk_Size*X_Chun + worldX * Chunk_Size
            // Debug.Log(i);
            float x = 0.0F;
                    while (x < Chunk_Size)
                    {
                worldX = i % (X_Chun * Chunk_Size);
                worldX /=  Chunk_Size;
                float sample = 0;
                //if (pix2[i].b > mapMod[1])
                //{
                //    if (pix3[i].b > mapMod[2])
                //    {
                //        sample = mapModAlt[2];
                //    }
                //    else
                //    {
                //        sample = pix1[i].b + pix2[i].b;
                //        if (sample > 1) { sample = mapModAlt[1]; }
                //    }
                //}
                //else
                //{
                sample = pix1[i].b;// - mapModAlt[0];
                //}
             //   Debug.Log($"[{worldX} +({worldY}* {X_Chun})");
                if (sample1[worldX + (worldY * X_Chun)] > 0.5f)
                {
                    sample = 0;
                }
                else
                {
                    sample = 1;
                }

                //sample += sample1[iFix] - 0.5f;
                //Debug.Log(sample1[iFix]);
                //if (sample1[worldI] > 0.5f)
                //{
                //    sample = 0;
                //}
                //else
                //{
                //    sample = 1;
                //}


                if (sample > 0.990f) { sample = 0.990f; }
                        else if (sample < 0) { sample = 0.001f; }

                        Color C1 = new Color(0, 0, sample);

                        pix1[i] = C1;
                        x++;
                        i++;
                    }
                    y++;
                }
          //  worldI++;
       // }

        xc.SetPixels(pix1);
        xc.Apply();


        byte[] bytes = xc.EncodeToPNG();

        File.WriteAllBytes(Application.dataPath + $"/Map/Global/g{g}/DataFull.png", bytes);



        rend.material.mainTexture = xc;
        LevelCompilator(g, X_Chun,  Y_Chun, xc);

        if (PixComp)
            for(int iz =0; iz < WorldLevel; iz++)
            {
                GameObject GH = Instantiate(Compres);

                int xMod = t1 % _xChunk * Chunk_Size;

                int yMod = (t1 / _xChunk) * Chunk_Size;
                //int cof1 = 500;
                //int cof2 = 500;
                //Debug.Log($"{yMod} = ({t1} / {_xChunk})");

                GH.GetComponent<PixVriter>().id = iz;
                GH.GetComponent<PixVriter>().g = g;

                GH.GetComponent<PixVriter>().Lmap = Instantiate(_tilemap[0]);// GH1.GetComponenet<>
                GH.GetComponent<PixVriter>().Lmap.transform.SetParent(_worldGrid[0].transform);
                GH.GetComponent<PixVriter>().Lmap.gameObject.GetComponent<TilemapRenderer>().sortingOrder = iz * 5;
                GH.GetComponent<PixVriter>().Lmap.name = _tilemap[0].name + iz;

                GH.GetComponent<PixVriter>().Lmap.gameObject.transform.position = new Vector3(xMod, yMod, 0);
                //etComponent<TilemapRenderer>().sortingOrder = iz * 5;

                GH.GetComponent<PixVriter>().SubLmap = Instantiate(_tilemap[1]);// GH1.GetComponenet<>
                GH.GetComponent<PixVriter>().SubLmap.transform.SetParent(_worldGrid[1].transform);
                GH.GetComponent<PixVriter>().SubLmap.gameObject.GetComponent<TilemapRenderer>().sortingOrder = (iz * 5) - 1;
                GH.GetComponent<PixVriter>().SubLmap.name = _tilemap[1].name + iz;

                GH.GetComponent<PixVriter>().SubLmap.gameObject.transform.position = new Vector3(xMod, yMod, 0);


                GH.GetComponent<PixVriter>().BorderLmap = Instantiate(_tilemap[2]);// GH1.GetComponenet<>
                GH.GetComponent<PixVriter>().BorderLmap.transform.SetParent(_worldGrid[2].transform);
                GH.GetComponent<PixVriter>().BorderLmap.gameObject.GetComponent<TilemapRenderer>().sortingOrder = iz * 5;
                GH.GetComponent<PixVriter>().BorderLmap.name = _tilemap[2].name + iz;
                GH.GetComponent<PixVriter>().BorderLmap.gameObject.layer = 17 +iz;//.LayerMask.NameToLayer('Level'+(iz+1));

                GH.GetComponent<PixVriter>().BorderLmap.gameObject.transform.position = new Vector3(xMod, yMod, 0);


                GH.active = true;
            }
    }
    void LevelCompilator(int g, int X_Chun, int Y_Chun, Texture2D FullMap)
    {
        //закгрузка карты для обработки
        Color[] pix1 = FullMap.GetPixels(0, 0, FullMap.width, FullMap.height);
        Color[] pix2 = FullMap.GetPixels(0, 0, FullMap.width, FullMap.height);


        for (int i=0;i< WorldLevel; i++)
        {
            Texture2D xc = new Texture2D(FullMap.width, FullMap.height);

            float n = (1f / WorldLevel )* i;
            for(int ii =0; ii < pix1.Length; ii++)
            {

                float sample = 1f;
                if(pix1[ii].b > n)
                {
                    sample = 0f;
                }
                pix2[ii] =  new Color(0, 0, sample); 
            }

            xc.SetPixels(pix2);
            xc.Apply();
            byte[] bytes = xc.EncodeToPNG();

            // For testing purposes, also write to a file in the project folder
            File.WriteAllBytes(Application.dataPath + $"/Map/Global/g{g}/DataFullLevel{i+1}.png", bytes);
        }

    }

   
   
}
